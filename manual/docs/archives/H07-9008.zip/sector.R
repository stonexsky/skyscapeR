suppressPackageStartupMessages(library(skyscapeR))
v<-as.character(packageVersion("skyscapeR"));legacy<-v=="2.0.9007"
img<-array(0,c(20,60,4));img[11:20,,4]<-1
png::writePNG(img,"terrain.png")
photo<-function(bounds)importPanorama("terrain.png",c(50,0,0),az.lim=bounds,alt.lim=c(-10,10),alt.unc=.5)
h<-photo(c(330,30));full<-photo(c(0,360))
rows<-list()
score<-function(label,result,expected)rows[[length(rows)+1]]<<-data.frame(label,result=as.character(result),expected=as.character(expected),pass=identical(as.character(result),as.character(expected)))
err<-function(expr)tryCatch({force(expr);"finite"},error=function(e)if(grepl('coverage|photographed|panorama sector',conditionMessage(e),ignore.case=TRUE))"coverage error" else paste("error",conditionMessage(e)))
for(a in c(330,345,359,0,15,30,30.1,180,329.9)){
 z<-hor2alt(h,a,TRUE)
 score(paste("lookup",a),all(is.finite(z)),a<=30 || a>=330)
}
for(a in c(345,359,0,29,180)){
 p<-az.pdf(a,3,pdf="uniform",.res=.5,verbose=FALSE)
 ans<-err(coordtrans(p,h,verbose=FALSE))
 score(paste("PDF",a),ans,if(a %in% c(29,180))"coverage error" else "finite")
 if(a %in% c(345,359,0)){
  q<-coordtrans(p,h,verbose=FALSE)$data[[1]];z<-coordtrans(p,full,verbose=FALSE)$data[[1]]
  score(paste("full-profile agreement",a),isTRUE(all.equal(q,z,tolerance=1e-9)),TRUE)
 }
}
p<-az.pdf(0,3,.res=1,verbose=FALSE)
z<-spd(p,xrange=c(0,360),.res=1)
score("SPD with zero tails",err(coordtrans(z,h,verbose=FALSE)),"finite")
score("sunrise sector",err(riseset(loc=h,date="2000/01/02",obj="sun",timezone="UTC",refraction=FALSE,verbose=FALSE)),"coverage error")
if(!legacy){
 for(pair in list(c(60,90),c(110,150))){
  q<-photo(pair)
  score("ordinary sector inside",err(coordtrans(az.pdf(mean(pair),2,verbose=FALSE),q,verbose=FALSE)),"finite")
  score("ordinary sector outside",err(coordtrans(az.pdf(250,2,verbose=FALSE),q,verbose=FALSE)),"coverage error")
 }
 score("stellar crossing sector",err(riseset(loc=h,date="2000/01/02",obj="Mintaka",timezone="UTC",verbose=FALSE)),"coverage error")
 score("phase sector",err(star.phases("Mintaka",2000,h)),"coverage error")
 score("spatial equinox sector",err(spatial.equinox(h,year=2000)),"coverage error")
 score("spatial equinox full",err(spatial.equinox(full,year=2000)),"finite")
 score("solar full",err(riseset(loc=full,date="2000/01/02",obj="sun",timezone="UTC",verbose=FALSE)),"finite")
 score("phase full",err(star.phases("Mintaka",2000,full)),"finite")
}
for(use in c(FALSE,TRUE)){
 n<-paste0('case-',use)
 score(paste("export sector",use),err(exportHor(h,name=n,use.image=use)),"coverage error")
 score(paste("export full",use),err(exportHor(full,name=n,use.image=use)),"finite")
 unlink(paste0(n,"-horizon.zip"))
}
r<-do.call(rbind,rows);write.csv(r,paste0('sector-',v,'.csv'),row.names=FALSE)
if(!legacy)stopifnot(all(r$pass))
