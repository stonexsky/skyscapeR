library(skyscapeR)
skyscapeR.vars(dec="geo", timezone="UTC", calendar="G",refraction=FALSE)
years <- c(-3499L,-3399L)
track <- star("Aldebaran", seq(years[1],years[2]))$coord$Dec
print(range(track))
# Deliberately centre a narrow teaching band on the star's middle-epoch value.
band <- round(track[51],1)+c(-.05,.05)
print(band)
selected <- findTargets(band, year=years, max.mag=1.5, dates=TRUE)
print(selected$stellar)
write.csv(data.frame(year=seq(years[1],years[2]),dec=track,
                    lower=band[1],upper=band[2]),"annual-star.csv",row.names=FALSE)
