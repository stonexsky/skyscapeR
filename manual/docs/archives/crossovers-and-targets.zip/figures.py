from pathlib import Path
import numpy as np
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
p=Path(__file__).resolve().parent
style={'font.size':10,'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'text.color':'#203647','axes.labelcolor':'#203647'}
plt.rcParams.update(style)
a=np.genfromtxt(p/'annual-star.csv',delimiter=',',names=True)
fig,ax=plt.subplots(figsize=(7.3,3.5),layout='constrained')
ax.axhspan(a['lower'][0],a['upper'][0],color='#ead5ba',label='Input declination band')
ax.plot(1-a['year'],a['dec'],color='#156d77',lw=2.3,label='Aldebaran, annual samples')
ax.set(xlim=(3500,3400),xlabel='Year (BCE)',ylabel='Barycentric declination (°)')
ax.legend(frameon=False);fig.savefig(p/'ald-star.png',dpi=170);plt.close(fig)
import csv
with open(p/'two-evenings.csv') as f:d=list(csv.DictReader(f))
fig,ax=plt.subplots(1,2,figsize=(7.3,3.35),layout='constrained')
for a,col,label in zip(ax,['margin','difference'],['Visibility margin (°)','Moonset minus sunset azimuth (°)']):
 v=[float(row[col]) for row in d];a.bar([0,1],v,width=.58,color=['#9a7254','#227682']);a.axhline(0,color='#293943',lw=.8);a.set_xticks([0,1],['30 June','1 July']);a.set_ylabel(label);a.margins(y=.24)
 for i,b in enumerate(v):a.annotate(f'{b:+.2f}°',(i,b),xytext=(0,4 if b>=0 else -4),textcoords='offset points',ha='center',va='bottom' if b>=0 else 'top')
fig.savefig(p/'crescent-gates.png',dpi=170)
