library(skyscapeR)
skyscapeR.vars(dec="geo", timezone="UTC", calendar="G", refraction=FALSE)
site <- c(40,0,400)
h <- createHor(c(0,7,10,12,15,180,360), c(0,0,12,12,0,0,0), loc=site)
north <- vapply(c(5,25), function(w) hor2max.dec(h,range=w),numeric(1))
print(north)
print(hor2min.dec(h))
targets <- findTargets(c(-1.5,0.2), year=c(2020,2026), max.mag=2.5, dates=TRUE)
print(targets)
print(skyObject("Equinox",2026)$decs)
print(c(jS=jS(2026,verbose=FALSE),dS=dS(2026,verbose=FALSE),
        north_major=nMjLX(2026,verbose=FALSE), north_minor=nmnLX(2026,verbose=FALSE),
        south_major=sMjLX(2026,verbose=FALSE), south_minor=smnLX(2026,verbose=FALSE)))
