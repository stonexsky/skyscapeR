Run Rscript S03.R and Rscript S03-extra.R. Use python3 score.py for the independent ranks. The baseline directory contains fixed input matrices.
Current package run: skyscapeR 2.0.9015, revision fec1c516e8cf9b8caa0bb560fe797dc1c7847b18. Run commands in the extracted directory.
