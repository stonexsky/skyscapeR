# D01 numerical validation

Install the exact skyscapeR source from the manual (SHA-256 0446c0a57afe16274e7ef033113ac8d9f251b4f812b1a2d2ea22eac145bb3bbe). Tested with R 4.3.3. Set TRIO_LIB to a custom R library when needed. Run from this directory. S03 also requires Python 3 with numpy and pandas.

Rscript D01.R

CSV outputs preserve discrepancies. A01 JD tolerance is 0.0001 second. D01 density tolerance is 1e-10 per degree. S03 linear rank and interval tolerance is 1e-11. Circular diagnostics merge the north seam and omit the duplicate direction. For the historical equations see https://github.com/stonexsky/probSkyscapeArch/blob/07d9b84a43cdd2641f9557b704ef4b5927366254/src.R#L300 .
