"""Cache airless topocentric Horizons observer tables; all calls are serial."""
import csv,io,time
from pathlib import Path
from urllib.parse import urlsplit,parse_qsl,urlencode
from urllib.request import urlopen
import pandas as pd
sites={'Atacama':(-70.4,-24.63,2.6),'Kuncizzjoni':(14.34014,35.90085,.1583),'Malta':(14.34,35.90083,.158),'Wiltshire':(-1.83,51.18,.1)}
epochs=[(-3499,443077),(-2499,808319),(-999,1356183),(1900,2415021),(2000,2451545),(2025,2460677)]
def run():
    rows=[]
    for year,jd in epochs:
      for site,(lon,lat,height) in sites.items():
        p=Path('raw',f'{site}-{year}.txt')
        par=dict(format='text',COMMAND='301',CENTER="'coord@399'",COORD_TYPE="'GEODETIC'",SITE_COORD=f"'{lon},{lat},{height}'",EPHEM_TYPE="'OBSERVER'",START_TIME=f"'JD{jd}'",STOP_TIME=f"'JD{jd+3}'",STEP_SIZE="'10 MINUTES'",QUANTITIES="'4,7,30,49'",APPARENT="'AIRLESS'",CSV_FORMAT="'YES'",EXTRA_PREC="'YES'",CAL_FORMAT="'BOTH'",OBJ_DATA="'NO'")
        url='https://ssd.jpl.nasa.gov/api/horizons.api?'+urlencode(par)
        if not p.exists():
          for i in range(4):
            try:
              data=urlopen(url,timeout=50).read().decode()
              if '$$EOE' not in data: raise ValueError(data[-1000:])
              p.write_text(data);break
            except OSError:
              if i==3: raise
              time.sleep(1)
        p.with_suffix('.url').write_text(url)
        chunk=p.read_text().split('$$SOE')[1].split('$$EOE')[0].strip()
        parsed=list(csv.reader(io.StringIO(chunk)));assert len(parsed)==433
        for a in parsed:
          _,t,_,_,az,alt,last,dt,dut,_=map(str.strip,a)
          rows.append(dict(site=site,year=year,jd=float(t),az=float(az),alt=float(alt),last=sum(float(v)/60**k for k,v in enumerate(last.split())),dt=float(dt),dut=0 if dut=='n.a.' else float(dut),lon=lon,lat=lat,height=height))
        assert abs(float(parsed[0][1])-jd)<1e-8
        print(site,year,flush=True)
    pd.DataFrame(rows).to_csv('reference.csv',index=False)
if __name__=='__main__':run()
