suppressPackageStartupMessages(library(skyscapeR))
suppressPackageStartupMessages(library(swephR))
stopifnot(as.character(packageVersion("skyscapeR"))=="2.0.9004")
h <- read.csv("reference.csv")
jd <- h$jd+h$dut/86400
series <- function(mode) {
  out <- matrix(NA_real_, nrow(h), 4)
  for (i in seq_len(nrow(h))) {
    loc <- c(h$lat[i],h$lon[i],h$height[i]*1000)
    if (mode!="package") swe_set_delta_t_userdef((h$dt[i]-h$dut[i])/86400)
    if (mode!="matched") {
      p <- body.position(jd[i],obj="Moon",loc=loc,dec="topo",refraction=FALSE,verbose=FALSE)
      out[i,] <- c(p$horizontal$az,p$horizontal$alt,p$equatorial$RA,p$equatorial$Dec)
    } else {
      swe_set_topo(loc[2],loc[1],loc[3])
      eq <- swe_calc_ut(jd[i],1L,34818L)
      stopifnot(eq$return>=0, bitwAnd(eq$return,7L)==2)
      a <- swe_azalt(jd[i],1L,loc[c(2,1,3)],0,15,eq$xx[1:3])$xaz
      out[i,] <- c((a[1]+180)%%360,a[2],eq$xx[1:2])
    }
  }
  colnames(out) <- paste0(mode,c("_az","_alt","_ra","_dec"))
  out
}
default <- series("package")
control <- series("matched")
clock <- series("clock")
write.csv(cbind(h,default,control,clock),"directions.csv",row.names=FALSE)
