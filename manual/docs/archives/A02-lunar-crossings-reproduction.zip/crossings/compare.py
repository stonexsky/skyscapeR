from pathlib import Path
import numpy as np
import pandas as pd
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq
profiles={'flat 0':lambda a:0.,'level 5':lambda a:5.,'undulating':lambda a:4+3*np.sin(np.deg2rad(2*a+30))}
def direction(az,alt):
    a,h=np.deg2rad([az,alt])
    return np.array([np.cos(h)*np.sin(a),np.cos(h)*np.cos(a),np.sin(h)]).T
def hybrid(g):
    H,d,p=np.deg2rad([15*g['last']-g.matched_ra,g.matched_dec,g.lat])
    return np.array([-np.cos(d)*np.sin(H),np.cos(p)*np.sin(d)-np.sin(p)*np.cos(d)*np.cos(H),np.sin(p)*np.sin(d)+np.cos(p)*np.cos(d)*np.cos(H)]).T
def crossings(t,v,site):
    spline=CubicSpline(t,v,axis=0)
    def angles(x):
        e,n,u=spline(x).T
        return np.rad2deg(np.arctan2(e,n))%360,np.rad2deg(np.arctan2(u,np.hypot(e,n)))
    roots=[]
    terrain=site=='Kuncizzjoni'
    grid=np.arange(0,t[-1]+.01,10.) if terrain else t
    if terrain:
        q=pd.read_csv('kuncizzjoni.csv').sort_values('az')
        shapes={'Kunċizzjoni archived skyline':lambda a:np.interp(a,q.az,q.alt,period=360)}
    else:
        shapes=profiles
    for profile,height in shapes.items():
        def clearance(x):
            az,alt=angles(x)
            return alt-height(az)
        clearance_t=clearance(grid)
        for i in np.flatnonzero(np.signbit(clearance_t[:-1])!=np.signbit(clearance_t[1:])):
            r=brentq(clearance,grid[i],grid[i+1]);a,h=angles(r)
            roots.append(dict(profile=profile,event='rise' if clearance_t[i]<0 else 'set',elapsed_s=r,az=a,alt=h))
    return roots
def run():
    rows=[]
    for (site,y),g in pd.read_csv('directions.csv').groupby(['site','year']):
        t=(g.jd-g.jd.iloc[0]).to_numpy()*86400
        assert len(t)==433 and np.max(abs(np.diff(t)-600))<.001
        series={'Horizons':direction(g.az,g.alt),'package':direction(g.package_az,g.package_alt),'clock':direction(g.clock_az,g.clock_alt),'matched':direction(g.matched_az,g.matched_alt),'hybrid':hybrid(g)}
        for step in [1,2]:
            for mode,v in series.items():
                rows.extend(dict(site=site,year=y,start_jd=g.jd.iloc[0],mode=mode,step_min=10*step,**r) for r in crossings(t[::step],v[::step],site))
    events=pd.DataFrame(rows);events.to_csv('events.csv',index=False)
    blocks=['site','year','profile','event','step_min']
    residuals=[]
    for k,g in events.groupby(blocks):
        ref=g[g['mode']=='Horizons']
        for mode in ['package','clock','matched','hybrid']:
            others=g[g['mode']==mode];seen=set()
            for o in others.itertuples():
                ds=abs(ref.elapsed_s-o.elapsed_s)
                if ds.min()>1800 or ds.empty: raise ValueError(('unpaired',k,mode,o))
                q=ref.loc[ds.idxmin()];assert q.name not in seen;seen.add(q.name)
                residuals.append(dict(zip(blocks,k),mode=mode,reference_jd=o.start_jd+q.elapsed_s/86400,reference_az=q.az,site_time_s=o.elapsed_s,Horizons_time_s=q.elapsed_s,time_error_s=o.elapsed_s-q.elapsed_s,az_error_deg=(o.az-q.az+180)%360-180))
            if len(seen)!=len(ref):raise ValueError(('missing',k,mode))
    pd.DataFrame(residuals).to_csv('differences.csv',index=False)
if __name__=='__main__':run()
