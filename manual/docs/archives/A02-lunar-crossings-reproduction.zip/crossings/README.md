# A02 supplement · Lunar skyline crossings

The entry point is A02-lunar-crossings.html. R 4.3.3, skyscapeR 2.0.9004, swephR 0.3.2, Swiss Ephemeris 2.10.03, compressed DE441. Use the ten external ephemeris files identified in manifest-441.csv (source URLs and SHA-256). The tested package build and documented public wrapper belong to the original A02 validation. Python requires numpy, scipy, pandas 2.2+ and matplotlib.

Run from this directory:

    python verify_files.py 441 /path/to/de441
    python fetch.py
    SE_EPHE_PATH=/path/to/de441 Rscript swiss.R
    python compare.py
    python verify_roots.py
    python report.py

Cached JPL Horizons API text and original URLs in raw/ allow offline reconstruction. Remove selected replies to requery the service. Each start epoch is noon UT in the proleptic Gregorian calendar, expressed to the service as a numeric JD. Use archived files to reproduce the published version. reference.csv uses the observer-table JD (UT1 before 1962, UTC after). directions.csv appends Swiss horizontal positions and equatorial directions in degrees. Column last is local apparent sidereal time in hours, dt is TDB minus Horizons UT in seconds, dut is UT1−UTC, or zero for UT1 epochs. Sites use east-positive longitude and geodetic latitude (degrees), height in km. swiss.R converts to metres. Crossings use centre of Moon, airless, and a fixed observer.

events.csv contains each independently solved crossing and the sampling step. differences.csv pairs each crossing by site, epoch, skyline, rise/set and nearest reference time, one to one within 30 minutes. Every event paired. Residuals are model minus Horizons. site_time_s and Horizons_time_s are elapsed seconds since the common window opening. Different profiles applied to one lunar passage are repeated observations of that passage. The hybrid control converts the Swiss apparent topocentric RA and Dec using Horizons local apparent sidereal time and the standard equatorial-to-horizontal rotation. It is diagnostic only. Matching ΔT uses Horizons TDB−UT1 as an approximation to TT−UT1. This study uses a separate common root solver on body.position() directions; the public riseset() solver is outside its scope.

The archived terrain curve is element 27 of skyscapeR::malta_horizons, constructed by Tore Lomsdalen with Andrew Smith's Horizon. kuncizzjoni.csv reproduces the 0.01° azimuth samples of that curve (360° duplicates excluded). Its own observer metadata give 35.90085° N, 14.34014° E, 158.3 m. The three-location synthetic test and the archived-viewpoint test are distinct. No field observations enter the comparison.

Original A02 report: https://chatgpt.com/library?file_id=libfile_d04d9dbb171c81918b23cb2035fe63aa&account_id=personal
JPL Horizons documentation: https://ssd.jpl.nasa.gov/horizons/manual.html
Swiss Ephemeris sidereal-time documentation: https://www.astro.com/swisseph/swisseph.htm
