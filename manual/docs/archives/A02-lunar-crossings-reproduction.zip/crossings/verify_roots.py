"""Check interpolated event roots against fresh Horizons positions at their times."""
from pathlib import Path
from urllib.parse import urlsplit,parse_qs,urlencode
from urllib.request import urlopen
import csv,io
import numpy as np
import pandas as pd
from compare import profiles
events=pd.read_csv('events.csv')
sel=events.query("mode=='Horizons' and step_min==10 and year==-3499")
results=[]
profile=pd.read_csv('kuncizzjoni.csv')
for site,grp in sel.groupby('site'):
    p=Path('raw',f'{site}-rootcheck.txt')
    u=urlsplit(Path('raw',f'{site}--3499.url').read_text())
    q=parse_qs(u.query)
    for x in ['START_TIME','STOP_TIME','STEP_SIZE']:q.pop(x)
    epochs=grp.start_jd+grp.elapsed_s/86400
    q.update(TLIST=["'"+','.join(f'{t:.10f}' for t in sorted(epochs))+"'"],TLIST_TYPE=["'JD'"])
    url=u._replace(query=urlencode(q,doseq=True)).geturl()
    if not p.exists():p.write_bytes(urlopen(url,timeout=45).read())
    p.with_suffix('.url').write_text(url)
    data=list(csv.reader(io.StringIO(p.read_text().split('$$SOE')[1].split('$$EOE')[0].strip())))
    assert len(data)==len(grp)
    for row,(_,r) in zip(data,grp.assign(t=epochs).sort_values('t').iterrows()):
        jd,az,alt=map(float,[row[1],row[4],row[5]])
        assert abs(jd-r.t)<1e-8
        height=profiles[r.profile](az) if r.profile in profiles else np.interp(az,profile.az,profile.alt,period=360)
        results.append(dict(site=site,jd=jd,profile=r.profile,event=r.event,clearance_arcsec=(alt-height)*3600))
pd.DataFrame(results).to_csv('root-check.csv',index=False)
print(len(results),max(abs(r['clearance_arcsec']) for r in results))
