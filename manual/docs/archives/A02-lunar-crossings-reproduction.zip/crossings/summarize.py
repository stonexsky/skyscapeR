from pathlib import Path
import numpy as np
import pandas as pd
def summarize():
    diff=pd.read_csv('differences.csv')
    group=['site','year','mode','event','profile']
    diff=diff.sort_values(group+['step_min','reference_jd'])
    diff['sequence']=diff.groupby(group+['step_min']).cumcount()
    coarse=diff[diff.step_min==20];fine=diff[diff.step_min==10].copy()
    pair=fine.merge(coarse,on=group+['sequence'],validate='one_to_one',suffixes=('_10','_20'));assert len(pair)==len(fine)==len(coarse)
    check={c:float((pair[c+'_10']-pair[c+'_20']).abs().max()) for c in ['time_error_s','az_error_deg','site_time_s','Horizons_time_s']}
    fine['period']=np.where(fine.year<0,'Prehistoric','1900–2025')
    fine['abs_az']=abs(fine.az_error_deg);fine['abs_time_min']=abs(fine.time_error_s)/60
    def summary(g):
        return pd.Series({'Events':len(g),'Median |Δaz| (°)':g.abs_az.median(),'Maximum |Δaz| (°)':g.abs_az.max(),'Median |Δt| (min)':g.abs_time_min.median(),'Maximum |Δt| (min)':g.abs_time_min.max()})
    result=fine.groupby(['period','mode']).apply(summary,include_groups=False)
    byyear=fine.groupby(['period','year','mode']).apply(summary,include_groups=False)
    sites=fine.groupby(['period','site','profile','mode','event']).apply(summary,include_groups=False)
    result.to_csv('summary.csv');sites.to_csv('by-site-profile-event.csv');byyear.to_csv('by-year.csv')
    print(result.to_string());print('grid check',check)
    return fine,result,sites,check
if __name__=='__main__':summarize()
