from pathlib import Path
import pandas as pd, numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from zipfile import ZipFile,ZIP_DEFLATED

def julian_day(j):
    if pd.isna(j):return ''
    c=int(np.floor(j+.5))+32082
    d=(4*c+3)//1461;e=c-(1461*d)//4
    m=(5*e+2)//153
    day=e-(153*m+2)//5+1;month=m+3-12*(m//10);y=d-4800+m//10
    return f'{abs(y) if y>0 else 1-y:04d}-{month:02d}-{day:02d} '+('CE' if y>0 else 'BCE')
ph=pd.read_csv('phases.csv');refined=pd.read_csv('refined.csv')
r=[]
for i,g in ph.iterrows():
 row=dict(site=g.site,epoch=f'{1-g.year} BCE' if g.year<=0 else f'{g.year} CE',astronomical_year=g.year,star=g.star,
          sample='main' if i<80 else 'Mnajdra follow-up',phase_class=g.phase_class,
          phases_local_date_Julian=julian_day(g.phase_jd),phases_date_JD_code=g.phase_jd)
 if pd.notna(g.phase_jd):
    v=pd.read_csv(f'daily/{i+1:03d}.csv')
    for _,adj in refined[refined.i==i+1].iterrows():
        v.loc[v.offsets==adj.offset,adj.curve]=adj.direct
    for col,label in [('margin','calibrated')]:
      for lim in ([5.5,6,6.5] if col=='margin' else [6]):
       ok=v[col]>=6-lim
       if not ok.any():
        continue
       edges=np.flatnonzero((~ok.to_numpy()[:-1]) & ok.to_numpy()[1:])+1
       if len(edges)!=1 or not ok.iloc[edges[0]:edges[0]+3].all():continue
       ix=edges[0]
       off=int(v.iloc[ix].offsets)
       if lim==6:
        row[label+'_days']=off
        row[label+'_date_Julian']=julian_day(g.phase_jd+off)
        row[label+'_date_JD_code']=g.phase_jd+off
       else:row['calibrated_days_at_limit_'+str(lim)]=off
 r.append(row)
out=pd.DataFrame(r)
out.to_csv('Heliacal-rising-results.csv',index=False)
