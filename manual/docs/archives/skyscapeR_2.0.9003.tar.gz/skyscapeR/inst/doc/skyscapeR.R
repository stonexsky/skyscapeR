## ----setup, include=FALSE-----------------------------------------------------
spreadsheet_examples <- requireNamespace("readxl", quietly = TRUE)
# Accept file-backed positions from either swephRdata or SE_EPHE_PATH.
covers_years <- function(years) {
  tryCatch({
    skyscapeR::star("Aldebaran", year = years)
    TRUE
  }, skyscapeR_ephemeris_error = function(e) FALSE)
}
astronomy_examples <- covers_years(c(-3399L, -3099L, 2016L, 2026L))
epoch_examples <- astronomy_examples && covers_years(c(-3999L, -1999L))
knitr::opts_chunk$set(error = FALSE, collapse = TRUE, comment = "#>",
                      fig.width = 7, fig.height = 4,
                      out.width = "100%", fig.align = "center")

## ----own-file, eval=FALSE-----------------------------------------------------
#  library(skyscapeR)
#  survey <- readxl::read_excel("/Users/yourname/Research/field-survey.xlsx", sheet = "Compass")

## ----load-example, include=FALSE----------------------------------------------
library(skyscapeR)
if (spreadsheet_examples) survey <- readxl::read_excel(system.file("extdata", "field-survey.xlsx", package="skyscapeR"), sheet="Compass")

## ----show-survey, eval=spreadsheet_examples-----------------------------------
survey

## ----reduce-survey, eval=spreadsheet_examples, message=FALSE------------------
locations <- as.matrix(survey[c("latitude", "longitude", "elevation_m")])
compass <- reduct.compass(loc = locations, mag.az = survey$mag_az_deg,
                          date = as.Date(survey$survey_date), ID = survey$id)
compass[c("ID", "Magnetic.Azimuth", "Mag.Dec", "True.Azimuth")]

## ----solar-sight, eval=astronomy_examples, message=FALSE----------------------
library(skyscapeR)
site_location <- c(51.18, -1.83, 105)
theo <- reduct.theodolite(loc = site_location, az = c(298.40, 302.35),
                          date = "2016/02/20", time = "11:07:17",
                          tz = "Europe/London", az.sun = ten(327, 29, 50),
                          limb = "right")
theo$Altitude <- c(2, 5)  # Horizon altitudes measured along the two sightlines
theo[c("Uncorrected.Azimuth", "Sun.Az", "True.Azimuth", "Altitude")]

## ----compass-decs, eval=spreadsheet_examples----------------------------------
survey$true_az_deg <- compass$True.Azimuth %% 360
survey$dec_deg <- az2dec(survey$true_az_deg, loc = survey$latitude,
                         alt = survey$horizon_alt_deg)
survey[c("id", "true_az_deg", "horizon_alt_deg", "dec_deg")]

## ----theo-decs, eval=astronomy_examples---------------------------------------
theo$Declination <- az2dec(theo$True.Azimuth, loc = theo$Latitude, alt = theo$Altitude)
theo[c("True.Azimuth", "Altitude", "Declination")]

## ----own-targets, eval=spreadsheet_examples && astronomy_examples-------------
candidates <- findTargets(survey$dec_deg[1] + c(-2, 2), c("3400 BC", "3200 BC"))
candidates$stellar

## ----entrance-----------------------------------------------------------------
door <- malta_entrances[1, ]
door[, c("Name", "Latitude", "Longitude", "Az L", "Az R")]
edges <- c(door[["Az L"]], door[["Az R"]])
door_frame <- c(edges[1], mean(edges), edges[2])

## ----surveyed, eval=FALSE-----------------------------------------------------
#  profile <- read.csv("/Users/yourname/Research/surveyed-horizon.csv")
#  survey_location <- c(51.18, -1.83, 105)  # latitude, longitude, elevation in metres
#  surveyed <- createHor(az = profile$azimuth, alt = profile$altitude,
#                        loc = survey_location)
#  plot(surveyed)

## ----photo, eval=FALSE--------------------------------------------------------
#  photo <- importPanorama("doorway-east.png", loc = survey_location,
#                          az.lim = c(75, 115), alt.lim = c(-5, 10), calibrate = TRUE)
#  plot(photo, show.skyline = TRUE)

## ----hwt, eval=FALSE----------------------------------------------------------
#  hwt <- createHWT(lat = door$Latitude, lon = door$Longitude,
#                   elevation = 1.6, name = "Mnajdra South")

## ----peakfinder, eval=FALSE---------------------------------------------------
#  pf <- importPeakFinder("landscape.zip", svg = "panorama.svg")

## ----local-dem, eval=FALSE----------------------------------------------------
#  terrain <- createHor(dem = "survey-dem.tif", loc = c(door$Latitude, door$Longitude),
#                       eye.height = 1.6, max.distance = 10000, image.dir = tempdir())
#  plot(terrain)

## ----door-horizon-------------------------------------------------------------
hor <- malta_horizons[[1]]
hor2alt(hor, edges)
plot(hor, xrange = c(75, 115))
abline(v = door_frame, col = "firebrick", lty = c(1, 2, 1))
door_dec <- az2dec(edges, loc = hor)

## ----door-targets, eval=astronomy_examples------------------------------------
period <- c("3400 BC", "3100 BC")
targets <- findTargets(range(door_dec), period)
targets$solar
targets$stellar

## ----equinox, eval=astronomy_examples-----------------------------------------
year <- "3250 BC"
sun <- riseset(hor, date = "3250 BC/04/17", obj = "sun",
               calendar = "J", timezone = "UTC")$rise
sun
sky <- sketchSky(hor, time = paste(sun$date, sun$time), calendar = "J", timezone = "UTC")
equinox <- skyObject("Equinox", year = year, loc = hor, col = "steelblue", lty = 3)
sunrise_track <- skyObject(sun$declination, year = year, loc = hor, col = "orange")
plot(hor, sky = sky, obj = list(equinox, sunrise_track), xrange = c(85, 105))
abline(v = door_frame, col = "firebrick", lty = c(1, 2, 1))

## ----phase-circle, eval=astronomy_examples, fig.height=7----------------------
phases <- star.phases("M 45", year, hor)
plot(phases)
events <- phases$metadata$events
hr_date <- events$date.julian[events$event == "heliacal rising"]
hr_date

## ----phase-linear, eval=astronomy_examples------------------------------------
plot(phases, layout = "linear")

## ----cluster-rise, eval=astronomy_examples------------------------------------
rise <- riseset(hor, date = hr_date, obj = "M 45", calendar = "J", timezone = "UTC")$rise
rise
rise_jd <- time2jd(paste(rise$date, rise$time), timezone = "UTC", calendar = "J")
sky <- sketchSky(hor, jd = rise_jd + 5 / 1440)
plot(hor, sky = sky, xrange = c(85, 105))
abline(v = door_frame, col = "firebrick", lty = c(1, 2, 1))

## ----alcyone-dawn, eval=astronomy_examples------------------------------------
alcyone <- star.phases("Alcyone", year, hor)
events <- alcyone$metadata$events
date <- events$date.julian[events$event == "heliacal rising"]
alcyone_rise <- riseset(hor, date = date, obj = "Alcyone", calendar = "J", timezone = "UTC")$rise
jd <- time2jd(paste(alcyone_rise$date, alcyone_rise$time), timezone = "UTC", calendar = "J")
sky <- sketchSky(hor, jd = jd + 16 / 1440)
plot(hor, sky = sky, xrange = c(85, 105), yrange = c(0, 11))
abline(v = door_frame, col = "firebrick", lty = c(1, 2, 1))

## ----later-rise, eval=astronomy_examples--------------------------------------
later <- riseset(hor, jd = rise_jd + 60, obj = "M 45", calendar = "J", timezone = "UTC")$rise
sky <- sketchSky(hor, time = paste(later$date, later$time), calendar = "J", timezone = "UTC")
sector <- c(85, 105)
plot(hor, sky = sky, xrange = sector, yrange = c(0, 11))
abline(v = door_frame, col = "firebrick", lty = c(1, 2, 1))

## ----later-step, eval=astronomy_examples--------------------------------------
sky <- skyStep(hor, sky, minutes = 10, xrange = sector, yrange = c(0, 11))
abline(v = door_frame, col = "firebrick", lty = c(1, 2, 1))

## ----group-bearings, fig.height=7---------------------------------------------
rows <- which(malta_entrances$Phase == "Ggantija")
sites <- malta_entrances[rows, ]
profiles <- malta_horizons[rows]
width <- (sites[["Az R"]] - sites[["Az L"]]) %% 360
centre <- (sites[["Az L"]] + width / 2) %% 360
plotAzimuth(centre)

## ----compass-targets, eval=astronomy_examples, fig.height=7-------------------
solstices <- skyObject("solar extremes", year = year, loc = hor)
plotAzimuth(centre, obj = solstices, marks = "rim", obj.position = "outside")

## ----group-opening-widths-----------------------------------------------------
plotBars(centre, unc = width / 2, names = sites$Name, unit = "Azimuth")

## ----group-decs---------------------------------------------------------------
bearings <- az.pdf(pdf = "uniform", az = centre, unc = width / 2, name = sites$Name)
decs <- coordtrans(bearings, profiles)
plot(spd(decs))

## ----linked-doorway-----------------------------------------------------------
plot(decs, index = 1, az = bearings, hor = profiles, hdr = 0.68)

## ----random-null, eval=FALSE--------------------------------------------------
#  set.seed(42)
#  fit <- randomTest(decs, az = bearings, hor = profiles, nsims = 500)

## ----random-result------------------------------------------------------------
fit <- readRDS(system.file("extdata", "ggantija-random-500.rds", package = "skyscapeR"))
plot(fit, show.local = TRUE)
fit$metadata$local.pval

## ----peak-targets, eval=astronomy_examples------------------------------------
bands <- fit$metadata$local.pval
peak <- subset(bands, type == "+" & p.value < 0.05)
candidates <- findTargets(c(peak$start, peak$end), period)
candidates$stellar

## ----gacrux, eval=astronomy_examples------------------------------------------
gacrux <- skyObject("Gacrux", year = period)
plot(fit, obj = gacrux, show.local = TRUE)

## ----gacrux-rise, eval=astronomy_examples-------------------------------------
i <- which(sites$Name == "Skorba West")
site_hor <- profiles[[i]]
opening <- c(sites[["Az L"]][i], sites[["Az R"]][i])
g_phases <- star.phases("Gacrux", year, site_hor)
g_events <- g_phases$metadata$events
g_date <- g_events$date.julian[g_events$event == "heliacal rising"]
g_rise <- riseset(site_hor, date = g_date, obj = "Gacrux",
                  calendar = "J", timezone = "UTC")$rise
g_rise
g_jd <- time2jd(paste(g_rise$date, g_rise$time), timezone = "UTC", calendar = "J")
sky <- sketchSky(site_hor, jd = g_jd + 20 / 1440)
plot(site_hor, sky = sky, xrange = c(122, 144), yrange = c(-1, 10))
abline(v = c(opening[1], mean(opening), opening[2]), col = "firebrick", lty = c(1, 2, 1))

## ----sky-styles, eval=astronomy_examples, fig.show="hold", fig.cap=c("Natural", "Publication colour", "Publication monochrome")----
sector <- c(0, 180)
heights <- c(-5, 85)
when <- "2026/12/21 20:00"

natural <- sketchSky(hor, time = when, timezone = "UTC", style = "natural")
plot(hor, sky = natural, xrange = sector, yrange = heights)

colour <- sketchSky(hor, time = when, timezone = "UTC", style = "publication-colour")
plot(hor, sky = colour, xrange = sector, yrange = heights)

mono <- sketchSky(hor, time = when, timezone = "UTC", style = "publication-mono")
plot(hor, sky = mono, xrange = sector, yrange = heights)

## ----compare-epochs, eval=epoch_examples, fig.height=7------------------------
ald <- lapply(c("4000 BC", "3250 BC", "2000 BC"),
              function(y) star.phases("Aldebaran", y, hor))
plot(ald[[1]], ald[-1])

## ----epoch-strips, eval=epoch_examples----------------------------------------
plot(ald[[1]], ald[-1], layout = "linear")

## ----star-strips, eval=astronomy_examples-------------------------------------
stars <- lapply(c("Aldebaran", "M 45", "Gacrux"),
                function(s) star.phases(s, year, hor))
plot(stars[[1]], stars[-1], layout = "linear")

## ----star-epoch-strips, eval=epoch_examples-----------------------------------
gacrux <- lapply(c("4000 BC", "2000 BC"),
                 function(y) star.phases("Gacrux", y, hor))
pair <- c(ald[c(1, 3)], gacrux)
plot(pair[[1]], pair[-1], layout = "linear")

## ----western-sky, eval=astronomy_examples, fig.cap="Modern Western constellations above the eastern horizon at Mnajdra South."----
sky <- sketchSky(hor, time = when, timezone = "UTC", style = "publication-colour",
                 display = list(constellations = "modern"))
plot(hor, sky = sky, xrange = sector, yrange = heights)

## ----chinese-constellations, eval=astronomy_examples, fig.cap="Chinese lunar-mansion asterisms visible in the same eastern sky."----
sky <- sketchSky(hor, time = when, timezone = "UTC", style = "publication-colour",
                 display = list(constellations = "chinese_mansions"))
plot(hor, sky = sky, xrange = sector, yrange = heights)

## ----custom-constellations, eval=FALSE----------------------------------------
#  my_figures <- importConstellations("my-constellationship.fab")
#  # Subset rows here if only some figures should be drawn.
#  sky <- sketchSky(hor, time = "2026/12/21 20:00", timezone = "UTC",
#                   display = list(constellations = my_figures))
#  plot(hor, sky = sky, xrange = sector)
#  abline(v = door_frame, col = "firebrick", lty = c(1, 2, 1))

## ----mnajdra-twilight, eval=astronomy_examples, fig.cap=c("Civil twilight towards sunset at Mnajdra South on 1 February 2025, 16:40 UTC.", "The Belt of Venus above the opposite horizon at the same instant.")----
dusk <- sketchSky(hor, time = "2025/02/01 16:40", timezone = "UTC",
                  style = "natural", display = list(moon = FALSE))
plot(hor, sky = dusk, xrange = c(211, 291), yrange = c(-3, 37))
plot(hor, sky = dusk, xrange = c(31, 111), yrange = c(-3, 37))
abline(v = door_frame, col = "firebrick", lty = c(1, 2, 1))

## ----efm, eval=astronomy_examples---------------------------------------------
full_moon <- EFM(year = 2026, loc = c(40, 0, 400), season = "spring", timezone = "UTC")
full_moon$Moon
full_moon$Sun

## ----cc, eval=astronomy_examples----------------------------------------------
crescent <- CC(year = 2026, loc = c(40, 0, 400), season = "winter", crescent = "first",
               timezone = "UTC", simulation = "SIM1")
crescent$Moon
crescent$diagnostics[, c("status", "visibility.margin", "day.offset")]

## ----planisphere, eval=astronomy_examples, fig.height=7-----------------------
planisphere(year, lat = door$Latitude, max.mag = 3, show.galactic.equator = TRUE)

## ----planisphere-mansions, eval=astronomy_examples, fig.height=7, fig.cap="Chinese lunar-mansion asterisms on the planisphere for Mnajdra South's latitude and the chosen epoch."----
planisphere(year, lat = door$Latitude, max.mag = 3,
            show.galactic.equator = TRUE, constellations = "chinese_mansions")

