Run sector.R to test partial and complete horizon coverage.
