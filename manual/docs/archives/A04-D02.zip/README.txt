Run A04.R, A04-full.R, D02.R and D02-full.R with Rscript. Run python3 D02-reference.py to produce independent quadrature and Sobol comparisons.
Run with skyscapeR 2.0.9016. Run commands in the extracted directory.
