library(skyscapeR)
skyscapeR.vars(refraction=FALSE)
h <- list(createHor(az=c(0,90,180,270,360),alt=c(1,4,1,2,1),alt.unc=.5,loc=c(-11,-77,0),verbose=FALSE),
          createHor(az=c(0,90,180,270,360),alt=c(2,1,3,2,2),alt.unc=.4,loc=c(35,-8,100),verbose=FALSE))
x <- c(20,65,114,193,295)
for (kind in c("shared","paired")) {
 rows <- list()
 for(j in 1:2) for(a in x){
   site <- h[[if(kind=="shared") 1 else j]]
   p <- az.pdf(a,j,.res=.5,verbose=FALSE)
   d <- coordtrans(p,site,.res=.1,.prec=.5,.output.res=.1,verbose=FALSE)
   rows[[length(rows)+1]] <- spd(d,.res=1,xrange=c(-90,90))$data$y
 }
 writeBin(as.double(t(do.call(rbind,rows))),paste0(kind,".bin"),endian="little")
}
# Check the cached calculation against the public route with exactly the same draws.
idx <- rep(1:2,4)
hs <- h[idx]
w <- lapply(idx,function(j) if(j==1)c(1,2,4,2,1) else c(4,1,1,1,3))
m <- lapply(w,function(z)data.frame(x=x,w=z))
set.seed(201)
obs <- vapply(w,function(z)sample.int(5,1,prob=z),integer(1))
set.seed(502)
draw <- t(replicate(39,vapply(w,function(z)sample.int(5,1,prob=z),integer(1))))
a <- az.pdf(x[obs],idx,.res=.5,verbose=FALSE)
set.seed(502)
fit <- modelTest(a,m,hor=hs,nsims=39,ncores=1,.res=1,.prec=.5,.output.res=.1,verbose=FALSE)
kernels<-matrix(readBin("paired.bin","double",181*10,endian="little"),nrow=10,byrow=TRUE)
mm<-t(apply(rbind(obs,draw),1,function(ids)colSums(kernels[(idx-1)*5+ids,,drop=FALSE])))
stopifnot(max(abs(fit$data$empirical$y-mm[1,]))<1e-12)
writeBin(as.double(t(mm)),"public.bin",endian="little")
write.csv(data.frame(global=fit$metadata$global.pval,local=min(c(1,fit$metadata$local.pval$p.value))),"public.csv",row.names=FALSE)
