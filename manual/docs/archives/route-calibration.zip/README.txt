Run Rscript kernels.R, then python3 calibrate.py. Repeat with CALIBRATION_SEED=93276 and CALIBRATION_OUTPUT=rates-repeat.csv. The primary seed is 13350. Requires NumPy, pandas, SciPy and g++.
Run with skyscapeR 2.0.9016. Run commands in the extracted directory.
