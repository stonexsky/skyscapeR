suppressPackageStartupMessages(library(skyscapeR))
skyscapeR.vars(refraction=FALSE)
h<-createHor(az=c(0,65,85,92,104,360),alt=c(2,2,10,1,4,2),alt.unc=.6,loc=c(45,0,0),verbose=FALSE)
a<-az.pdf(c(88,95),c(4,2),.res=.25,verbose=FALSE)
p<-coordtrans(a,h,.res=.1,.prec=.1,.output.res=.05,verbose=FALSE)
m<-list(data.frame(x=c(-18,-4,10),w=c(1,3,2)),data.frame(x=c(-12,7,22),w=c(2,1,4)))
set.seed(22);draws<-replicate(19,skyscapeR:::sampleList(m))
centre<-function(d){
 f<-approxfun(d$x,d$y)
 # Integrate independent affine segments by Simpson's rule, exact for x*f.
 l<-head(d$x,-1);u<-tail(d$x,-1);mid<-(l+u)/2
 sum((u-l)*(l*f(l)+4*mid*f(mid)+u*f(u)))/sum((u-l)*(f(l)+4*f(mid)+f(u)))
}
expected<-function(draw){
 Reduce('+',Map(function(d,v){
  approx(d$x-centre(d)+v,d$y,xout=-90:90,yleft=0,yright=0)$y
 },p$data,draw))
}
trace(".simulation_inference",where=asNamespace("skyscapeR"),print=FALSE,tracer=quote(assign("captured",memory,.GlobalEnv)))
rows<-list()
for(mode in c("shift","explicit")){
 set.seed(22)
 args<-list(pdf=p,model=m,nsims=19,ncores=1,.res=1,verbose=FALSE)
 if(mode=="explicit")args$unc<-c(3,5)
 f<-do.call(modelTest,args)
 refs<-if(mode=="shift")t(apply(draws,2,expected)) else t(apply(draws,2,function(v)spd(dec.pdf(v,c(3,5),verbose=FALSE),xrange=c(-90,90),.res=1)$data$y))
 rows[[mode]]<-data.frame(mode,error=max(abs(refs-captured)))
}
untrace(".simulation_inference",where=asNamespace("skyscapeR"))
r<-do.call(rbind,rows);write.csv(r,'transformed-checks.csv',row.names=FALSE);stopifnot(all(r$error<1e-10))
