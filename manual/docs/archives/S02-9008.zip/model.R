suppressPackageStartupMessages(library(skyscapeR))
source("same.R")
stopifnot(all(read.csv("same-2.0.9008.csv")$error==0))
rows<-list()
check<-function(case,err,tol) {rows[[length(rows)+1]]<<-data.frame(case,err,tol,pass=is.finite(err)&&err<=tol)}
decX<-c(-42,-18,-7,11,32)
azX<-c(0,22,89,184,311)
weights<-list(c(1,2,4,2,1),c(4,1,1,1,3))
# Each number is probability mass at its candidate, including on uneven grids.
set.seed(288);draws<-replicate(50000,skyscapeR:::sampleList(lapply(weights,function(w)data.frame(x=decX,w))))
for(k in 1:2)check(paste("weight frequency",k),max(abs(tabulate(match(draws[k,],decX),5)/ncol(draws)-weights[[k]]/10)),.012)
# Two asymmetric piecewise-linear, unit-area templates centred independently
# by numerical quadrature. Unequal shapes and widths preserve site pairing.
shapes<-lapply(1:2,function(k){
 xx<-c(-4,-2,0,1,4,7)*k; yy<-c(0,1,4,3,1,0)
 f<-approxfun(xx,yy)
 mass<-sum(sapply(seq_len(length(xx)-1),function(j)integrate(f,xx[j],xx[j+1])$value))
 first<-sum(sapply(seq_len(length(xx)-1),function(j)integrate(function(x)x*f(x),xx[j],xx[j+1])$value))
 data.frame(x=xx-first/mass,y=yy/mass)
})
for(route in c("az","dec","shape","override")){
 candidates<-if(route=="az")azX else decX
 coord<-if(route=="az")"az" else "dec"
 xr<-if(coord=="az")c(0,360) else c(-90,90)
 ctor<-if(coord=="az")az.pdf else dec.pdf
 mk<-function(v,k){
  if(route=="shape"){
   curve<-shapes[[k]];curve$x<-curve$x+v
   return(structure(list(metadata=list(coord="dec"),data=list(curve)),class="skyscapeR.pdf"))
  }
  ctor(v,c(3,5)[k],.res=.5,.cutoff=.002,verbose=FALSE)
 }
 bank<-do.call(rbind,lapply(1:2,function(k)do.call(rbind,lapply(candidates,function(v)spd(mk(v,k),xrange=xr,.res=1)$data$y))))
 writeBin(as.double(t(bank)),paste0(route,".bin"),endian="little")
 for(k in 1:2)for(i in seq_along(candidates)){
  p<-mk(candidates[i],k)
  if(route=="shape"){
   tt<-skyscapeR:::.declination_template(p$data[[1]])
   check("asymmetric shape and centre",max(abs(tt$x-shapes[[k]]$x),abs(tt$y-shapes[[k]]$y)),1e-12)
  }
 }
 ix<-c(2,4,1,5,2,3,1,4)
 keys<-rep(1:2,4)
 p<-mk(candidates[ix[1]],1)
 p$data<-Map(function(i,k)mk(candidates[i],k)$data[[1]],ix,keys)
 if(route!="shape"){
   p$metadata$unc<-c(3,5)[keys];p$metadata[[coord]]<-candidates[ix];p$metadata$name<-paste0("m",1:8)
 }
 models<-lapply(keys,function(k)data.frame(x=candidates,w=weights[[k]]))
 set.seed(901)
 ds<-rbind(ix,t(replicate(39,match(skyscapeR:::sampleList(models),candidates))))
 ns<-asNamespace("skyscapeR")
 trace(".simulation_inference",where=ns,print=FALSE,tracer=quote(assign("captured",rbind(observed$y,memory),envir=.GlobalEnv)))
 set.seed(901)
 fit<-if(route=="override")modelTest(p,models,unc=c(3,5)[keys],nsims=39,.res=1,ncores=1,verbose=FALSE) else modelTest(p,models,nsims=39,.res=1,ncores=1,verbose=FALSE)
 untrace(".simulation_inference",where=ns)
 rebuilt<-t(apply(ds,1,function(i)colSums(bank[(keys-1)*5+i,,drop=FALSE])))
 check(paste(route,"public curve matrix"),max(abs(captured-rebuilt)),1e-12)
 writeBin(as.double(t(captured)),paste0(route,"-public.bin"),endian="little")
 write.csv(data.frame(global=fit$metadata$global.pval,local=min(c(1,fit$metadata$local.pval$p.value))),paste0(route,"-public.csv"),row.names=FALSE)
 if(route=="shape"){
  m<-models;m[[1]]<-data.frame(x=89,w=1)
  msg<-tryCatch({modelTest(p,m,nsims=2,ncores=1,verbose=FALSE);""},error=conditionMessage)
  check("pole boundary rejection",as.integer(!grepl("outside",msg)),0)
 }
}
r<-do.call(rbind,rows);write.csv(r,"checks.csv",row.names=FALSE);stopifnot(all(r$pass))
