suppressPackageStartupMessages(library(skyscapeR))
d<-malta_entrances;xx<-seq(0,359.5,.5);w<-read.csv("wind-weights.csv");aspect<-read.csv("aspect.csv")
models<-list(wind=data.frame(x=xx,w=w$mass[1+floor(((xx-180+15)%%360)/30)]),winter=read.csv("winter-sun.csv"),
 aspect=lapply(seq_len(nrow(d)),function(i)data.frame(x=xx,w=Reduce('+',lapply(-1:1,function(k)dnorm(xx+360*k,aspect$mean[i],aspect$sd[i]))))))
width<-(d[['Az R']]-d[['Az L']])%%360
p<-az.pdf((d[['Az L']]+width/2)%%360,width/4,.res=.1,verbose=FALSE)
obs<-spd(p,xrange=c(0,360),.res=.5)$data
basis<-lapply(width/4,function(w)head(spd(az.pdf(0,w,.res=.1,verbose=FALSE),xrange=c(0,360),.res=.5)$data$y,-1))
out<-list()
for(key in names(models)){
 model<-models[[key]];if(is.data.frame(model))model<-rep(list(model),length(width))
 set.seed(2808)
 draws<-t(replicate(9999,skyscapeR:::sampleList(model)))
 # Score grid coincides with each candidate centre and is a multiple of
 # input spacing. A shift by k grid points rotates the exact package basis.
 m<-matrix(0,nrow=nrow(draws),ncol=721)
 for(j in seq_along(basis)){
  idx<-outer(-round(draws[,j]*2),0:720,"+")%%720+1
  m<-m+matrix(basis[[j]][idx],nrow=nrow(m))
 }
 z<-skyscapeR:::.simulation_inference(obs,499,list(1:499),character(),m[1:499,],.95,2,circular=TRUE)
 orig<-read.csv('malta-results.csv');stopifnot(z$global==orig$global[orig$model==key])
 original.local<-read.csv(paste0(key,"-local.csv"))
 stopifnot(isTRUE(all.equal(z$local,original.local,check.attributes=FALSE)))
 z<-skyscapeR:::.simulation_inference(obs,nrow(m),list(seq_len(nrow(m))),character(),m,.95,2,circular=TRUE)
 out[[key]]<-data.frame(model=key,n=length(width),B=nrow(m),global=z$global)
 write.csv(z$local,paste0(key,'-9999-local.csv'),row.names=FALSE)
 write.csv(do.call(rbind,out),"malta-9999.csv",row.names=FALSE)
}
