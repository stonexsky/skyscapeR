# Galdies (2011), Fig. 19. Convert measured sector radii to relative masses.
import fitz,numpy as np,pandas as pd
from PIL import Image
d=fitz.open('wind.pdf');p=d[27]
pm=p.get_pixmap(matrix=fitz.Matrix(1.8,1.8),clip=fitz.Rect(0,30,p.rect.width,415))
im=np.array(Image.frombytes('RGB',(pm.width,pm.height),pm.samples)).astype(float)
cy,cx=429.,412.;out=[]
for deg in range(0,360,30):
 r=np.arange(8,240);phi=np.deg2rad(deg)
 pix=im[np.rint(cy-r*np.cos(phi)).astype(int),np.rint(cx+r*np.sin(phi)).astype(int)]
 colour=(pix.max(1)-pix.min(1)>150)
 out.append((deg,float(r[colour].max())/9.8))
pd.DataFrame(out,columns=['wind_from','mass']).to_csv('wind-weights.csv',index=False)
