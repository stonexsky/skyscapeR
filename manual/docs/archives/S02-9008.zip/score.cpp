// Monte Carlo ranks for a matrix including the observation in row zero.
// Each column uses the pooled type-7 quantiles and the pooled sample SD.
#include <algorithm>
#include <cmath>
#include <vector>
#include <numeric>
struct Run { int count=0,sign=0; double mass=0; };
static double maximum(const std::vector<double>& z, bool circle,double step) {
    std::vector<Run> runs;
    for(double v:z) {
        int sign=(v>0)-(v<0);
        if(runs.empty() || runs.back().sign!=sign) runs.push_back({0,sign,0});
        runs.back().count++;
        runs.back().mass+=std::abs(v);
    }
    if(circle && runs.size()>1 && runs[0].sign==runs.back().sign) {
        runs[0].count+=runs.back().count;
        runs[0].mass+=runs.back().mass;
        runs.pop_back();
    }
    double best=0;
    for(const Run& r:runs) if(r.sign && r.count>1 && (r.count-1)*step>=0.5-2e-13)
        best=std::max(best,r.mass);
    return best;
}
extern "C" void ranks(const double* m,int n,int g,double step,int tails,int circle,double* output) {
    // A closing north sample is removed by the caller.
    std::vector<std::vector<double>> z(n,std::vector<double>(g,0));
    std::vector<double> v(n);
    const double high=(n-1)*(tails==2?.975:.95),low=(n-1)*.025;
    for(int j=0;j<g;j++) {
        for(int i=0;i<n;i++) v[i]=m[i*g+j];
        std::sort(v.begin(),v.end());
        if(v[0]==v[n-1]) continue;
        long double mean=std::accumulate(v.begin(),v.end(),(long double)0)/n,ss=0;
        for(double y:v)ss+=(y-mean)*(y-mean);
        double sd=std::sqrt(double(ss/(n-1)));
        if(sd==0) continue;
        auto quant=[&](double r){int k=int(r); return (1-(r-k))*v[k]+(r-k)*v[k+1];};
        double hi=quant(high),lo=quant(low);
        for(int i=0;i<n;i++) {
            double y=m[i*g+j];
            if(y>hi) z[i][j]=(y-hi)/sd;
            else if(tails==2 && y<lo) z[i][j]=(y-lo)/sd;
        }
    }
    std::vector<double> global(n),local(n);
    for(int i=0;i<n;i++) {
        long double above=0,below=0;
        for(double y:z[i]) {if(y>0) above+=y;else below-=y;}
        global[i]=double(above)+double(below);
        local[i]=maximum(z[i],circle,step);
    }
    for(int k=0;k<2;k++){
        const auto& scores=k?local:global;
        int b=1;
        for(int i=1;i<n;i++) if(scores[i]>=scores[0]) b++;
        output[k]=double(b)/n;
    }
}
