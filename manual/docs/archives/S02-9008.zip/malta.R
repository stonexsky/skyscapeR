suppressPackageStartupMessages(library(skyscapeR))
library(swephR)
d<-malta_entrances
xx<-seq(0,359.5,.5)
w<-read.csv("wind-weights.csv")
wind<-data.frame(x=xx,w=w$mass[1+floor(((xx-180+15)%%360)/30)])
# Reconstruct the published daylight-minute design at the mean temple location.
loc<-c(mean(d$Longitude),mean(d$Latitude),0)
swe_set_topo(loc[1],loc[2],0)
year<--2999
start<-swe_julday(year,9L,1L,0,0L)
longitude<-function(jd)swe_calc_ut(jd,0L,2L)$xx[1]
root<-function(target,lo,hi)uniroot(function(jd)(longitude(jd)-target+180)%%360-180,c(lo,hi),tol=1e-6)$root
autumn<-root(180,start-30,start+50);spring<-root(0,autumn+150,autumn+210)
jd<-seq(autumn,spring,by=1/1440)
b<-vapply(jd,function(t){
 e<-swe_calc_ut(t,0L,34818L);stopifnot(bitwAnd(e$return,7L)==2L)
 h<-swe_azalt(t,1L,loc,1013.25,15,e$xx[1:3])$xaz
 if(h[3]>=0)(h[1]+180)%%360 else NA_real_
},numeric(1))
sun<-data.frame(x=xx,w=tabulate(1+round(b[is.finite(b)]*2)%%720,720))
write.csv(sun,"winter-sun.csv",row.names=FALSE)
width<-(d[['Az R']]-d[['Az L']])%%360
p<-az.pdf((d[['Az L']]+width/2)%%360,width/4,.res=.1,name=d$Name,verbose=FALSE)
models<-list(wind=wind,winter=sun)
if(file.exists("aspect.csv")){
 a<-read.csv('aspect.csv')
 models$aspect<-lapply(seq_len(nrow(d)),function(i)data.frame(x=xx,w=Reduce('+',lapply(-1:1,function(k)dnorm(xx+360*k,a$mean[i],a$sd[i])))))
}
out<-list()
for(key in names(models)){
 set.seed(2808);fit<-modelTest(p,models[[key]],nsims=499,ncores=1,.res=.5,verbose=FALSE)
 out[[key]]<-data.frame(model=key,n=length(width),B=499,global=fit$metadata$global.pval)
 write.csv(fit$metadata$local.pval,paste0(key,'-local.csv'),row.names=FALSE)
}
write.csv(do.call(rbind,out),"malta-results.csv",row.names=FALSE)
