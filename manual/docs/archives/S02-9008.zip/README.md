# Specified and site-specific models (S02)

Use R with skyscapeR 2.0.9008 installed, Python with NumPy, pandas, SciPy and a C++17 compiler. Run in this directory:

    Rscript model.R
    Rscript transformed.R
    python calibrate.py

Each of 12 conditions uses 2,000 independent outer datasets and 39 new inner reference draws for eight observations. The candidate directions are unevenly spaced. The supplied weights are probability masses, not density heights. Uniform random variates and inverse cumulative probabilities generate the independent reference draws. The score implementation was previously checked in S01 and is directly compared with the current public modelTest() ranks and simulation matrices here. Results at 1%, 5% and 10% include pointwise Wilson 95% intervals. The 1% level is unattainable with 39 reference draws. The dependent alternative pairs the underlying random quantiles of observations while preserving their individual marginal models. The injected alternative fixes the first four of eight observations at the fourth candidate. These two settings measure different departures. Public replays also check explicit replacement uncertainties, shifting genuine coordtrans() profiles and rejection of pole-crossing templates.

## Maltese landscape models

Silva & Lomsdalen (2025), doi:10.1007/s12520-025-02208-4, Table 2, supplementary Table S1 and Fig. 4. All 64 entrance endpoints in malta_entrances match the supplementary table in order. The half-degree model grid, RNG seed, angular binning, inference and candidate weights here define a new reconstruction. The centre and SD of each measurement are respectively the midpoint and one quarter of the frame width. The original figures, random draws and model weights were not used as substitutes for a current calculation.

To rerun using the included reconstructed aspect summaries and wind weights, configure modern and prehistoric Swiss ephemeris files (SE_EPHE_PATH), then run:

    Rscript malta.R
    Rscript malta-rank.R

The second script first checks global and local probabilities against 499 simulations run through modelTest(), then scores 9,999 fresh-reference draws (including those first 499) using the same package scorer. The candidate grid coincides with the stored sum grid; this allows exact rotations of precomputed package measurement densities. Every observed local interval is in the corresponding CSV. Global resolution is 0.0001.

Wind weights were digitised from the 12 sectors of Fig. 19 of Galdies (2011), The Climate of Malta, https://nso.gov.mt/wp-content/uploads/The_Climate_of_Malta.pdf. Within each 30-degree sector the weight is constant and the model is rotated by 180 degrees; calm and variable winds carry no orientation. To regenerate the weights, place the PDF here as wind.pdf and run python wind.py (PyMuPDF, NumPy, pandas, Pillow). They are estimates from the published graphic. The daylight model uses one-minute steps between the computed 3000 BCE autumn and spring equinoxes at the mean temple location, apparent solar-centre altitude at least zero, air pressure 1013.25 mbar and air temperature 15 C. The aspect model uses within-30 m cell aspects of the external Alberti 5 m Malta DTM, an eight-neighbour operator, circular mean and SD, and a wrapped Gaussian for each structure. Set MALTA_DTM to the original DTM5m.tif and run aspect.R (R terra) to regenerate aspect.csv. Raster SHA-256: 78e90f9ddd858130db073d03814adbd446db287a711a961c442416afed7228cd. The table alone suffices to rerun the tests.
