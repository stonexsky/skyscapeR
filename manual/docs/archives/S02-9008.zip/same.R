suppressPackageStartupMessages(library(skyscapeR))
rows<-lapply(c("az","dec"),function(coord){
 ctor<-if(coord=="az") az.pdf else dec.pdf
 p<-ctor(c(10,30),c(3,5),.res=.5,.cutoff=.002,verbose=FALSE)
 s<-list(coord=coord,family="normal",unc=c(3,5),source.res=.5,source.cutoff=.002,
  xrange=if(coord=="az") c(0,360) else c(-90,90),normalise=FALSE,resolution=1)
 observed<-spd(p,xrange=s$xrange,.res=1)$data$y
 data.frame(coord,error=max(abs(observed-skyscapeR:::.model_curve(c(10,30),s))))
})
write.csv(do.call(rbind,rows),paste0("same-",packageVersion("skyscapeR"),".csv"),row.names=FALSE)
