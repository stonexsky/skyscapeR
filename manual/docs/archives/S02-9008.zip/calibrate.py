from pathlib import Path
import ctypes,subprocess
import numpy as np,pandas as pd
from scipy.stats import binomtest
from concurrent.futures import ProcessPoolExecutor
def prepare():
 subprocess.run(['g++','-O3','-std=c++17','-shared','-fPIC','score.cpp','-o','score.so'],check=True)
def score(a,circ):
 lib=ctypes.CDLL(str(Path('score.so').resolve()))
 ptr=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
 lib.ranks.argtypes=[ptr,ctypes.c_int,ctypes.c_int,ctypes.c_double,ctypes.c_int,ctypes.c_int,ptr]
 a=np.ascontiguousarray(a[:,:-1] if circ else a)
 out=np.zeros(2);lib.ranks(a,*a.shape,1,2,int(circ),out);return out
conditions=[(r,kind) for r in ['az','dec','shape'] for kind in ['common','site','injected','dependent']]
def calc(job):
 c,start=job;r,kind=conditions[c];circ=r=='az';n=8;B=39
 m=np.fromfile(r+'.bin','<f8').reshape(10,-1)
 rows=[]
 for i in range(start,start+100):
  rng=np.random.default_rng(np.random.SeedSequence([9008,c,i]))
  u=rng.random((B+1,n))
  if kind=='dependent':u[0,1::2]=u[0,::2]
  M=np.zeros((B+1,m.shape[1]))
  for j in range(n):
   w=np.array([1,2,4,2,1] if kind=='common' or j%2==0 else [4,1,1,1,3])/10
   idx=np.searchsorted(w.cumsum(),u[:,j])
   if kind=='injected' and j<4:idx[0]=3
   M+=m[5*(j%2)+idx]
  rows.append([r,kind,i,*score(M,circ)])
 return rows
if __name__=='__main__':
 prepare()
 for r in ['az','dec','shape','override']:
  a=np.fromfile(r+'-public.bin','<f8').reshape(40,-1)
  assert np.array_equal(score(a,r=='az'),pd.read_csv(r+'-public.csv').values[0])
 with ProcessPoolExecutor(5) as ex:
  rows=sum(ex.map(calc,[(c,i) for c in range(len(conditions)) for i in range(0,2000,100)]),[])
 d=pd.DataFrame(rows,columns=['route','truth','i','global','local']);d.to_csv('outer.csv',index=False)
 out=[]
 for (r,k),g in d.groupby(['route','truth']):
  for m in ['global','local']:
   for alpha in [.01,.05,.10]:
    n=len(g); count=int((g[m]<=alpha).sum());ci=binomtest(count,n).proportion_ci(method='wilson')
    out.append([r,k,m,alpha,n,count,count/n,ci.low,ci.high])
 pd.DataFrame(out,columns=['route','truth','metric','alpha','n','count','rate','lower','upper']).to_csv('rates.csv',index=False)
