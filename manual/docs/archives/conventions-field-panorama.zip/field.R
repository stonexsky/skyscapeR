library(skyscapeR)
skyscapeR.vars(timezone="UTC",calendar="G",refraction=FALSE)
site <- c(35.84,14.57,100)
day <- "2026/02/20"
clock <- "11:07:17"
print(mag.dec(site,day))
print(reduct.compass(site,mag.az=c(358.5,82.5),date=day,alt=c(2,5)))
for (l in c("left","right")) print(sunAz(site,paste(day,clock),"Europe/Malta",limb=l))
print(sunAz(site,paste(day,clock),"Europe/Malta"))
r <- reduct.theodolite(matrix(site,nrow=1),az=2.25,date=day,time=clock,tz="Europe/Malta",az.sun=358.75,alt=2)
print(r)
print(r$True.Azimuth %% 360)
print(reduct.theodolite(matrix(site,nrow=1),az=302.5,date=day,time=clock,tz="Europe/Malta",az.sun=327.25,alt=2))
print(sunAz(site,paste(day,"11:08:17"),"Europe/Malta")-
      sunAz(site,paste(day,clock),"Europe/Malta"))
