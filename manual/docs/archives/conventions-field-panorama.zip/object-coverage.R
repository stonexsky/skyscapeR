library(skyscapeR)
skyscapeR.vars(refraction=TRUE, atm=1013.25, temp=15)
partial <- importPanorama("skyline.png", c(51,0,100),
    az.lim=c(330,30), alt.lim=c(-4,6))
lookup <- hor2alt(partial, c(0,20,180))
bearing <- az.pdf(180, unc=1, pdf="uniform", verbose=FALSE)
density <- coordtrans(bearing, partial, verbose=FALSE)
rise <- riseset(partial, "2026/03/20", obj="sun",
    timezone="UTC", calendar="G", verbose=FALSE)$rise
print(lookup)
print(range(density$data[[1]]$x))
print(rise)
stopifnot(is.na(lookup[3]), all(is.finite(density$data[[1]]$x)),
          rise$azimuth > 30, rise$azimuth < 330)

both <- dec.pdf(c(-10,20), unc=c(1,2), name=c("A","B"), verbose=FALSE)
one <- subset(both, 2)
print(one$metadata[c("name","dec","unc")])
stopifnot(length(one$data)==1L, identical(one$data[[1]],both$data[[2]]),
          identical(one$metadata$name,"B"), identical(one$metadata$dec,c(-10,20)))
