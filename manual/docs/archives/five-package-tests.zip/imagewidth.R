library(terra);library(skyscapeR)
r<-rast(xmin=499800,xmax=500200,ymin=5699800,ymax=5700200,resolution=1,crs="EPSG:32630");values(r)<-100
s<-vect(matrix(c(500000,5700000),1),crs=crs(r))
d<-as.numeric(commandArgs(TRUE)[1]);res<-list()
for(pixel in c(360,720))for(occ in c(FALSE,TRUE)){
 mk<-function(y,x1,x2,height,col)horFeature(vect(matrix(c(500000+x1,5700000+y,500000+x2,5700000+y),2,byrow=TRUE),type="lines",crs=crs(r)),type="wall",height=height,width=1,colour=col)
 f<-list(mk(d,-2,2,8,"#ff0000"));if(occ)f<-c(f,list(mk(d/2,-2,0,6,"#00ff00")))
 h<-createHor(dem=r,loc=s,features=f,max.distance=170,az.step=5,distance.step=3,panorama.distance.step=3,panorama=TRUE,width=pixel,ncores=1,verbose=FALSE,progress=FALSE,name=paste("width",d,pixel,occ))
 im<-png::readPNG(h$metadata$image$path);red<-im[,,1]>1.5*im[,,2] & im[,,1]>1.5*im[,,3] & im[,,4]>.1
 # Endcaps of a buffered line have radius 0.5 m. Horizontal angular limits from tangent rays.
 half<-(atan2(2,d)+asin(.5/sqrt(d^2+4)))*180/pi
 ref<-if(occ)half-asin(.5/(d/2))*180/pi else 2*half
 res[[length(res)+1]]<-data.frame(d,pixel,occ,angular_width_deg=ref,rendered_deg=sum(colSums(red)>0)*360/dim(im)[2])
 write.csv(do.call(rbind,res),paste0("width-",d,".csv"),row.names=FALSE)
}
