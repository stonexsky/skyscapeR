library(skyscapeR)
out<-do.call(rbind,lapply(c("Arcturus","Sirius","Vega","Aldebaran","Regulus","Spica"),function(n)do.call(rbind,lapply(c(-3499,-1999,200,2000),function(y)data.frame(name=n,star(n,y)$coord)))))
write.csv(out,"stars.csv",row.names=FALSE)
