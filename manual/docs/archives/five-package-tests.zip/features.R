library(skyscapeR)
library(terra)
r<-rast(xmin=499700,xmax=500300,ymin=5699700,ymax=5700300,resolution=1,crs="EPSG:32630");values(r)<-100
s<-vect(matrix(c(500000,5700000),1),crs=crs(r))
out<-list()
for(d in c(50,150))for(w in c(1,4))for(step in c(1,5))for(pixel in c(360,720))for(occ in c(FALSE,TRUE)){
 mk<-function(y,half,height,offset=0) horFeature(vect(matrix(c(500000-half+offset,5700000+y,500000+half+offset,5700000+y),2,byrow=TRUE),type="lines",crs=crs(r)),type="wall",height=height,width=w)
 f<-list(mk(d,2,8));if(occ)f<-c(f,list(mk(d/2,1,6,-1)))
 h<-createHor(dem=r,loc=s,features=f,max.distance=200,az.step=step,distance.step=step,panorama=TRUE,width=pixel,ncores=1,verbose=FALSE,progress=FALSE)
 ref<-atan2(8-1.6,d-w/2)*180/pi
 # Test the eastern half at x=1.5 m projected to the far wall. Foreground wall extends east by w/2.
 az<-atan2(1.5,d)*180/pi
 a<-max(sapply(seq(0,200,.02),function(u){x<-u*sin(az*pi/180);y<-u*cos(az*pi/180);z<-if(sqrt(pmax(abs(x)-2,0)^2+(y-d)^2)<=w/2)8 else 0;if(occ && sqrt(pmax(abs(x+1)-1,0)^2+(y-d/2)^2)<=w/2)z<-max(6,z);atan2(z-1.6,u)*180/pi}))
 out[[length(out)+1]]<-data.frame(d,w,step,pixel,occ,az,expected=a,actual=hor2alt(h,az))
 write.csv(do.call(rbind,out),"features.csv",row.names=FALSE)
}
