import numpy as np,pandas as pd,erfa
d=pd.read_csv('stars.csv');cat=pd.read_csv('HYG-extract.csv').set_index('proper')
result=[]
for s in d.itertuples():
 c=cat.loc[s.name];y=s.year; jd=sum(erfa.cal2jd(y,1,1))+.5;epoch=2000+(jd-2451545)/365.25
 # The HYG Cartesian position and space velocity use pc and pc/Julian year.
 p=c[['x','y','z']].to_numpy(dtype=float)+(epoch-2000)*c[['vx','vy','vz']].to_numpy(dtype=float)
 p/=np.linalg.norm(p); p=erfa.ltpb(epoch)@p
 n=erfa.num06a(2451545.,jd-2451545)@p
 q=erfa.s2c(np.deg2rad(s.RA),np.deg2rad(s.Dec))
 result.append([s.name,y,np.hypot(c.pmra,c.pmdec),np.rad2deg(erfa.sepp(n,q))*3600])
pd.DataFrame(result,columns=['star','year','pm_mas_yr','separation_arcsec']).to_csv('astrometry.csv',index=False)
