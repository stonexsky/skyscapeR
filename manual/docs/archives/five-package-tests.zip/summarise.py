from pathlib import Path
from scipy.stats import binomtest
import pandas as pd
results=[]
for path in sorted(Path('stress').glob('*-*/rates.csv')):
 files=[path,*sorted(path.parent.glob('batch-*.csv'))]
 assert len(files)==5
 table=pd.concat([pd.read_csv(f) for f in files]).groupby(['skyline','weights','outcome'])[['rejections','datasets']].sum().reset_index()
 table['family_grid']=path.parent.name
 results.append(table)
out=pd.concat(results)
out['rate']=out.rejections/out.datasets
ci=[binomtest(k,n).proportion_ci(method='wilson') for k,n in zip(out.rejections,out.datasets)]
out['lower']=[i.low for i in ci];out['upper']=[i.high for i in ci]
assert len(out)==48 and (out.datasets==10000).all()
out.to_csv('calibration.csv',index=False)
