library(skyscapeR)
D<-pi/180; ans<-list()
for(radius in c(1,2,3))for(site in c("Coalsack","Carina")){
 l0<-if(site=="Carina")287 else 303
 f<-expand.grid(l=seq(l0-radius,l0+radius,.1),b=seq(-2-radius,-2+radius,.1));l<-f$l*D;b<-f$b*D
 keep<-sin(b)*sin(-2*D)+cos(b)*cos(-2*D)*cos(l-l0*D)>=cos(radius*D)
 cl<-skyscapeR:::.galactic_classes(cos(b)*cos(l),cos(b)*sin(l),sin(b),diag(3))
 flux<-weighted.mean(skyscapeR:::.mw_radiance()[cl[keep]+1],cos(b[keep]));ans[[length(ans)+1]]<-data.frame(site,radius,pred=-2.5*log10(flux/3600^2),observed=if(site=="Carina")20.7 else 21.4)
}
write.csv(do.call(rbind,ans),"sky.csv",row.names=FALSE)
fields<-list();for(name in c("southern12","southern15","southern18","Cygnus","Scutum")){
 b0<-switch(name,southern12=-12,southern15=-15,southern18=-18,Cygnus=4,Scutum=-3)
 l0<-switch(name,Cygnus=70,Scutum=27,330);observed<-switch(name,Cygnus=20.1,Scutum=20.3,southern12=22.0,southern15=22.1,southern18=22.2)
 hw<-switch(name,Cygnus=6,Scutum=3,10);hh<-switch(name,Cygnus=2,Scutum=3,.5)
 f<-expand.grid(l=seq(l0-hw,l0+hw,.1),b=seq(b0-hh,b0+hh,.1));l<-f$l*D;b<-f$b*D
 keep<-if(name=="Scutum")sin(b)*sin(b0*D)+cos(b)*cos(b0*D)*cos(l-l0*D)>=cos(3*D) else rep(TRUE,length(l))
 cl<-skyscapeR:::.galactic_classes(cos(b)*cos(l),cos(b)*sin(l),sin(b),diag(3))
 flux<-weighted.mean(skyscapeR:::.mw_radiance()[cl[keep]+1],cos(b[keep]));fields[[name]]<-data.frame(name,observed,pred=-2.5*log10(flux/3600^2))
}
write.csv(do.call(rbind,fields),"fields.csv",row.names=FALSE)
