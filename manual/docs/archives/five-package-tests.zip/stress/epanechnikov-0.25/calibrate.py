from pathlib import Path
import ctypes,subprocess
import numpy as np,pandas as pd
from scipy.stats import binomtest
from concurrent.futures import ProcessPoolExecutor
def prepare():
 subprocess.run(['g++','-O3','-std=c++17','-shared','-fPIC','score.cpp','-o','score.so'],check=True)
def score(a,circ):
 lib=ctypes.CDLL(str(Path('score.so').resolve()))
 ptr=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
 lib.ranks.argtypes=[ptr,ctypes.c_int,ctypes.c_int,ctypes.c_double,ctypes.c_int,ctypes.c_int,ptr]
 a=np.ascontiguousarray(a[:,:-1] if circ else a)
 out=np.zeros(2);lib.ranks(a,*a.shape,1,2,int(circ),out);return out
if __name__ == '__main__':
 prepare()
 reference=score(np.fromfile('public.bin','<f8').reshape(40,181),False)
 expected=pd.read_csv('public.csv').values[0]
 assert np.array_equal(reference,expected),(reference,expected)
 results=[]
 for j,(sky,weights) in enumerate((sky,weights) for sky in ['shared','paired'] for weights in ['common','site']):
  kernels=np.fromfile(sky+'.bin','<f8').reshape(10,181)
  rng=np.random.default_rng(int(__import__('os').environ.get('CALIBRATION_SEED','13350'))+j)
  counts=np.zeros(2)
  for k in range(2000):
   curves=np.zeros((40,181))
   for site in range(8):
    p=[.1,.2,.4,.2,.1] if weights=='common' or site%2==0 else [.4,.1,.1,.1,.3]
    draws=rng.choice(5,40,p=p)
    curves+=kernels[(site%2)*5+draws]
   counts+=score(curves,False)<=.05
  for label,n in zip(['global','any-local'],counts.astype(int)):
   ci=binomtest(n,2000).proportion_ci(method='wilson')
   results.append([sky,weights,label,n,2000,n/2000,ci.low,ci.high])
 pd.DataFrame(results,columns=['skyline','weights','outcome','rejections','datasets','rate','lower','upper']).to_csv(__import__('os').environ.get('CALIBRATION_OUTPUT','rates.csv'),index=False)
