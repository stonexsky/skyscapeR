import numpy as np,pandas as pd
from pathlib import Path
for dataset in ('bearings','bearings-long'):
 d=pd.read_csv(dataset+'.csv');out=[]
 d['group']=d.source_id.str.replace(r'UK-W-GorsFawr.*','UK-W-GorsFawr',regex=True).str.replace(r'IE-W-Ushnagh-.*','IE-W-Ushnagh',regex=True)
 for (station,product),v in d.groupby(['group','product']):
  train=d[d.group!=station];s=train[train['product']==product];fallback=s.empty
  if fallback:s=train
  w=s.error.abs().quantile(.95,interpolation='higher');e=v.error.abs()
  out.append([station,product,len(v),w,fallback,sum(e<=.5),sum(e<=w),sum(e<=.98)])
 o=pd.DataFrame(out,columns=['station_group','product','n','trained95_deg','pooled_fallback','within_half','within_trained','within_1.96sd']);o.to_csv(dataset+'-folds.csv',index=False)
 print(dataset,len(d),d.group.nunique(),o[['within_half','within_trained','within_1.96sd']].sum().tolist())
