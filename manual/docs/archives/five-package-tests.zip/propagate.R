library(skyscapeR)
skyscapeR.vars(refraction=FALSE);set.seed(455261)
D<-pi/180;az<-c(0,3,7,90,180,270,357,360);alt<-c(43,46,15,2,0,3,15,43)
h<-createHor(az=az,alt=alt,alt.unc=.5,loc=c(45,0,0),verbose=FALSE)
out<-list();n<-500000
for(centre in c(0,3,7))for(family in c("normal","epanechnikov","triangular")){
 u<-runif(n);b<-switch(family,normal=rnorm(n,centre,1),epanechnikov=centre+(2*qbeta(u,2,2)-1),triangular=centre+ifelse(u<.25,-1+sqrt(4*u),3-sqrt(12*(1-u))))%%360
 p<-if(family=="triangular")az.pdf(centre,pdf=family,lower=(centre-1)%%360,upper=(centre+3)%%360,verbose=FALSE) else az.pdf(centre,1,pdf=family,verbose=FALSE)
 ht<-(approx(az,alt,b)$y+rnorm(n,0,.5))*D
 ref<-quantile(asin(sin(45*D)*sin(ht)+cos(45*D)*cos(ht)*cos(b*D))/D,c(.025,.5,.975))
 for(step in c(.05,.1,.25,1)){g<-tryCatch(coordtrans(p,h,.prec=step,.res=.1,.output.res=.1,verbose=FALSE)$data[[1]],error=function(e)NULL);if(is.null(g)){out[[length(out)+1]]<-data.frame(centre,family,step,prob=c(.025,.5,.975),ref,pred=NA_real_);next};m<-c(0,cumsum(diff(g$x)*(head(g$y,-1)+tail(g$y,-1))/2));q<-approx(m/max(m),g$x,c(.025,.5,.975),ties="ordered")$y;out[[length(out)+1]]<-data.frame(centre,family,step,prob=c(.025,.5,.975),ref,pred=q)}
}
write.csv(do.call(rbind,out),"propagation.csv",row.names=FALSE)
