library(skyscapeR)
skyscapeR.vars(refraction=FALSE)
h <- createHor(az=c(0,3,7,90,180,270,357,360),alt=c(45,46,15,2,0,3,15,45),
               alt.unc=.5,loc=c(45,-77,0),verbose=FALSE)
rows<-list()
for(family in c("normal","epanechnikov","triangular")){
 p<-if(family=="triangular") az.pdf(0,pdf=family,lower=359,upper=3,verbose=FALSE) else az.pdf(0,1,pdf=family,verbose=FALSE)
 for(step in c(.25,1)){
 d<-coordtrans(p,h,.prec=step,verbose=FALSE)$data[[1]]
 mass<-sum(diff(d$x)*(head(d$y,-1)+tail(d$y,-1))/2)
 stopifnot(abs(mass-1)<1e-10,all(d$y>=0),all(is.finite(d$y)))
 rows[[length(rows)+1]]<-data.frame(family,step,mass)
 }
}
write.csv(do.call(rbind,rows),"exact-pole.csv",row.names=FALSE)
