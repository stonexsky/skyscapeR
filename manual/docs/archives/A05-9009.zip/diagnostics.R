suppressPackageStartupMessages(library(skyscapeR));library(swephR)
r<-read.csv("external-roots.csv")
r$error_sec<-mapply(function(t,d){
  uniroot(function(dt)swe_calc_ut(t+dt,0L,2050L)$xx[2]-d,
          c(-.05,.05),tol=1e-10)$root*86400
},r$jd,r$target)
write.csv(r,"jpl-time-residuals.csv",row.names=FALSE)
