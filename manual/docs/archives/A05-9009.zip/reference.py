from pathlib import Path
from urllib.request import urlopen
from urllib.parse import urlencode
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq
import numpy as np,pandas as pd, json,io
root=Path('.')
def cache(name,url):
 p=Path(name);p.with_suffix('.url').write_text(url)
 if not p.exists():p.write_bytes(urlopen(url,timeout=45).read())
 return p.read_text()
param=dict(format='text',COMMAND="'10'",CENTER="'500@399'",EPHEM_TYPE="'OBSERVER'",START_TIME="'1999-12-31'",STOP_TIME="'2001-01-02'",STEP_SIZE="'6 h'",QUANTITIES="'2'",CAL_FORMAT="'BOTH'",ANG_FORMAT="'DEG'",EXTRA_PREC="'YES'",CSV_FORMAT="'YES'",OBJ_DATA="'NO'")
s=cache('horizons.txt','https://ssd.jpl.nasa.gov/api/horizons.api?'+urlencode(param))
d=pd.read_csv(io.StringIO(s.split('$$SOE')[1].split('$$EOE')[0]),header=None)
x=d[1].to_numpy();y=d[5].to_numpy();spl=CubicSpline(x,y);out=[]
for target in [-23,-15,0,15,23,23.437]:
 for i in np.where((y[:-1]-target)*(y[1:]-target)<0)[0]:
  t=brentq(lambda z:spl(z)-target,x[i],x[i+1])
  if 2451544.5<=t<2451910.5:out.append([target,t])
pd.DataFrame(out,columns=['target','jd']).to_csv('external-roots.csv',index=False)
u=json.loads(cache('usno.json','https://aa.usno.navy.mil/api/seasons?year=2000'))
from datetime import datetime, timezone
events=[e for e in u['data'] if e['phenom'] in ('Equinox','Solstice')]
rows=[]
for e in events:
 t=datetime.strptime(f"{e['year']}-{e['month']}-{e['day']} {e['time']}","%Y-%m-%d %H:%M").replace(tzinfo=timezone.utc)
 rows.append([e['phenom'],t.strftime('%-d %b'),2440587.5+t.timestamp()/86400])
pd.DataFrame(rows,columns=['event','date','jd']).to_csv('usno-events.csv',index=False)
