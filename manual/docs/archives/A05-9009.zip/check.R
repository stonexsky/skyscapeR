suppressPackageStartupMessages(library(skyscapeR))
library(swephR)
skyscapeR.vars(refraction=FALSE)
rad<-pi/180; v<-as.character(packageVersion("skyscapeR"))
rows<-list();record<-function(label,obs,ref,tol=0,unit="degree"){
 num<-is.numeric(ref); e<-if(num&&length(obs)==length(ref))max(abs(obs-ref)) else NA_real_
 pass<-if(num)isTRUE(e<=tol) else identical(as.character(obs),as.character(ref))
 rows[[length(rows)+1]]<<-data.frame(label,observed=paste(obs,collapse=" / "),reference=paste(ref,collapse=" / "),unit,tol,error=e,pass)
}
# JPL roots are sub-day reference instants; the public quantity is a UT day.
j<-read.csv("external-roots.csv");day<-function(t,cal=1L){x<-swe_revjul(t,cal);paste(x$day,month.abb[x$month])}
for(a in unique(j$target)){
 actual<-na.omit(as.character(solar.date(a,2000,"G",FALSE)[-1,1]))
 expected<-vapply(j$jd[j$target==a],day,character(1))
 record(paste("JPL civil dates",a),actual,expected,unit="date")
}
usno.table<-read.csv("usno-events.csv");season<-usno.table$date
record("USNO season days",unname(skyscapeR:::.season_dates(2000,"G")),season,unit="date")
# Compare underlying longitude roots with USNO rounded event times in UT.
usno<-usno.table$jd
for(i in 1:4){
 t<-usno[i];f<-function(dt)(swe_calc_ut(t+dt,0L,2L)$xx[1]-(i-1)*90+180)%%360-180
 r<-uniroot(f,c(-2,2),tol=1e-11)$root
 record(paste("USNO season instant",i),r*86400,0,65,"seconds")
}
dec<-function(t)swe_calc_ut(t,0L,2050L)$xx[2]
peak<-optimize(function(dt)dec(2451716+dt),c(-2,2),maximum=TRUE,tol=1e-9)
for(delta in c(0,-1e-7,1e-5)){
 z<-try(solar.date(peak$objective+delta,2000,"G",FALSE),silent=TRUE)
 n<-if(inherits(z,"try-error"))0L else sum(!is.na(z[-1,1]))
 record(paste("solstice branch count",delta),n,if(delta==0)1 else if(delta<0)2 else 0,0,"events")
}
# The rising January branch can occur twice inside one civil year.
found<-FALSE
for(y in 1998:2005){
 j0<-swe_julday(y,1,1,0,1);j1<-swe_julday(y+1,1,1,0,1)
 if(dec(j1)>dec(j0)+.001){
  z<-solar.date(mean(c(dec(j0),dec(j1))),y,"G",FALSE)
  record("three passages in a civil year",sum(!is.na(z[-1,1])),3,0,"events")
  found<-TRUE;break
 }
}
stopifnot(found)
for(yr in c(-3249,2000))for(cal in c("G","J")){
 start<-swe_julday(yr,1,1,0,as.integer(cal=="G"))
 sample<-seq(start,start+367,by=.25)
 d<-vapply(sample,dec,numeric(1))
 for(a in c(-22,0,22)){
  idx<-which(head(d-a,-1)*tail(d-a,-1)<0)
  rt<-vapply(idx,function(i)uniroot(function(t)dec(t)-a,sample[i+0:1],tol=1e-8)$root,numeric(1))
  end<-swe_julday(yr+1,1,1,0,as.integer(cal=="G"))
  ref<-vapply(rt[rt<end],day,character(1),cal=as.integer(cal=="G"))
  record(paste("independent root brackets",yr,cal,a),na.omit(as.character(solar.date(a,yr,cal,FALSE)[-1,1])),ref,unit="date")
 }
}
geom<-function(az,h,lat)asin(sin(lat*rad)*sin(h*rad)+cos(lat*rad)*cos(h*rad)*cos(az*rad))/rad
for(lat in c(-40,0,50,78)){
 for(a in c(0,4)){
  record(paste("north level",lat,a),hor2max.dec(lat,a,8),geom(0,a,lat),.006)
  record(paste("south level",lat,a),hor2min.dec(lat,a,8),geom(180,a,lat),.006)
 }
}
z<-cbind(c(0,6,7,8,165,185,186,187,360),c(0,1,9,1,0,0,-8,0,0))
h<-createHor(az=z[,1],alt=z[,2],loc=c(50,0,0),verbose=FALSE)
for(north in c(TRUE,FALSE)){
 a<-seq(-10,10,.002)+if(north)0 else 180
 d<-geom(a,approx(z[,1],z[,2],xout=a%%360)$y,50)
 record(paste("interior limiting sightline",north),if(north)hor2max.dec(h,range=10) else hor2min.dec(h,range=10),if(north)max(d) else min(d),.006)
}
for(yr in c(-3249,2000)){
 eps<-swe_calc_ut(swe_julday(yr,1,1,12,1),-1L,2L)$xx[1]
 record(paste("obliquity",yr),obliquity(yr),eps,1e-10)
 for(lat in c(-50,0,50)){
  shift<-.00224*sin(lat*rad)
  record(paste("solar limits",yr,lat),c(dS(yr,lat,verbose=FALSE),eq(lat,verbose=FALSE),jS(yr,lat,verbose=FALSE)),c(-eps,0,eps)-shift,1e-10)
  record(paste("parallax altitude",lat),parallax.corr(.952,lat,10),.952*cos(10*rad)*sin(lat*rad),1e-10)
 }
}
# Analytic hour-angle track in a local ENU frame. Locate sign changes on a
# 15-second independent scan and bisect each bracket; horizon centre, airless.
for(lat in c(-35,50,75))for(shape in c("flat","east","west")){
 az<-c(0,20,35,145,160,200,215,325,340,360)
 ht<-switch(shape,flat=rep(0,10),east=c(0,0,7,7,0,0,0,0,0,0),west=c(0,0,0,0,0,0,7,7,0,0))
 hr<-createHor(az,ht,loc=c(lat,0,0),verbose=FALSE);skyline<-approxfun(az,ht)
 pos<-function(t,d){
  H<-(360*t-180)*rad
  az<-(atan2(-cos(d*rad)*sin(H),cos(lat*rad)*sin(d*rad)-sin(lat*rad)*cos(d*rad)*cos(H))/rad)%%360
  alt<-asin(sin(lat*rad)*sin(d*rad)+cos(lat*rad)*cos(d*rad)*cos(H))/rad
  list(az=az,h=alt)
 }
 actual<-suppressWarnings(spatial.equinox(hr,year=2000,refraction=FALSE,parallax=0))
 ref<-sapply(c(-1,1)*obliquity(2000),function(d){
  clearance<-function(t){p<-pos(t,d);p$h-skyline(p$az)}
  grid<-seq(0,1,1/5760);u<-clearance(grid)
  ix<-which(head(u,-1)*tail(u,-1)<0)
  roots<-vapply(ix,function(i)uniroot(clearance,grid[i+0:1],tol=1e-12)$root,numeric(1))
  c(if(any(roots<.5))pos(min(roots[roots<.5]),d)$az else NA,
    if(any(roots>.5))pos(max(roots[roots>.5]),d)$az else NA)
 })
 for(k in 1:2){
  label<-paste("spatial midpoint",lat,shape,c("rise","set")[k])
  if(anyNA(ref[k,]))record(label,is.na(actual$azimuth[[k]]),TRUE,unit="missing")
  else {a<-(ref[k,1]+((ref[k,2]-ref[k,1]+180)%%360-180)/2)%%360
   record(label,actual$azimuth[[k]],a,.001)
   record(paste(label,"declination"),actual$declination[[k]],geom(a,skyline(a),lat),.001)
  }
 }
}
# The geometric overhead point is at the observer's latitude, including on
# each tropical boundary. At a different epoch the reachable band changes.
for(lat in c(20,-20)){
 record(paste("default overhead geometry",lat),zenith(lat),lat,1e-10)
 record(paste("default anti-zenith geometry",lat),antizenith(lat),-lat,1e-10)
}
for(yr in c(-3249,2000))for(lat in c(0,20,-20,obliquity(yr),-obliquity(yr),24.5,75)){
 for(fn in c("zenith","antizenith")){
  target<-if(fn=="zenith")lat else -lat
  res<-try(do.call(fn,list(loc=lat,year=yr)),silent=TRUE)
  if(abs(lat)<=obliquity(yr))record(paste(fn,yr,lat),if(is.numeric(res))res else NA_real_,target,1e-10)
  else record(paste(fn,yr,lat),is.null(res),TRUE,unit="not reachable")
 }
}
out<-do.call(rbind,rows);write.csv(out,paste0("A05-",v,".csv"),row.names=FALSE);print(subset(out,!pass))
