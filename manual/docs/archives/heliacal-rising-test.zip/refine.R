library(skyscapeR)
skyscapeR.vars(refraction=FALSE)
ph<-read.csv("phases.csv")
sites<-list(Wiltshire=createHor(0:359,rep(0,360),c(51.18,-1.83,100),name="Wiltshire"),Mnajdra=malta_horizons[[1]])
inc<-function(B) ifelse(B<.0708,(6.505e-4*B^.25-8.461e-4*sqrt(B))^2,(1.772e-4*B^.25+7.167e-5*sqrt(B))^2)
lim<-function(nL)6-2.5*log10(inc(nL*1e-5/pi)/inc(60*1e-5/pi))
per.nl<-3600^2/(34.08*exp(20.7233))
check<-function(i){
 g<-ph[i,]; v<-read.csv(sprintf("daily/%03d.csv",i))
 ans<-list()
 for(which in c("new","old")){
  close<-which(abs(v[[which]])<.02 | abs(abs(v[[which]])-.5)<.02)
  for(j in close){
   tm<-v[[if(which=="new")"best" else "oldbest"]][j]
   margins<-vapply(tm+c(-1,0,1)/1440,function(jd){
    s<-sketchSky(sites[[g$site]],jd=jd,light.model="shared",max.mag=3.5,display=list(moon=FALSE))
    if(which=="old")s$light$calibrated.twilight<-FALSE
    p<-s$stars[g$key,]; hor<-sites[[g$site]]$data
    if(p[2]<=max(0,approx(hor$az,hor$alt,xout=p[1])$y) || p[2]>10 || p[1]>=180 || s$light$sun[2]>=0)return(-Inf)
    f<-skyRadiance(s,p[1]+c(-.005,.005),p[2]+c(-.005,.005),c(1,1))
    lim((f$radiance-f$direct)/per.nl)+2.5*log10(s$light.budget$stars[g$key])
   },numeric(1))
   ans[[length(ans)+1L]]<-data.frame(i,offset=v$offsets[j],curve=which,approx=v[[which]][j],direct=max(margins))
  }
 }
 do.call(rbind,ans)
}
out<-do.call(rbind,parallel::mclapply(which(is.finite(ph$phase_jd)),check,mc.cores=5,mc.preschedule=FALSE))
write.csv(out,'refined.csv',row.names=FALSE)
print(subset(out,(approx>=0)!=(direct>=0)))
