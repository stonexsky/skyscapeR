library(skyscapeR)
skyscapeR.vars(refraction=FALSE)
ph<-read.csv("phases.csv")
sites<-list(Wiltshire=createHor(0:359,rep(0,360),c(51.18,-1.83,100),name="Wiltshire"),Mnajdra=malta_horizons[[1]])
check<-function(i){
 v<-read.csv(sprintf("daily/%03d.csv",i));g<-ph[i,]
 j<-which(v$standard>=0)[1]
 if(!is.finite(j) || j==1) return(NULL)
 do.call(rbind,lapply(c(j-1,j),function(k){
  t<-v$stdbest[k];if(!is.finite(t)) return(NULL)
  s<-sketchSky(sites[[g$site]],jd=t,style="natural",light.model="standard",max.mag=3.5,display=list(moon=FALSE))
  painted<-s$star.opacity[g$key]>0 && s$stars[g$key,3]>0
  data.frame(i,offset=v$offsets[k],scan=v$standard[k],painted=painted)
 }))
}
q<-do.call(rbind,parallel::mclapply(which(is.finite(ph$phase_jd)),check,mc.cores=5,mc.preschedule=FALSE))
write.csv(q,"standard-renderer-check.csv",row.names=FALSE)
print(subset(q,(scan>=0)!=painted))
