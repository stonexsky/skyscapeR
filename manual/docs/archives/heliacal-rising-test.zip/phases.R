library(skyscapeR)
skyscapeR.vars(refraction=FALSE)
W<-createHor(0:359,rep(0,360),c(51.18,-1.83,100),name="Wiltshire")
sites<-list(Wiltshire=W,Mnajdra=malta_horizons[[1]])
stars<-c(Sirius="alf CMa",Aldebaran="alf Tau",Regulus="alf Leo",Alcyone="eta Tau",Spica="alf Vir",Antares="alf Sco",Procyon="alf CMi",Capella="alf Aur")
grid<-expand.grid(site=names(sites),year=c(-3499,-3249,-1999,200,2026),star=names(stars),stringsAsFactors=FALSE)
extra<-c(Miaplacidus="bet Car",Alnair="alf Gru",Avior="eps Car",Peacock="alf Pav","Rigil Kentaurus"="alf Cen")
stars<-c(stars,extra)
grid<-rbind(grid,data.frame(site="Mnajdra",year=-3249,star=names(extra)))
phaseOne<-function(i){
 g<-grid[i,];h<-sites[[g$site]]
 p<-star.phases(g$star,g$year,h,k=.2,limit=6,refraction=FALSE)
 e<-subset(p$metadata$events,event=="heliacal rising")
 if(nrow(e)>1)stop("Multiple seasonal events")
 data.frame(g,key=unname(stars[g$star]),phase_class=p$metadata$type,date_julian=if(nrow(e))e$date.julian else NA_character_,phase_jd=if(nrow(e))time2jd(paste(e$date.julian,"00:00"),timezone="UTC",calendar="J") else NA_real_)
}
res<-do.call(rbind,parallel::mclapply(seq_len(nrow(grid)),phaseOne,mc.cores=4))
write.csv(res,"phases.csv",row.names=FALSE)
print(table(res$phase_class));print(head(res,8))
