from pathlib import Path
import pandas as pd, numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from zipfile import ZipFile,ZIP_DEFLATED

def julian_day(j):
    if pd.isna(j):return ''
    c=int(np.floor(j+.5))+32082
    d=(4*c+3)//1461;e=c-(1461*d)//4
    m=(5*e+2)//153
    day=e-(153*m+2)//5+1;month=m+3-12*(m//10);y=d-4800+m//10
    return f'{abs(y) if y>0 else 1-y:04d}-{month:02d}-{day:02d} '+('CE' if y>0 else 'BCE')
ph=pd.read_csv('phases.csv');refined=pd.read_csv('refined.csv')
r=[]
for i,g in ph.iterrows():
 row=dict(site=g.site,epoch=f'{1-g.year} BCE' if g.year<=0 else f'{g.year} CE',astronomical_year=g.year,star=g.star,
          sample='main' if i<80 else 'Mnajdra follow-up',phase_class=g.phase_class,
          phases_local_date_Julian=julian_day(g.phase_jd),phases_date_JD_code=g.phase_jd)
 if pd.notna(g.phase_jd):
    v=pd.read_csv(f'daily/{i+1:03d}.csv')
    for _,adj in refined[refined.i==i+1].iterrows():
        v.loc[v.offsets==adj.offset,adj.curve]=adj.direct
    for col,label in [('new','calibrated'),('old','earlier_curve'),('standard','standard_symbol')]:
      for lim in ([5.5,6,6.5] if col=='new' else [6]):
       ok=v[col]>=6-lim
       if not ok.any():
        continue
       ix=np.where(ok)[0][0];assert ix>0 and not ok[ix-1] and ok[ix:ix+3].all()
       off=int(v.iloc[ix].offsets)
       if lim==6:
        row[label+'_days']=off
        row[label+'_date_Julian']=julian_day(g.phase_jd+off)
        row[label+'_date_JD_code']=g.phase_jd+off
       else:row['calibrated_days_at_limit_'+str(lim)]=off
 r.append(row)
out=pd.DataFrame(r)
out.to_csv('Heliacal-rising-results.csv',index=False)
stars=['Sirius','Procyon','Aldebaran','Regulus','Spica','Antares','Alcyone']
main=out.query('sample=="main"').dropna(subset=['calibrated_days'])
fig,axes=plt.subplots(1,2,figsize=(10,4.8),sharey=True)
years=sorted(main.astronomical_year.unique())
cm=LinearSegmentedColormap.from_list('lag',['#f2f4f5','#b6d3d4','#77adad','#31696f','#163d4c'])
for ax,site in zip(axes,['Wiltshire','Mnajdra']):
 mat=main.query('site==@site').pivot(index='star',columns='astronomical_year',values='calibrated_days').reindex(index=stars,columns=years)
 ax.imshow(mat,cmap=cm,vmin=0,vmax=8,aspect='auto')
 for (y,x),v in np.ndenumerate(mat.to_numpy()):ax.text(x,y,str(int(v)),ha='center',va='center',color='white' if v>=5 else '#112725',fontweight='bold')
 ax.set_xticks(range(5),['3500\nBCE','3250\nBCE','2000\nBCE','200\nCE','2026\nCE'])
 ax.set_yticks(range(7),stars);ax.set_title('Wiltshire · level horizon' if site=='Wiltshire' else 'Mnajdra South · terrain skyline',fontsize=13)
 ax.tick_params(length=0,pad=7)
 for spine in ax.spines.values():spine.set_visible(False)
fig.suptitle('Days from the star.phases() heliacal rising to first morning visibility',fontsize=15,y=.97)
fig.subplots_adjust(top=.83,bottom=.13,left=.12,right=.98,wspace=.12)
fig.savefig('Heliacal-rising-by-star-and-epoch.png',dpi=175)
for name,g in [('main',main),('extra',out.query('sample!="main"'))]:
 cols=['calibrated_days','earlier_curve_days','standard_symbol_days']
 print(name);print(g[cols].abs().agg(['count','mean','median','max']));print(g[cols].mean())
print(main.groupby('site').calibrated_days.mean())
print(main.groupby('star').calibrated_days.agg(['min','max']))
print(main[['calibrated_days_at_limit_5.5','calibrated_days_at_limit_6.5']].agg(['min','max']))
