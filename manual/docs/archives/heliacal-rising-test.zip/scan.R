library(skyscapeR)
skyscapeR.vars(refraction=FALSE)
ph<-read.csv("phases.csv")
sites<-list(Wiltshire=createHor(0:359,rep(0,360),c(51.18,-1.83,100),name="Wiltshire"),Mnajdra=malta_horizons[[1]])
B0<-60*1e-5/pi
inc<-function(B) ifelse(B<.0708,(6.505e-4*B^.25-8.461e-4*sqrt(B))^2,(1.772e-4*B^.25+7.167e-5*sqrt(B))^2)
limit<-function(nL) 6-2.5*log10(inc(nL*1e-5/pi)/inc(B0))
per.nl<-3600^2/(34.08*exp(20.7233))
scan<-function(i){
 g<-ph[i,]; hor<-sites[[g$site]];loc<-as.numeric(hor$metadata$georef);geo<-loc[c(2,1,3)]
 horizon<-skyscapeR:::.horizon_profile(hor$data$az,hor$data$alt)
 ref<-g$phase_jd;flags<-32768L+2048L+2L
 swe_set_topo(geo[1],geo[2],geo[3])
 key<-paste0(",",g$key); mag<-swe_fixstar2_mag(key)$mag
 sample<-function(d){
  # Report local mean solar date. Grid in whole UT minutes, as in the pilot.
  day<-ref+d
  jds<-day+(-75:795)/1440
  local.hour<-(jds-day)*24+loc[2]/15
  jds<-jds[local.hour>=0 & local.hour<12]
  eq<-swe_fixstar2_ut(key,day+.25,flags)
  stopifnot(eq$return>=0,bitwAnd(eq$return,7)==2)
  eq<-eq$xx[1:3]
  H<-((15*swe_sidtime(day)+loc[2]-eq[1]+360.985647*(jds-day)+180)%%360-180)*pi/180
  lat<-loc[1]*pi/180; dec<-eq[2]*pi/180
  ht<-asin(sin(lat)*sin(dec)+cos(lat)*cos(dec)*cos(H))*180/pi
  jds<-jds[ht>=-0.15 & ht<=10.15 & H<=0]
  distant<-c(new=-Inf,old=-Inf,best=NA,oldbest=NA,standard=-Inf,stdbest=NA)
  if(!length(jds))return(distant)
  azalt<-function(j,xyz)swe_azalt(j,1L,geo,1013.25,15,xyz)$xaz
  pos<-t(vapply(jds,azalt,numeric(3),xyz=eq))
  az<-(pos[,1]+180)%%360
  ok<-az<180 & pos[,2]>pmax(0,horizon(az)) & pos[,2]<=10
  if(!any(ok))return(distant)
  pos<-pos[ok,,drop=FALSE];jds<-jds[ok]; az<-az[ok]
  sun<-t(vapply(jds,function(j)azalt(j,swe_calc_ut(j,0L,flags)$xx[1:3]),numeric(3)))
  keep<-which(sun[,2]<0);if(!length(keep))return(distant)
  eq<-eq*pi/180
  cls<-skyscapeR:::.galactic_classes(cos(eq[2])*cos(eq[1]),cos(eq[2])*sin(eq[1]),sin(eq[2]),t(skyscapeR:::.galactic_frame(day)))
  mw<-skyscapeR:::.mw_radiance()[cls+1]*skyscapeR:::.band_transmission(pos[keep,2],.2)/per.nl
  m<-mag+skyscapeR:::.stellar_extinction(pos[keep,3],.2)
  compare<-function(cal){
   B<-vapply(keep,function(k)skyscapeR:::.sky_luminance(list(sun=c((sun[k,1]+180)%%360,sun[k,2]),k=.2,calibrated.twilight=cal),az[k],pos[k,2]),numeric(1))+mw
   margin<-limit(B)-m
   c(max(margin),jds[keep[which.max(margin)]])
  }
  a<-compare(TRUE);b<-compare(FALSE)
  # Standard natural-style symbol appears once its opacity is positive.
  ad<-approx(c(-12,-9,-5,-1),c(0,1,1,0),xout=sun[keep,2],rule=2)$y
  back<-vapply(seq_along(keep),function(ii){
    k<-keep[ii];skyscapeR:::.sky_luminance(list(sun=c((sun[k,1]+180)%%360,sun[k,2]),k=.2),az[k],pos[k,3],adaptation=ad[ii])
  },numeric(1))
  std<-6-1.45*log10(back/60)-m
  c(new=a[1],old=b[1],best=a[2],oldbest=b[2],standard=max(std),stdbest=jds[keep[which.max(std)]])
 }
 offsets<- -24:24
 v<-t(vapply(offsets,sample,numeric(6)))
 if(any(v[1,c(1,2,5)]>=-.5)||any(v[nrow(v),c(1,2,5)]<.5)){
  offsets<- -64:64;v<-t(vapply(offsets,sample,numeric(6)))
 }
 res<-data.frame(i,offsets,v,check.names=FALSE)
 write.csv(res,sprintf("daily/%03d.csv",i),row.names=FALSE)
 NULL
}
dir.create("daily",showWarnings=FALSE)
invisible(parallel::mclapply(which(is.finite(ph$phase_jd)),scan,mc.cores=5,mc.preschedule=FALSE))
stopifnot(length(list.files("daily",pattern="csv$"))==sum(is.finite(ph$phase_jd)))
