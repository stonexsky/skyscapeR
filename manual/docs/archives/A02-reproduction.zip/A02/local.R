suppressPackageStartupMessages(library(skyscapeR));library(swephR)
h<-read.csv("horizons.csv")
rows<-list()
for(clock in c("default","Horizons")){
 for(i in seq_len(nrow(h))){
  r<-h[i,];jd<-r$jd+r$dut/86400
  loc<-c(r$latitude,r$longitude,r$height_km*1000)
  if(clock=="Horizons")swe_set_delta_t_userdef((r$dt-r$dut)/86400)
  swe_set_topo(loc[2],loc[1],loc[3])
  dt<-swe_deltat_ex(jd,2L)$deltat*86400
  p<-body.position(jd,obj=r$body,loc=loc,dec="topo",refraction=FALSE,verbose=FALSE)
  id<-c(Sun=0L,Moon=1L,Venus=3L)[[r$body]]
  eq<-swe_calc_ut(jd,id,as.integer(2+2048+32768))
  stopifnot(bitwAnd(eq$return,7L)==2L, eq$return>0)
  a<-swe_azalt(jd,1L,loc[c(2,1,3)],0,15,eq$xx[1:3])$xaz
  for(mode in c("package","apparent")){
   az<-if(mode=="package")p$horizontal$az else (a[1]+180)%%360
   alt<-if(mode=="package")p$horizontal$alt else a[2]
   rad<-pi/180;daz<-(az-r$az+180)%%360-180
   term<-sin((alt-r$alt)*rad/2)^2+cos(alt*rad)*cos(r$alt*rad)*sin(daz*rad/2)^2
   ra<-if(mode=="package")p$equatorial$RA else eq$xx[1]
   dec<-if(mode=="package")p$equatorial$Dec else eq$xx[2]
   dra<-(ra-r$ra+180)%%360-180
   eqterm<-sin((dec-r$dec)*rad/2)^2+cos(dec*rad)*cos(r$dec*rad)*sin(dra*rad/2)^2
   rows[[length(rows)+1L]]<-data.frame(eq_separation_arcsec=2*asin(sqrt(eqterm))/rad*3600,ra_error_arcsec=dra*3600,dec_error_arcsec=(dec-r$dec)*3600,site=r$site,jd=r$jd,body=r$body,clock,mode,delta_t_s=dt,az_error_arcsec=daz*3600,alt_error_arcsec=(alt-r$alt)*3600,separation_arcsec=2*asin(sqrt(term))/rad*3600)
  }
 }
}
write.csv(do.call(rbind,rows),"results/local.csv",row.names=FALSE)
