library(swephR)
yrs<-c(-3499,-2499,-999,1900,2000,2025)
ep<-do.call(rbind,lapply(yrs,function(y)data.frame(year=y,jd=swe_julday(y,1L,1L,12,1L)+c(0,44.125,89.25,135.375,181.5,227.625,273.75,319.875),kind="sample")))
for(y in c(-3000,1800)){
 start<-swe_julday(y,1L,1L,0,as.integer(y>=1600));ep<-rbind(ep,data.frame(year=y,jd=start+c(-.01,0,.01),kind='boundary'))
}
ep$group<-ifelse(ep$year<0,'prehistoric','modern/historical')
write.csv(ep,'epochs.csv',row.names=FALSE)
