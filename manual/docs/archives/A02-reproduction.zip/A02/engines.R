args<-commandArgs(TRUE); generation<-args[1]
suppressPackageStartupMessages(library(skyscapeR)); library(swephR)
if(!dir.exists("results"))dir.create("results")
path<-normalizePath(Sys.getenv("SE_EPHE_PATH"))
stopifnot(as.character(packageVersion("skyscapeR"))=="2.0.9004")
writeLines(c(paste("R",getRversion()),paste("swephR",packageVersion("swephR")),paste("Swiss",swe_version()),paste("skyscapeR",packageVersion("skyscapeR")),paste("Input",path)) ,paste0("results/version-",generation,".txt"))
ep<-read.csv("epochs.csv")
bodies<-c("Sun","Moon","Mercury","Venus","Mars","Jupiter","Saturn","Uranus","Neptune","Pluto")
swe_set_ephe_path(path)
wrap<-function(a)(a+180)%%360-180
rows<-list();pos<-list();ph<-list()
for(j in seq_len(nrow(ep))){
 jd<-ep$jd[j]
 for(id in 0:9){
  body<-bodies[id+1]
  # Identical numerical native ephemeris argument; no civil-time conversion in parent test.
  flags<-as.integer(2+16+32+64+2048+4096+131072)
  raw<-swe_calc(jd,id,flags)
  if(raw$return<0L || bitwAnd(raw$return,7L)!=2L)stop(paste(jd,body,raw$serr))
  pos[[length(pos)+1L]]<-data.frame(jd,body,x=raw$xx[1],y=raw$xx[2],z=raw$xx[3],flag=raw$return)
  for(mode in c("geo","topo")){
   loc<-c(35.90083,14.34,158)
   flags<-as.integer(if(mode=="geo")2050 else 34834) # SWIEPH + EQUATORIAL [+ TOPOCTR + TRUEPOS]
   if(mode=="topo")swe_set_topo(loc[2],loc[1],loc[3])
   eq<-swe_calc_ut(jd,id,flags)
   stopifnot(eq$return>=0L,bitwAnd(eq$return,7L)==2L)
   hor<-swe_azalt(jd,1L,loc[c(2,1,3)],1013.25,15,eq$xx[1:3])$xaz
   for(refr in c(FALSE,TRUE)){
    p<-body.position(jd,obj=body,loc=loc,dec=mode,refraction=refr,atm=1013.25,temp=15,verbose=FALSE)
    rows[[length(rows)+1L]]<-data.frame(jd,body,mode,refr,az_error=wrap(p$horizontal$az-(hor[1]+180)%%360),alt_error=p$horizontal$alt-hor[if(refr)3 else 2],RA_error=wrap(p$equatorial$RA-eq$xx[1]),dec_error=p$equatorial$Dec-eq$xx[2],flag=eq$return)
   }
  }
 }
 q<-swe_pheno_ut(jd,1L,2L);stopifnot(bitwAnd(q$return,7L)==2L)
 ph[[j]]<-data.frame(jd,phase=moonphase(jd),direct=q$attr[2],flag=q$return)
}
savecsv<-function(x,f)write.csv(do.call(rbind,x),sprintf("results/%s-%s.csv",f,generation),row.names=FALSE)
savecsv(pos,"geometric");savecsv(rows,"wrapper");savecsv(ph,"moonphase")
