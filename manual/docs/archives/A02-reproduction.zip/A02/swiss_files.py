from pathlib import Path
from urllib.request import urlopen
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import csv,os,shutil
dest=Path('swiss441');dest.mkdir(exist_ok=True)
names=[f'{p}{block}.se1' for p in ['sepl','semo'] for block in ['m36','m30','m12','_12','_18']]
def acquire(name):
    url=f'https://raw.githubusercontent.com/aloistr/swisseph/master/ephe/{name}'
    file=dest/name
    if not file.exists():
        candidate=Path(os.environ.get('SWISS_CANDIDATE','/nonexistent'))/name
        if candidate.exists() and b'DE441' in candidate.read_bytes()[:280]:
            shutil.copyfile(candidate,file)
        else:file.write_bytes(urlopen(url,timeout=40).read())
    data=file.read_bytes();header=data[:300].split(b'\r\n')[2].decode().strip()
    assert 'DE441' in header,(name,header)
    return [name,header,len(data),sha256(data).hexdigest(),url]
if __name__=='__main__':
    with ThreadPoolExecutor(4) as pool: rows=list(pool.map(acquire,names))
    with open('results/manifest-441.csv','w') as f:
        w=csv.writer(f);w.writerow(['file','header','bytes','sha256','source']);w.writerows(rows)
