from pathlib import Path
from io import BytesIO
from base64 import b64encode
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
ep=pd.read_csv('epochs.csv')
p=pd.concat([pd.read_csv(f'results/parent-{n}.csv').assign(parent=n) for n in [431,441]]).merge(ep)
l=pd.read_csv('results/local.csv').merge(ep)
def stats(s):
    return pd.Series(dict(N=len(s),median=s.median(),rms=np.sqrt(np.mean(s**2)),maximum=s.max()))
def summarize(d,by):
    return d.groupby(by).separation_arcsec.apply(stats).unstack()
parent=summarize(p,['parent','group','body'])
local=summarize(l,['group','clock','mode'])
parent.to_csv('results/parent-summary.csv');local.to_csv('results/local-summary.csv')
fig,ax=plt.subplots(1,2,figsize=(10,4),constrained_layout=True)
for n,g in p.groupby('parent'):
    x=np.sort(g.separation_arcsec)*1000
    ax[0].step(x,np.arange(1,len(x)+1)/len(x),label=str(n))
ax[0].set(xscale='log',xlabel='Geocentric separation (milliarcseconds)',ylabel='Fraction at or below separation',title='Swiss files against their JPL parent');ax[0].axvline(1,color='#777',linestyle=':');ax[0].legend(title='DE')
g=l[(l.clock=='default')&(l['mode']=='package')]
for body,grp in g.groupby('body'):
    a=grp.groupby('year').separation_arcsec.median()/3600
    ax[1].plot(np.arange(len(a)),a,'o',label=body)
ax[1].set(yscale='log',xticks=range(6),xticklabels=['3500 BCE','2500 BCE','1000 BCE','1900','2000','2025'],ylabel='Median separation (degrees)',title='Local sky direction against Horizons');ax[1].tick_params(axis='x',rotation=35);ax[1].legend()
f=BytesIO();fig.savefig(f,format='png',dpi=150);img=b64encode(f.getvalue()).decode()
table=lambda df:df.to_html(float_format=lambda x:f'{x:.6f}')
html=f"""<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>A02 · Ephemeris accuracy</title><style>body{{max-width:920px;margin:3em auto;padding:0 1em;color:#182838;font:17px/1.55 system-ui}}h1,h2{{line-height:1.22}}table{{border-collapse:collapse;font-size:.88em}}th,td{{padding:.3em .55em;border-bottom:1px solid #ccd7d9;text-align:right}}.scroll{{overflow:auto}}img{{width:100%;height:auto}}a{{color:#126074}}</style>
<h1>A02 · How accurately does skyscapeR reproduce planetary and lunar positions?</h1>
<p>Validation run of 9 November 2026. skyscapeR 2.0.9004, swephR 0.3.2, Swiss Ephemeris 2.10.03, R 4.3.3.</p>
<h2>Outcome for users</h2>
<p>File-backed geocentric directions agreed with the corresponding JPL parent to within 0.0065″ in all 1,080 comparisons. The public position wrapper agreed with direct Swiss calls at numerical precision. For local solar, lunar and Venus directions, the maximum separation of the package from airless JPL Horizons was 44.4″ in 1900–2025 and 0.7013° in the prehistoric sample. These comparisons measure agreement between reconstructions. The prehistoric sample has no observational ground truth.</p>
<img alt="Empirical cumulative geocentric residuals for DE431 and DE441, and local median residuals by body and year" src="data:image/png;base64,{img}">
<h2>Geocentric ephemerides</h2><p>Ten bodies (Sun, Moon, Mercury through Pluto), 54 dates and two file generations. Eight instants in each of 3500 BCE, 2500 BCE, 1000 BCE, 1900, 2000 and 2025 sample different orbital configurations. Six additional instants fall on and immediately beside the file boundaries at astronomical year −3000 and CE 1800. Sampling is deterministic and gives no statistical confidence interval for the maximum over all dates.</p>
<p>For each family, compare geometric Earth-centred equatorial Cartesian vectors in J2000 ICRS with the same numerical dynamical-time argument. This isolates the ephemeris from civil-time conversion. We evaluated JPL's ASCII Chebyshev coefficients independently, reconstructed the Earth from the Earth–Moon barycentre and the Moon, and checked 46 official JPL position or velocity components per DE generation. The largest evaluator discrepancy was 7.2 × 10⁻¹⁵ AU or AU/day. Vector separation uses the cross and dot products. The archive also gives signed Swiss-minus-JPL right ascension, declination and range residuals.</p>
<p>The median separation was 0.000257″ for DE431 and 0.000260″ for DE441. In each family 514 of 540 directions were within 0.001″. Venus gave both maxima (0.00646″ and 0.00540″). Astrodienst's description of compression accuracy is a useful reference value. This sample does not support 0.001″ as a universal bound on geocentric angular separation. File headers and hashes identify the parent separately for every block.</p>
<h2>Public R functions and missing files</h2><p>At a Maltese location we compared <code>body.position()</code> with direct swephR calls for all 54 instants, 10 bodies, both geocentric and topocentric modes, and refraction on and off. Both generations reproduced azimuth, altitude, right ascension and declination to better than 10⁻¹² degrees across 4,320 calls. All 108 <code>moonphase()</code> illuminated fractions matched the native backend. Agreement with the same engine verifies the wrapper and conventions. It does not independently establish refraction or phase accuracy.</p>
<p>Seven isolated installations tested file handling for the Sun. A covering pair succeeded. Empty, planet-only, Moon-only, out-of-block, just-before-block and corrupt-planet cases all raised <code>skyscapeR_ephemeris_error</code>. Particularly important for users, the native call returned the Swiss backend flag even with a planet-only file. The public function still rejected the incomplete pair.</p>
<h2>Local sky directions</h2><p>We compared Sun, Moon and Venus airless directions at three specified locations (Malta, Wiltshire and Atacama), four instants per year, 216 site–body–instant comparisons. Rows include directions above and below the horizon. Site longitudes are positive east, heights are geodetic, and azimuth is clockwise from true north. The public call used <code>dec="topo", refraction=FALSE</code>. Its true-position flag requests geometric positions, whereas Horizons supplies apparent directions. The primary metric is angular separation on the sky, which remains meaningful near the zenith where azimuth alone is unstable.</p>
<p>Two controls identify how much the convention matters. First, remove the true-position flag to request apparent directions directly from Swiss. Second, set Swiss ΔT to Horizons TDB−UT1, treating TT−TDB as negligible at this scale. We used UT1 before 1962 and converted modern Horizons UTC epochs to UT1 with the returned DUT1. The archive preserves each target, site, ephemeris, reference frame, time convention and API reply.</p>
<p>With apparent conventions and aligned clocks, the modern/historical maximum fell to 0.55″. The corresponding prehistoric maximum was still 0.719°, although the equatorial directions agreed to within 48.8″. Much of the remaining disagreement therefore appears in the transformation to the local horizon. This run does not assign it to either service or isolate a particular Earth-orientation model. The Horizons replies identify measured Earth-orientation coverage beginning in 1962. For a prehistoric alignment needing a tolerance finer than the reported differences, the choice of local reconstruction matters.</p>
<h3>Local angular separation in arcseconds</h3><div class="scroll">{table(local)}</div><p>“Package” uses the public topocentric convention. “Apparent” is the swephR control. “Default” uses Swiss ΔT. “Horizons” uses the aligned ΔT. Each row summarizes 108 comparisons.</p>
<h3>Geocentric angular separation by body and period, in arcseconds</h3><div class="scroll">{table(parent)}</div>
<h2>Sources and reproduction</h2><p>See the companion archive for scripts, individual residuals, the sampled coefficient records, raw Horizons replies and Swiss input hashes. Consult the <a href="https://www.astro.com/swisseph/swephinfo_e.htm">Swiss Ephemeris technical information</a>, the <a href="https://ssd.jpl.nasa.gov/ftp/eph/planets/ascii/">JPL Development Ephemeris ASCII archive</a> and the <a href="https://ssd.jpl.nasa.gov/horizons/manual.html">Horizons manual</a>.</p></html>"""
Path('A02-results.html').write_text(html)
