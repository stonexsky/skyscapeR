from pathlib import Path
from urllib.request import Request,urlopen
from concurrent.futures import ThreadPoolExecutor
import re,math,time
import pandas as pd
import numpy as np
root=Path('inputs');root.mkdir(exist_ok=True)
ep=pd.read_csv('epochs.csv')
def retrieve(url,span=None):
 for retry in range(3):
  try:
   rq=Request(url+(f'?a02_range={span[0]}-{span[1]}' if span else ''),headers={'Range':f'bytes={span[0]}-{span[1]}'} if span else {})
   with urlopen(rq,timeout=28) as response:
    if span:
     assert response.status==206 and response.headers['Content-Range'].startswith(f'bytes {span[0]}-{span[1]}/')
    b=response.read()
    if span:assert len(b)==span[1]-span[0]+1
    return b
  except Exception:
   if retry==2:raise
   time.sleep(1)
def coeff(d):
 return np.fromstring(d.decode('ascii').replace('D','E'),sep=' ')
def one(args):
 n,year=args;prefix='asc'+('m' if year<0 else 'p')+f'{abs(year):05}.{n}';url=f'https://ssd.jpl.nasa.gov/ftp/eph/planets/ascii/de{n}/{prefix}'
 d=root/str(n);d.mkdir(exist_ok=True)
 head=d/(prefix+'.start');head.write_bytes(retrieve(url,(0,91))) if not head.exists() else None
 jd0=float(head.read_text().split()[2].replace('D','E'))
 todo=ep[(ep.jd>=jd0)&(ep.jd<jd0+365250)].jd
 def get(jd):
  k=math.floor((jd-jd0)/32);p=d/(prefix+f'.r{k:05}')
  if not p.exists():p.write_bytes(retrieve(url,(26821*k,26821*(k+1)-1)))
  v=coeff(p.read_bytes());assert int(v[1])==1018 and v[2]<=jd<v[3] and v[3]-v[2]==32
 with ThreadPoolExecutor(3) as pool:list(pool.map(get,sorted(set(todo))))
 print(n,year,len(todo),flush=True)
if __name__=='__main__':
 for n,h in [(431,'header.431_572'),(441,'header.441')]:
  if not (root/h).exists():(root/h).write_bytes(retrieve(f'https://ssd.jpl.nasa.gov/ftp/eph/planets/ascii/de{n}/{h}'))
 with ThreadPoolExecutor(4) as pool:list(pool.map(one,[(n,y) for n in [431,441] for y in [-4000,-3000,-1000,1000,2000]]))
