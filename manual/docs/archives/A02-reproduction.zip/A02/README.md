# A02 · Ephemeris accuracy

Open A02-results.html for the research question, results and limitations. All residuals use skyscapeR or Swiss minus reference. One arcsecond is 1/3600 degree. The archive records the 9 November 2026 run. No manual changes were made in this revision. Editorial note for the next manual revision: include the upcoming validation programme table and link it to completed reports as they become available.

## Reproduce

Use the archived skyscapeR 2.0.9004 build (project package archive), swephR 0.3.2 with Swiss 2.10.03, R, Python 3, numpy, pandas and matplotlib. Run in this directory. The full JPL fixtures and Horizons replies are included. Swiss .se1 files are external. For DE431 obtain the files specified in results/manifest-431.csv from the swephRdata distribution. For DE441 run python swiss_files.py or supply files whose SHA256 matches the manifest. Copy the pinned manifest before using swiss_files.py, which writes an inventory of the downloaded version. Validate hashes against the original archived manifest before comparing results.

    Rscript setup.R
    python sources.py
    python horizons.py
    python verify_files.py 431 /path/to/de431
    python verify_files.py 441 /path/to/de441
    SE_EPHE_PATH=/path/to/de431 Rscript engines.R 431
    SE_EPHE_PATH=/path/to/de441 Rscript engines.R 441
    python evaluate.py
    SE_EPHE_PATH=/path/to/de441 Rscript local.R
    SE_EPHE_PATH=/path/to/de441 python coverage.py
    python report.py

For the missing-file controls, use an R library without installed swephRdata and with no planetary or lunar .se1 files in swephR's own ephemeris directory. coverage.py checks the response in a new R process for each arrangement. The two boundaries are also sampled with complete files in the main matrix. R_BIN can override the default R executable used in the controls. The archived Horizons data are fixed; to query the current service afresh, move the horizons directory aside. TLIST_TYPE=JD is explicit, with assertions on all returned epochs. The compressed planet and Moon files must both match the cited JPL parent in every sampled block.

## Inputs and scope

- JPL reference files originate at https://ssd.jpl.nasa.gov/ftp/eph/planets/ascii/ under de431/ or de441/. The input filename prefix identifies the original source. Each rNNNNN is one complete 32-day ASCII record indexed from zero. Official testpo files are included unchanged; 46 eligible component checks per family overlapped our records.
- JPL Horizons observer responses in horizons/ preserve each URL and header. Each output direction is for the specified target centre (Sun 10, Moon 301, Venus system barycentre 2) and geodetic observer on Earth. Dates are matched by numerical JD, irrespective of printed civil calendar. Longitudes, site heights and positions in horizons.csv are explicit.
- The local sample covers solar, lunar and Venus directions, with no terrain masking or atmospheric refraction. It tests reproducibility between models, not observational accuracy at prehistoric dates. The parent test covers all ten solar-system bodies listed in engines.R; stellar catalogues, trajectories, event times and heliacal visibility are outside this check.
- results/parent-*.csv and local.csv contain signed component residuals and total angular separations. Parent summaries use angular units of arcseconds and range units of km. Wrapper component errors are in degrees. Phase errors are dimensionless.
