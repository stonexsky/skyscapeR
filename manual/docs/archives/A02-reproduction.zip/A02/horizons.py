import csv,urllib.request,urllib.parse,re,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import pandas as pd
out=Path('horizons');out.mkdir(exist_ok=True)
epochs=pd.read_csv('epochs.csv');epochs=epochs[epochs.kind=='sample'].groupby('year').head(4)
sites={'Malta':(14.34,35.90083,.158),'Wiltshire':(-1.83,51.18,.100),'Atacama':(-70.4,-24.63,2.6)}
def fetch(arg):
 name,target=arg;lon,lat,km=sites[name];file=out/f'{name}-{target}.txt'
 par={'format':'text','COMMAND':str(target),'CENTER':"'coord@399'",'COORD_TYPE':"'GEODETIC'",'SITE_COORD':f"'{lon},{lat},{km}'",'EPHEM_TYPE':"'OBSERVER'",'TLIST_TYPE':"'JD'",'TLIST':"'"+','.join(f'{x:.8f}' for x in epochs.jd)+"'",'QUANTITIES':"'2,4,10,20,30,49'",'ANG_FORMAT':"'DEG'",'APPARENT':"'AIRLESS'",'CSV_FORMAT':"'YES'",'EXTRA_PREC':"'YES'",'CAL_FORMAT':"'BOTH'",'OBJ_DATA':"'NO'"}
 url='https://ssd.jpl.nasa.gov/api/horizons.api?'+urllib.parse.urlencode(par)
 if not file.exists() or 'TLIST_TYPE' not in (out/f'{name}-{target}.url').read_text():
  for _ in range(3):
   try:
    with urllib.request.urlopen(url,timeout=35) as r:data=r.read()
    file.write_bytes(data)
    if b'$$SOE' in data:break
   except OSError:time.sleep(2)
 (out/f'{name}-{target}.url').write_text(url+'\n')
 t=file.read_text();assert '$$SOE' in t,(name,target,t[-600:])
 rr=[]
 for line in t.split('$$SOE')[1].split('$$EOE')[0].strip().splitlines():
  a=[x.strip() for x in next(csv.reader([line]))];assert len(a)==14,(len(a),a)
  date,jd,_,_,ra,dec,az,alt,illum,rng,rate,dt,dut,_=a
  rr.append(dict(site=name,longitude=lon,latitude=lat,height_km=km,body={10:'Sun',301:'Moon',2:'Venus'}[target],jd=float(jd),ra=float(ra),dec=float(dec),az=float(az),alt=float(alt),illum=(float(illum)/100 if illum!='n.a.' else None),range_au=float(rng),dt=float(dt),dut=float(dut) if dut!='n.a.' else 0))
 assert [r['jd'] for r in rr] == list(epochs.jd), name
 return rr
if __name__=='__main__':
 # Horizons requests are serialized to respect JPL's fair-use guidelines.
 rows=[]
 for name in sites:
  for target in (301,10,2):
   rr=fetch((name,target));rows.extend(rr);print(name,target,len(rr),flush=True)
 pd.DataFrame(rows).to_csv('horizons.csv',index=False)
