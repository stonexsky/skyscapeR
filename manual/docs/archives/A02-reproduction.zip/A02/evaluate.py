"""Evaluate the JPL ASCII ephemerides directly and check against JPL testpo."""
from pathlib import Path
import re
import numpy as np
import pandas as pd
from numpy.polynomial.chebyshev import chebval, chebder
from sources import coeff
ids=dict(zip('Sun Moon Mercury Venus Mars Jupiter Saturn Uranus Neptune Pluto'.split(),[11,10,1,2,4,5,6,7,8,9]))
for n,header in [(431,'header.431_572'),(441,'header.441')]:
    groups=re.split(r'GROUP\s+\d+',Path('inputs',header).read_text())
    names=groups[3].split()[1:]
    values=groups[4].replace('D','E').split()[1:]
    c=dict(zip(names,map(float,values)))
    ptr=np.array([list(map(int,line.split())) for line in groups[5].strip().splitlines()[:3]]).T
    records={}
    for p in Path('inputs',str(n)).glob('*.r*'):
        arr=coeff(p.read_bytes())[2:]
        records[arr[0]]=arr
    def state(arr,jd,body,vel=False):
        def raw(idx):
            offset,k,m=ptr[idx]
            t=(jd-arr[0])*m/32
            seg=min(int(t),m-1)
            vec=arr[offset-1+3*k*seg:offset-1+3*k*(seg+1)].reshape(3,k)
            return np.array([chebval(2*(t-seg)-1,chebder(axis)*2*m/32 if vel else axis) for axis in vec])
        if body==12:return np.zeros(3)
        if body in [3,10,13]:
            emb=raw(2)
            if body==13:return emb
            moon=raw(9)
            earth=emb-moon/(1+c['EMRAT'])
            return earth if body==3 else earth+moon
        return raw(body-1)
    def locate(jd):
        return next((arr for lo,arr in records.items() if lo<=jd<lo+32),None)
    tests=[]
    with open(f'inputs/testpo.{n}') as stream:
        for line in stream:
            row=line.split()
            if len(row)!=7 or row[0]!=str(n):continue
            jd=float(row[2]);target,center,component=map(int,row[3:6]);arr=locate(jd)
            if arr is None or not (1<=target<=13 and 1<=center<=13 and 1<=component<=6):continue
            vector=state(arr,jd,target,component>3)-state(arr,jd,center,component>3)
            tests.append(dict(jd=jd,target=target,center=center,component=component,error=vector[(component-1)%3]/c['AU']-float(row[6])))
    t=pd.DataFrame(tests);assert len(t)>0 and t.error.abs().max()<1e-12,t
    t.to_csv(f'results/evaluator-check-{n}.csv',index=False)
    s=pd.read_csv(f'results/geometric-{n}.csv')
    results=[]
    for r in s.itertuples():
        arr=locate(r.jd);v=(state(arr,r.jd,ids[r.body])-state(arr,r.jd,3))/c['AU']
        swiss=np.array([r.x,r.y,r.z]);u=swiss/np.linalg.norm(swiss);w=v/np.linalg.norm(v)
        sep=np.rad2deg(np.arctan2(np.linalg.norm(np.cross(u,w)),u@w))*3600
        signed_ra=(np.rad2deg(np.arctan2(u[1],u[0])-np.arctan2(w[1],w[0]))+180)%360-180
        results.append(dict(jd=r.jd,body=r.body,separation_arcsec=sep,ra_arcsec=signed_ra*3600,dec_arcsec=np.rad2deg(np.arcsin(u[2])-np.arcsin(w[2]))*3600,range_error_km=(np.linalg.norm(swiss)-np.linalg.norm(v))*c['AU']))
    pd.DataFrame(results).to_csv(f'results/parent-{n}.csv',index=False)
    print(n,len(t),t.error.abs().max(),pd.DataFrame(results).groupby('body').separation_arcsec.max())
