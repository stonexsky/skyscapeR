import tempfile,os,shutil,subprocess
from pathlib import Path
from csv import DictReader
src=Path(os.environ['SE_EPHE_PATH'])
out=Path('results/coverage.csv');out.unlink(missing_ok=True)
for case,files,jd,expected in [
 ('empty',[],2451545,'error'),('planet only',['sepl'],2451545,'error'),('moon only',['semo'],2451545,'error'),('pair',['sepl','semo'],2451545,'success'),('outside block',['sepl','semo'],2000000,'error'),('before block',['sepl','semo'],2378496.49,'error'),('corrupt planet',['sepl','semo'],2451545,'error')]:
    with tempfile.TemporaryDirectory() as d:
        for prefix in files:
            name=prefix+'_18.se1'
            if case=='corrupt planet' and prefix=='sepl':Path(d,name).write_bytes(b'invalid\n'*128)
            else:shutil.copyfile(src/name,Path(d,name))
        subprocess.run([os.environ.get('R_BIN','R'),'--vanilla','--slave','-f','coverage.R','--args',case,str(jd)],env=dict(os.environ,SE_EPHE_PATH=d),check=True)
        val=list(DictReader(out.open()))[-1]['package']
        assert val==('skyscapeR_ephemeris_error' if expected=='error' else 'success'),(case,val)
