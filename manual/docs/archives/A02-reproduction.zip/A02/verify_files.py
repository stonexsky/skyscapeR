"""Verify a supplied Swiss installation against this run's pinned file hashes."""
from pathlib import Path
import sys,csv,hashlib
generation,src=sys.argv[1:]
with open(f'results/manifest-{generation}.csv') as f:
    for row in csv.DictReader(f):
        p=Path(src,row['file'])
        assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],p
print(f'DE{generation} file hashes verified')
