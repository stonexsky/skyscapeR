Run Rscript banks.R, Rscript public.R, python3 calibrate.py and python3 verify.py. Fresh reference draws are generated for each of the 34,000 datasets.
Run with skyscapeR 2.0.9016. Run commands in the extracted directory.
