"""Three-way stellar visibility benchmark. Run from the directory containing stellar/."""
from pathlib import Path
from types import SimpleNamespace
from datetime import date
import numpy as np
import pandas as pd
import sys
D=Path(__file__).resolve().parent
rad=np.pi/180
ep={y:t for y,t in pd.read_csv(D/'physical-ephemeris.csv').groupby('year')}
ref=pd.read_csv(D/'physical-refraction.csv')
def limiting(b):
    dark=b<10**3.17
    c=np.where(dark,10**-9.80,10**-8.35)
    k=np.where(dark,10**-1.90,10**-5.90)
    return -16.57-2.5*np.log10(c*(1+np.sqrt(k*b))**2)
def night_background(lim,k,plus=False):
    intensity=10**(-.4*(16.57+lim+k))
    switch=limiting(10**3.17)
    c,coef=(10**-9.8,10**-1.9) if lim+k>=switch else (10**-8.35,10**-5.9)
    return (np.sqrt(intensity/c)+(1 if plus else -1))**2/coef
def inc(b):
    b=b*1e-5/np.pi
    return np.where(b<.0708,(6.505e-4*b**.25-8.461e-4*b**.5)**2,(1.772e-4*b**.25+7.167e-5*b**.5)**2)
def patat(h):
    x=-h-5
    return 34.08*np.exp(20.7233-.92104*(11.84+1.518*x-.057*x*x))
def local_background(h,alt,da):
    unit=10.76391*np.pi*1e5
    zen=10**np.interp(h,[-18,-15,-5,-3,0],np.log10([60,patat(-15),patat(-5),unit,8*unit]))
    zen=np.where((h>=-15)&(h<=-5),patat(h),zen)
    f=np.clip((h+6)/3,0,2)
    w=(1+np.cos(da))/2
    directions=([(.9,.7,.18,.06,.033,.022),(20,15,4.7,1.9,1.3,1),(150,150,37,16.5,9.5,8)],
                [(.078,.068,.043,.035,.025,.022),(2.4,2,2.1,1.6,1.1,1),(38,37,22,14,9.5,8)])
    grad=0
    for weight,rows in zip([w,1-w],directions):
        for i,row in enumerate(rows):
            grad+=weight*np.maximum(0,1-abs(f-i))*np.interp(alt,[0,10,30,50,70,90],np.log(np.array(row)/row[-1]))
    return 60+np.maximum(0,zen-60)*np.exp(grad)
def horizontal(ha,dec,lat):
    ha,dec,lat=ha*rad,dec*rad,lat*rad
    east=-np.cos(dec)*np.sin(ha)
    north=np.sin(dec)*np.cos(lat)-np.cos(dec)*np.cos(ha)*np.sin(lat)
    up=np.sin(dec)*np.sin(lat)+np.cos(dec)*np.cos(ha)*np.cos(lat)
    return np.arcsin(np.clip(up,-1,1))/rad,np.arctan2(east,north)
def run(x,year,days,step=1,reference=False,plus=False):
    e=ep[year]; base=e.jd.iloc[0]
    first=base+3
    minutes=np.arange(0,720.001,step)+(0 if x.phase=='MF1' else 720)
    times=first+np.asarray(days)[:,None]+(minutes[None,:]-4*x.lon)/1440
    st=(e.jd-base)*360.98564736629
    drift=np.unwrap((e.sid-st)*rad)/rad
    sid=(times-base)*360.98564736629+np.interp(times,e.jd,drift)+x.lon
    solarra=np.interp(times,e.jd,np.unwrap(e.ra*rad)/rad)
    h,az=horizontal(sid-solarra,np.interp(times,e.jd,e.dec),x.lat)
    hg,za=horizontal(sid-x.ra,x.dec,x.lat)
    alt=hg if reference else np.interp(hg,ref.alt,ref.apparent,left=-90)
    da=np.abs((az-za+np.pi)%(2*np.pi)-np.pi)
    z=(90-alt)*rad
    sine=np.sin(np.maximum(0,alt)*rad)
    loss=x.k/(sine+.025*np.exp(-11*sine))
    logb=4.75-da*z/3+h*rad*(12+8.21*z)+2.86*z
    b=night_background(x.lim,x.k,plus)+x.k/.2*np.maximum(0,10**logb-118)
    sch=limiting(b)-loss-x.mag
    sk=x.lim-2.5*np.log10(inc(local_background(h,alt,da))/inc(60))-loss-x.mag
    star_west=np.sin((sid-x.ra)*rad)>0
    ok=(alt>x.horizon)&(h<0)&(star_west if x.phase=='EL1' else ~star_west)
    outputs=[]
    for margin in [sch,sk]:
        mg=np.where(ok,margin,-100.)
        i=mg.argmax(axis=1)
        outputs.append((mg[np.arange(len(days)),i],times[np.arange(len(days)),i]))
    return outputs
