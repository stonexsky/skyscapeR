library(skyscapeR)
d <- read.csv("stellar/physical-table3.csv")[1:6]
historical <- read.csv("stellar/physical-historical-coords.csv")
eq <- unique(read.csv("stellar/physical-ephemeris.csv")[c("year","equinox")])
run <- function(i) {
 x <- d[i,]; sirius <- x$star=="Sirius"
 obj <- star(x$star,1950)
 pos <- if(sirius) c(101.09,-16.69) else c(221.05,27.15)
 if(x$year!=1950) pos <- unlist(subset(historical,year==x$year & star==x$star)[c("ra","dec")])
 obj$coord[2:3] <- pos
 obj$app.mag <- if(sirius) -1.46 else 2.40
 p <- star.phases(obj,x$year,c(x$lat,0,0),k=x$k,limit=x$lim,refraction=FALSE)
 ev <- p$metadata$events
 label <- if(sirius) "heliacal rising" else "acronycal setting"
 day <- time2jd(paste(ev$date.julian[ev$event==label],"00:00:00"),"UTC","J")
 equinox <- eq$equinox[eq$year==x$year]
 if(day < equinox) {
   next.events <- star.phases(obj,x$year+1L,c(x$lat,0,0),k=x$k,limit=x$lim,refraction=FALSE)$metadata$events
   day <- time2jd(paste(next.events$date.julian[next.events$event==label],"00:00:00"),"UTC","J")
 }
 data.frame(x,midpoint=day+.5-equinox)
}
result <- do.call(rbind,lapply(seq_len(nrow(d)),run))
write.csv(result,"current/table.csv",row.names=FALSE)
