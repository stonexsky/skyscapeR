library(skyscapeR)
skyscapeR.vars(timezone="UTC",calendar="G",refraction=TRUE)
sites <- list(Seattle=c(47+39/60,-(122+19/60),107),Tashla=c(43.23222,27.95722,300),Varna=c(43.20778,27.91,62),Rila=c(42.20778,23.32694,2233))
timed <- read.csv("stellar/timed.csv")
source("stellar/contrast.R")
run <- function(i){
 x <- timed[i,];loc <- sites[[x$site]];h <- createHor(0:359,rep(x$horizon,360),loc)
 k <- if(is.finite(x$k)) x$k else .2
 key <- if(x$name=="Sirius") "alf CMa" else "alf CMi"
 t <- time2jd(paste(gsub("-","/",x$date),x$ut),"UTC","G")
 p <- star.phases(x$name,as.integer(substr(x$date,1,4)),loc,alt.hor=x$horizon,solar.alt=-6,k=k)
 label <- if(x$phase=="MF1") "heliacal rising" else "acronycal setting"
 ev <- subset(p$metadata$events,event==label)
 phase.error <- if(nrow(ev)==1) time2jd(paste(ev$date.julian,"00:00"),"UTC","J")-floor(t-.5)-.5 else NA_real_
 off <- -40:65
 mm <- t(vapply(off,function(o)margin(h,t+o/1440,k,key,.5),numeric(2)))
 data.frame(i,offset=off,mm,phase.error)
}
dir.create("current/minutes",showWarnings=FALSE)
parallel::mclapply(seq_len(nrow(timed)),function(i)write.csv(run(i),sprintf("current/minutes/%02d.csv",i),row.names=FALSE),mc.cores=4,mc.preschedule=FALSE)
