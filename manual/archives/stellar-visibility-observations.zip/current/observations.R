source("stellar/phase-core.R")
cases <- read.csv("stellar/physical-cases.csv")
run <- function(i) {
 x <- cases[i,]
 p <- star.phases(lookup(x$key),as.integer(substr(x$date,1,4)),c(x$lat,x$lon,x$elev),alt.hor=x$horizon,k=x$k,limit=x$lim)
 e <- p$metadata$events
 morning <- x$phase %in% c("MF1","R")
 e <- e[e$event==if(morning) "heliacal rising" else "acronycal setting",]
 jd <- epoch(x$date)
 cal <- p$metadata$visibility.calendar
 visible <- if(morning) cal$morning else cal$evening
 data.frame(x,events=nrow(e),delta=if(nrow(e)==1) time2jd(paste(e$date.julian,"00:00:00"),"UTC","J")-jd else NA,visible=visible[match(jd,cal$local.jd)])
}
rows <- parallel::mclapply(seq_len(nrow(cases)),function(i) tryCatch(run(i),error=function(e) {cat(i,conditionMessage(e),"\n",file="current/errors",append=TRUE); NULL}),mc.cores=3)
stopifnot(all(vapply(rows,is.data.frame,logical(1))))
write.csv(do.call(rbind,rows),"current/observations.csv",row.names=FALSE)
session <- subset(do.call(rbind,rows),set=="session")
record <- subset(read.csv("stellar/cutoff-sessions.csv"),depression==6)
out <- merge(session,record[c("id","seen","marginal")],by="id")
out$correct <- out$visible==out$seen
write.csv(out,"current/sessions.csv",row.names=FALSE)
