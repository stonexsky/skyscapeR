"""Fractional last-evening boundary for the 60 N Izar row in Schaefer's Table 3."""
from pathlib import Path
from types import SimpleNamespace
import runpy
import numpy as np
import pandas as pd

model = runpy.run_path(str(Path(__file__).with_name('twilight-threshold.py')))
star = SimpleNamespace(phase='EL1', ra=221.05, dec=27.15, mag=2.40, lat=60,
                       lon=0, k=.2, lim=6, horizon=0)
eph = model['ep'][1950]
equinox = eph.equinox.iloc[0]
start = int(equinox - (eph.jd.iloc[0]+3) + 284.3)
rows = []
for minutes in [2, 1, .5, .25, .125]:
    margin, instant = model['run'](star,1950,np.arange(start-10,start+13),minutes,True)[0]
    edge, = np.flatnonzero((margin[:-1]>=0) & (margin[1:]<0))
    f = margin[edge]/(margin[edge]-margin[edge+1])
    days = instant[edge] + f*(instant[edge+1]-instant[edge]) - equinox
    rows.append((minutes,days,days-284.3))
pd.DataFrame(rows,columns=['step_minutes','days_from_equinox','minus_published_days']).to_csv('current/izar-sampling.csv', index=False)
