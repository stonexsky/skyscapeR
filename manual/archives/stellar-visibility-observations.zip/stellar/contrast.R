inc <- function(B) ifelse(B<.0708,(6.505e-4*B^.25-8.461e-4*sqrt(B))^2,(1.772e-4*B^.25+7.167e-5*sqrt(B))^2)
per.nl <- 3600^2/(34.08*exp(20.7233))
margin <- function(h,jd,k,key,cut){
 s <- sketchSky(h,jd=jd,max.mag=cut,k=k,display=list(milky.way=TRUE))
 p <- s$stars[key,]; if(p[2]<=h$data$alt[1]) return(c(alt=p[[2]],margin=-Inf))
 f <- skyRadiance(s,p[1]+c(-.005,.005),p[2]+c(-.005,.005),c(1,1))
 B <- (f$radiance-f$direct)/per.nl*1e-5/pi
 c(alt=p[[2]],margin=as.numeric(6-2.5*log10(inc(B)/inc(60e-5/pi))+2.5*log10(s$light.budget$stars[key])))
}
