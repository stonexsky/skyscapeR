library(skyscapeR)
skyscapeR.vars(timezone="UTC",calendar="G",refraction=TRUE)
catalog <- read.csv("stellar/catalog.csv")
catalog$key <- sub("mu[.]Gem","muGem",sub("the-2Tau","tet02Tau",catalog$key))
# Read the identifier as stored in the stellar catalogue, including spaces.
ident <- skyscapeR:::.read_star_catalogue()$identifier
lookup <- function(key) ident[match(tolower(gsub(" ","",key)),tolower(gsub(" ","",ident)))]
epoch <- function(date) time2jd(paste0(gsub("-","/",date)," 00:00:00"),"UTC","G")
calcphase <- function(x,k,h=0,solar=-6){
 p <- star.phases(lookup(x$key),as.integer(substr(x$date,1,4)),c(x$lat,x$lon,x$elev),alt.hor=h,solar.alt=solar,k=k)
 ev <- p$metadata$events
 # Last evening before invisibility and first morning after invisibility.
 label <- if(x$phase=="EL1") "acronycal setting" else "heliacal rising"
 dates <- ev$date.julian[ev$event==label]
 if(length(dates)!=1) return(NA_real_)
 time2jd(paste(dates,"00:00:00"),"UTC","J")-epoch(x$date)
}
