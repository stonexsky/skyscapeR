suppressPackageStartupMessages(library(skyscapeR))
skyscapeR.vars(refraction=FALSE)
ns<-asNamespace("skyscapeR")
# Capture numeric arguments at the real drawing call, then draw on the PNG device.
# Both namespace-qualified and imported graphics calls are monitored.
events<-list()
hook<-function(env,name){
 original<-get(name,env,inherits=FALSE)
 wrapper<-function(...){
  a<-list(...);events[[length(events)+1L]]<<-list(kind=name,args=a)
  original(...)
 }
 unlockBinding(name,env);assign(name,wrapper,env);lockBinding(name,env)
}
for(env in list(asNamespace("graphics"),parent.env(ns))){
 for(name in c("segments","polygon","lines","text","mtext","axis","rect"))
  if(exists(name,env,inherits=FALSE))hook(env,name)
}
hit<-function(type,test)any(vapply(events,function(e)e$kind==type && isTRUE(tryCatch(test(e$args),error=function(err)FALSE)),logical(1)))
eq<-function(a,b)length(a)==length(b)&&isTRUE(max(abs(a-b))<1e-7)
labels<-function()unlist(lapply(events,function(e)if(e$kind %in% c("text","mtext","axis")) unlist(e$args[intersect(names(e$args),"labels")]) else NULL))
rows<-list()
check<-function(label,ok){rows[[length(rows)+1L]]<<-data.frame(style,dpi,fig,label,pass=isTRUE(ok))}
dir.create("renders",showWarnings=FALSE)
start<-function(id){
 fig<<-id;events<<-list()
 png(file.path("renders",paste(style,dpi,id,sep="-") |> paste0(".png")),width=8,height=5,units="in",res=dpi)
}
band<-structure(list(decs=matrix(c(-5,10),2,dimnames=list(NULL,"Band")),epoch=c(-2000,2000),loc=c(50,0,0),n=1,col="red",lty=1,lwd=1),class="skyscapeR.object")
flat<-createHor(az=c(0,360),alt=c(0,0),loc=c(50,0,0),verbose=FALSE)
terrain<-createHor(az=c(0,90,180,270,360),alt=c(0,5,0,2,0),loc=c(50,0,0),verbose=FALSE)
p<-dec.pdf(0,2,name="Two peaks",verbose=FALSE);x<-seq(-12,12,.1)
p$data[[1]]<-data.frame(x,y=dnorm(x,-5,1)+dnorm(x,5,1))
den<-spd(p,xrange=c(-12,12),.res=.1)
xx<-0:360;yy<-(1+cos(xx*pi/180))/2
fit<-structure(list(metadata=list(coord="az",nsims=99,conf=.95,tails=2,global.pval=.03,
 local.inference="maximum-cluster-v1",local.pval=data.frame(type=c("+","-"),start=c(349,80),end=c(10,96),p.value=c(.02,.08))),
 data=list(empirical=data.frame(x=xx,y=yy),null.hyp=list(x=xx,CE.upper=.75+yy/8,CE.lower=.25-yy/8))),class="skyscapeR.sigTest")
phase<-function(name,epoch,site,shift){
 codes<-rep(c("I","R","RS","S","V"),c(65,70,100,54,76));if(shift)codes<-c(tail(codes,shift),head(codes,-shift))
 structure(list(metadata=list(star=list(name=name,Bayer=paste0("Bayer ",name),app.mag=1),year=epoch,loc=c(50,0,0),site.name=site),data=data.frame(day=1:365,phase=codes)),class="skyscapeR.starphases")
}
z<-phase("Aldebaran",2000,"Site A",0);z2<-phase("Sirius",1800,"Site B",20)
for(style in c("publication-colour","publication-mono"))for(dpi in c(96,180)){
 start("compass");az<-c(359,1,90,180)
 plotAzimuth(az,obj=list(period=band),obj.position="outside",style=style)
 check("true bearing spokes",hit("segments",function(a)eq(a[[3]],sin(az*pi/180))&&eq(a[[4]],cos(az*pi/180))))
 bounds<-sort(acos(sin(c(-5,10)*pi/180)/cos(50*pi/180))*180/pi)
 for(lim in list(bounds,360-rev(bounds)))check("range sector",hit("polygon",function(a){
  xy<-a[[1]];degs<-(atan2(xy[,1],xy[,2])*180/pi)%%360
  eq(range(degs),lim)&&eq(range(sqrt(rowSums(xy^2))),c(1.01,1.16))
 }))
 check("cardinal labels",hit("text",function(a)identical(a[[2]],c("N","NE","E","SE","S","SW","W","NW"))))
 dev.off()
 start("bars");plotBars(c(360,45),unc=c(2,5),names=c("Opening","Other"),unit="Azimuth",sort=FALSE,style=style,mark=TRUE)
 check("north crossing bar edges",hit("segments",function(a)eq(a[[1]],c(358,40))&&eq(a[[3]],c(362,50))))
 check("bar row association",hit("axis",function(a)identical(as.character(a$labels),c("Opening","Other"))))
 dev.off()
 for(id in c("flat","terrain")){
  h<-if(id=="flat") flat else terrain
  start(id);plot(h,xrange=c(80,110),yrange=c(-1,7),use.image=FALSE,style=style)
  check("terrain ordinate at 90",hit("lines",function(a) eq(a[[2]][match(90,a[[1]])],if(id=="flat")0 else 5)))
  check("terrain viewport clips to requested bearings",eq(par("usr")[1:2],c(80,110)));dev.off()
 }
 start("pdf");plot(p,hdr=.8,style=style)
 hdr<-hpdi(p,.8)[[1]]
 check("two HDR components",nrow(hdr)==2)
 for(j in 1:2)check("HDR polygon endpoints",hit("polygon",function(a)eq(range(a[[1]]),hdr[j,])))
 dev.off()
 start("sum");plot(den,style=style)
 check("summed density outline",hit("lines",function(a)eq(a[[1]],den$data$x)&&eq(a[[2]],den$data$y)));dev.off()
 for(id in c("full","wrapped")){
  start(paste0("sig-",id))
  lim<-if(id=="full")c(0,360) else c(350,15)
  plot(fit,xrange=lim,show.local=TRUE,style=style)
  bounds<-if(id=="full")list(c(0,10),c(349,360),c(80,96)) else list(c(350,370))
  for(b in bounds)check("clipped local segment",hit("segments",function(a)eq(c(a[[1]],a[[3]]),b)&&identical(a$lwd,3)))
  check("p-value label",hit("mtext",function(a)grepl("Global p = 0.03",a[[1]],fixed=TRUE)))
  check("pointwise envelope",hit("polygon",function(a)eq(a[[2]],c(fit$data$null.hyp$CE.upper,rev(fit$data$null.hyp$CE.lower)))))
  dev.off()
 }
 for(layout in c("linear","circular")){
  start(layout);plot(z,z2,layout=layout,style=style)
  if(layout=="linear"){
   for(ab in list(c(0,65),c(65,135),c(135,235),c(235,289),c(289,365)))check("first-row season endpoints",hit("polygon",function(a)eq(range(a[[1]]),ab)&&mean(a[[2]])>1.5))
   check("calendar dividers",hit("segments",function(a)eq(a[[1]],(0:12)*365/12)))
  }else{
   check("first ring first season",hit("polygon",function(a){
    deg<-(atan2(a[[1]],a[[2]])*180/pi)%%360
    max(deg)<66*360/365 && eq(max(deg),65*360/365)
   }))
   check("quarter labels",all(vapply(c("Dec. sol.","Mar. eq.","Jun. sol.","Sep. eq."),function(l)hit("text",function(a)identical(a[[3]],l)),logical(1))))
  }
  for(tag in c("Aldebaran","Sirius","Site A","Site B","1800","2000"))check("star/site/epoch identification",any(grepl(tag,c(labels(),unlist(lapply(events,function(e)if(e$kind=="text")as.character(e$args[[3]]) else ""))),fixed=TRUE)))
  dev.off()
 }
}
for(style in c("natural","publication-colour","publication-mono"))for(dpi in c(96,180)){
 start("sky-overlay")
 sky<-sketchSky(terrain,jd=2451545,style=style,max.mag=2,
                display=list(stars=FALSE,milky.way=FALSE,moon=FALSE,sun=TRUE))
 plot(terrain,sky=sky,xrange=c(80,110),yrange=c(-1,7),use.image=FALSE,show.skyline=TRUE)
 check("sky overlay retains measured ridge",hit("lines",function(a)eq(a[[2]][match(90,a[[1]])],5)))
 check("sky viewport",eq(par("usr"),c(80,110,-1,7)));dev.off()
}
style<-"publication-colour";dpi<-120
start("groups")
second<-band;second$epoch<-c(-1200,1000);second$col<-"blue";second$decs[,1]<-c(15,20)
plotAzimuth(c(0,1),obj=list(first=band,second=second),style=style)
for(g in list(band,second)){
 period<-paste(vapply(g$epoch,function(y)as.character(BC.AD(y)),character(1)),collapse=" to ")
 check("same target gets its correct epoch and colour",hit("text",function(a)
  any(grepl(period,a[[3]],fixed=TRUE))&&identical(unname(a$col),g$col)))
}
dev.off()
for(layout in c("linear","circular")){
 zz<-phase("Aldebaran",-1000,"Site A",20)
 start(paste0("epochs-",layout));plot(z,zz,layout=layout)
 for(year in c("2000","1001"))check("epoch label",hit("text",function(a)length(a)>=3 && any(grepl(year,a[[3]],fixed=TRUE))))
 dev.off()
}
start("single-seasons");plot(z,layout="linear")
events.ref<-skyscapeR:::.phase_plot_events(z)
check("ascending transitions",identical(order(events.ref$day),seq_len(nrow(events.ref))))
check("stored seasonal boundary days",eq(events.ref$day,c(0,65,288,364)))
for(day in events.ref$day)check("event leader starts on reference day",hit("segments",function(a)any(abs(a[[1]]-day)<1e-8)))
dev.off()

r<-do.call(rbind,rows)
write.csv(r,"plot-checks.csv",row.names=FALSE)
print(subset(r,!pass))
output<-capture.output(print(fit));writeLines(output,"printed.txt")
stopifnot(all(r$pass),any(grepl("[349, 10]",output,fixed=TRUE)),any(grepl("0.02",output,fixed=TRUE)),any(grepl("[80, 96]",output,fixed=TRUE)))
