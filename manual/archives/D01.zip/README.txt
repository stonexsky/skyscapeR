Run measurement-densities.R, then from the legacy directory run D01.R and D01-extra.R. This directory contains the analytic reference fixtures.
Current package run: skyscapeR 2.0.9015, revision fec1c516e8cf9b8caa0bb560fe797dc1c7847b18. Run commands in the extracted directory.
