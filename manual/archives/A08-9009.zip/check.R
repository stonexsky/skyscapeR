suppressPackageStartupMessages(library(skyscapeR));library(swephR)
v<-as.character(packageVersion("skyscapeR"));skyscapeR.vars(refraction=FALSE,calendar="G")
rows<-list()
check<-function(case,actual,expected,tol=0){
 a<-tryCatch(actual,error=function(e)paste("ERROR",conditionMessage(e)))
 error<-if(is.numeric(a)&&is.numeric(expected)&&length(a)==length(expected))max(abs(a-expected)) else NA_real_
 pass<-if(is.numeric(expected))isTRUE(error<=tol) else identical(as.character(a),as.character(expected))
 rows[[length(rows)+1]]<<-data.frame(case,actual=paste(a,collapse=" / "),expected=paste(expected,collapse=" / "),error,tol,pass)
}
for(yr in list(c(2000,2001),c(2000,2000),c(1810,2025),c(-3400,-3100))){
 ys<-seq(min(yr),max(yr));eps<-vapply(ys,function(y)swe_calc_ut(swe_julday(y,1,1,12,1),-1L,2L)$xx[1],numeric(1))
 for(lat in c(0,50,-35)){
  g<-try(skyObject(c('solar extremes','lunar extremes'),yr,loc=c(lat,0,0),col=c("red","blue")),silent=TRUE); if(inherits(g,"try-error")){check(paste("group range",lat,paste(yr,collapse="-")),as.character(g),"successful");next}
  check(paste("style mapping",paste(yr,collapse="-"),lat),g$col,rep(c("blue","red"),c(4,2)))
  for(id in colnames(g$decs)){
   ix<-switch(id,dS=-eps,jS=eps,nMjLX=eps+5.29,nmnLX=eps-5.29,sMjLX=-eps-5.29,smnLX=-eps+5.29)
   shift<-if(id %in% c('dS','jS')).00224 else .952
   check(paste("annual envelope",id,lat,paste(yr,collapse="-")),g$decs[,id],range(ix-shift*sin(lat*pi/180)),1e-10)
  }
 }
}
# Annual direct engine calls reproduce the documented barycentric star positions;
# separate reference code determines membership and interpolated dates.
ids<-c("alf CMa","alf Car")
annual<-function(id,years){
 jd<-vapply(years,swe_julday,numeric(1),month=1L,day=1L,hourd=12,gregflag=1L)
 z<-swe_fixstar2_ut(paste0(",",id),jd,18450L);stopifnot(all(z$return>=0))
 matrix(z$xx,nrow=length(jd))[,2]
}
# Choose a real internal turning point; both endpoints of its neighbourhood
# lie below or above the extreme. Include a band crossed twice and a tangency.
long<-(-5000):2000;track<-annual(ids[1],long)
turn<-which(diff(sign(diff(track)))!=0)+1L
win<-NULL
for(m in turn){
 ix<-max(1,m-6):min(length(long),m+6)
 if(length(ix)<13)next
 xx<-track[ix];if(xx[7]==max(xx)&&xx[7]>max(xx[c(1,13)])+.0001){win<-ix;break}
}
stopifnot(length(win)>0)
yr<-range(long[win]);ys<-seq(yr[1],yr[2]);short<-annual(ids[1],ys);peak<-max(short);floor<-max(short[c(1,13)])
refIntervals<-function(x,y,band){
 intervals<-list()
 for(i in seq_len(length(x)-1)){
  seg<-y[i+0:1];if(max(seg)<band[1] || min(seg)>band[2])next
  ends<-if(diff(seg)==0)c(0,1) else sort(pmin(1,pmax(0,(band-seg[1])/diff(seg))))
  lo<-x[i]+ends[1];hi<-x[i]+ends[2]
  if(length(intervals)&&abs(tail(intervals,1)[[1]][2]-lo)<1e-8)intervals[[length(intervals)]][2]<-hi
  else intervals[[length(intervals)+1]]<-c(lo,hi)
 }
 era<-function(t)ifelse(t<=0,paste(1-t,"BC"),paste(t,"AD"))
 paste(vapply(intervals,function(b)paste(era(round(b)),collapse=" - "),character(1)),collapse=" and ")
}
for(type in c("double","tangent","above")){
 band<-switch(type,double=floor+(peak-floor)*c(.35,.65),tangent=rep(peak,2),above=peak+c(.02,.03))
 f<-findTargets(band,yr,max.mag=-.7,dates=TRUE)
 for(id in ids){
  direct<-annual(id,ys);for(b in band)direct[abs(direct-b)<=1e-7]<-b;span<-range(direct)
  member<-max(band)>=span[1] && min(band)<=span[2]
  if(type=="tangent" && id==ids[1])stopifnot(member)
  selected<-if(is.data.frame(f$stellar))f$stellar[f$stellar$identifier==id,,drop=FALSE] else NULL
  check(paste(type,id,"membership"),NROW(selected)>0,member)
  if(member && NROW(selected)){
   check(paste(type,id,"years"),selected$daterange,refIntervals(ys,direct,band))
   check(paste(type,id,"limits"),unname(unlist(selected[c("min.dec","max.dec")])),round(span,2),1e-10)
  }
 }
}
mag<-star("Sirius",2000)$app.mag
for(cut in c(mag-.001,mag)){
 f<-findTargets(rep(peak,2),yr,max.mag=cut,dates=TRUE)
 check(paste("magnitude threshold",cut),ids[1] %in% f$stellar$identifier,cut>=mag)
}
check("magnitude exclusion",NROW(findTargets(rep(peak,2),yr,max.mag=-2)$stellar),0)
for(n in c("Sirius","alf CMa","ALF CMA")){
 check(paste("alias envelope",n),skyObject(n,yr)$decs[,1],range(annual("alf CMa",ys)),1e-10)
}
# The band's edge sits within a rounding unit of a displayed value.
for(id in c("jS","nMjLX")){
 x<-get(id)(2000,verbose=FALSE)
 f<-findTargets(rep(x,2),2000,max.mag=-2)
 name<-if(id=="jS")"june solstice" else "northern major lunar extreme"
 tab<-if(id=="jS")f$solar else f$lunar
 check(paste("unrounded exact membership",id),name %in% tab$name,TRUE)
 b<-if(round(x,2)>x)mean(c(x,round(x,2))) else mean(c(round(x,2),x))
 f<-findTargets(rep(b,2),2000,max.mag=-2)
 check(paste("outside rounded membership",id), name %in% (if(id=="jS")f$solar else f$lunar)$name,FALSE)
 f<-findTargets(rep(round(x,2),2),2000,max.mag=-2)
 check(paste("false positive at display value",id),name %in% (if(id=="jS")f$solar else f$lunar)$name,FALSE)
}
for(lat in c(0,-20,20,23.8)){
 yr<-c(-3249,-3248); t<-try(findTargets(rep(lat,2),yr,loc=c(lat,0,0),max.mag=-2),silent=TRUE);if(inherits(t,"try-error")){check(paste("zenith candidate",lat),as.character(t),"successful");next}
 check(paste("zenith candidate",lat),"zenith sun" %in% t$solar$name,TRUE)
 if("zenith sun" %in% t$solar$name)check(paste("zenith bounds",lat),unname(unlist(t$solar[t$solar$name=="zenith sun",c("min.dec","max.dec")])),c(lat,lat),1e-8)
}
# A nominal obliquity limit can exceed the actual maximum of date.
peakJ<-optimize(function(dt)swe_calc_ut(2451716+dt,0L,2050L)$xx[2],c(-2,2),maximum=TRUE)$objective
if(peakJ<obliquity(2000)){
 lat<-(peakJ+obliquity(2000))/2
 f<-findTargets(rep(lat,2),2000,loc=c(lat,0,0),max.mag=-2)
 check("no actual overhead passage","zenith sun" %in% f$solar$name,FALSE)
}
for(side in c("east","west")){
 angles<-c(0,20,35,145,160,200,215,325,340,360)
 h<-createHor(az=angles,alt=if(side=="east")c(0,0,7,7,0,0,0,0,0,0) else c(0,0,0,0,0,0,7,7,0,0),loc=c(50,0,0),verbose=FALSE)
 spatial<-range(unlist(spatial.equinox(h,year=2000,refraction=FALSE)$declination))
 f<-findTargets(spatial,2000,loc=h,max.mag=-2)
 result<-f$solar[f$solar$name=="spatial equinox",,drop=FALSE]
 check(paste("horizon-specific spatial",side),unname(unlist(result[c("min.dec","max.dec")])),round(spatial,2),1e-10)
}
obj<-skyObject(c("Sirius","solar extremes",5),c(2000,2001),loc=c(50,0,0),col=c("green","red","blue"),lty=c(3,2,1))
check("mixed groups names",colnames(obj$decs),c("dS","jS","Sirius","Custom Dec"))
check("mixed groups style",obj$lty,c(2,2,3,1))
check("fixed custom track",obj$decs[,4],c(5,5))
for(d in obj$decs[,2]){
 track<-orbit(d,c(50,0,0),refraction=FALSE)
 rr<-pi/180
 theoretical<-asin(sin(50*rr)*sin(track$alt*rr)+cos(50*rr)*cos(track$alt*rr)*cos(track$az*rr))/rr
 check("overlay orbit declination",max(abs(theoretical-d)),0,1e-8)
}
for(alias in c("M45","M 45","Pleiades")){
 check(paste("cluster alias",alias),skyObject(alias,c(2000,2001))$decs[,1],range(annual("M 45",2000:2001)),1e-7)
}
for(y in c(yr[1],yr[2])){
 ref<-annual(ids[1],y)
 f<-findTargets(rep(ref,2),y,max.mag=-.7,dates=TRUE)
 match<-f$stellar[f$stellar$identifier==ids[1],,drop=FALSE]
 check(paste("identical-epoch contact",y),NROW(match),1)
 if(NROW(match)) check(paste("identical-epoch dates",y),match$daterange,paste(rep(BC.AD(y),2),collapse=" - "))
}
repeated<-skyObject(c("solar extremes","solar extremes"),2000,col=c("red","blue"),lty=c(2,3))
check("repeated groups keep styles",repeated$col,c("red","red","blue","blue"))
out<-do.call(rbind,rows);write.csv(out,paste0("A08-",v,".csv"),row.names=FALSE)
print(subset(out,!pass))
