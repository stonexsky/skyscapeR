library(terra)
library(skyscapeR)
r<-rast("survey-window.tif")
station<-vect(matrix(c(412246,142194),1),crs=crs(r))
ridge<-vect(matrix(c(412206,142244,412286,142244),2,byrow=TRUE),type="lines",crs=crs(r))
bank<-horFeature(ridge,type="bank",width=8,height=6,colour="#eee8db",name="Test bank")
render<-function(name,...){
 createHor(dem=r,loc=station,name=name,az.step=1,max.distance=150,distance.step=1,
    panorama=TRUE,width=720,panorama.distance.step=1,ncores=1,progress=FALSE,verbose=FALSE,...)
}
a<-render("Relief",features=bank)
b<-render("Directional",features=bank,lighting="directional")
c<-render("Unshaded",features=bank,ambient=1,contrast=0,haze=0)
bare<-render("Ground")
height.shift<-hor2alt(a,0)-hor2alt(bare,0)
stopifnot(identical(a$data,b$data),identical(a$data,c$data),height.shift>0)
paths<-list.files(pattern="[.]png$"); stopifnot(length(paths)>=4)
imgs<-lapply(paths,png::readPNG)
stopifnot(length(unique(tools::md5sum(paths)))==length(paths))
write.csv(data.frame(azimuth=0,bare=hor2alt(bare,0),with_bank=hor2alt(a,0),
  bank_gain=height.shift,maximum_lighting_difference=max(abs(a$data$alt-b$data$alt))),"relief.csv",row.names=FALSE)
