Run Rscript check.R. Requires terra and png. Terrain is a 400 m square window from the Environment Agency bare-earth 1 m LiDAR composite, tile SU14SW, EPSG:27700, Open Government Licence. The bank is synthetic.
Current package run: skyscapeR 2.0.9015, revision fec1c516e8cf9b8caa0bb560fe797dc1c7847b18. Run commands in the extracted directory.
