"""Re-evaluate the 2020 script's published scoring convention for fixed curves."""
import numpy as np,pandas as pd
from score import segments
d=pd.read_csv('scores/historical-curves.csv');x=d.iloc[:,0].values;M=d.iloc[:,1:].values.T
sim=M[1:];z=(M-sim.mean(axis=0))/sim.std(axis=0,ddof=1)
up=np.maximum(z-np.quantile(z[1:],.9,axis=0),0)
dn=np.maximum(np.quantile(z[1:],.1,axis=0)-z,0)
def historical_p(scores):return round(np.sum(scores[1:]>=scores[0]) /len(scores),5)
rows=[dict(region='global',start='',end='',p=historical_p((up+dn).sum(axis=1)))]
for sign,part in [('+',up),('-',dn)]:
 for g in segments(part[0],x,False):
  if x[g[-1]]-x[g[0]]>5:rows.append(dict(region=sign,start=x[g[0]],end=x[g[-1]],p=historical_p(part[:,g].sum(axis=1))))
pd.DataFrame(rows).to_csv('S03-historical.csv',index=False)
