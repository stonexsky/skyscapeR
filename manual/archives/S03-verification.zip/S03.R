source('common.R')
dir.create('scores',showWarnings=FALSE)
options(digits=17)
save_fit <- function(key,x,M,fit,tails,conf){
 write.csv(data.frame(x, t(M)),file.path('scores',paste0(key,'-curves.csv')),row.names=FALSE)
 write.csv(fit$local,file.path('scores',paste0(key,'-local.csv')),row.names=FALSE)
 write.csv(data.frame(global=fit$global,tails,conf),file.path('scores',paste0(key,'-global.csv')),row.names=FALSE)
}
for(key in c('identical','isolated','tie','two-clusters','seam','half-degree','short')){
 x<-if(key=='seam')0:359 else (0:10)*if(key=='short') .249 else .25
 M<-matrix(2,9,length(x));M[1,]<-2
 if(key=='isolated') M[1,5]<-9
 if(key=='tie') M[c(1,3),3:6]<-10
 if(key=='two-clusters'){M[1,2:5]<-8;M[1,8:11]<-0;M[2,7:10]<-9;M[3,1:4]<-0}
 if(key=='seam') M[1,c(1,2,359,360)]<-9
 if(key %in% c('short','half-degree')) M[1,4:6]<-9
 for(tails in 1:2){
  obs<-data.frame(x=x,y=M[1,]);res<-skyscapeR:::.simulation_inference(obs,8,list(1:8),character(),M[-1,,drop=FALSE],.75,tails)
  save_fit(paste0(key,tails),x,M,res,tails,.75)
 }
}
# Nonconstant baselines allow both historical and current conventions to be scored.
x<-0:19;M<-t(vapply(0:15,function(k) 1+((x+3*k)%%7)/8,numeric(length(x))))
M[1,3:10]<-M[1,3:10]+1.2;M[2,12:19]<-M[2,12:19]+1.5
z<-skyscapeR:::.simulation_inference(data.frame(x=x,y=M[1,]),15,list(1:15),character(),M[-1,],.8,2)
save_fit('historical',x,M,z,2,.8)
ns<-asNamespace('skyscapeR')
trace('.simulation_inference',where=ns,print=FALSE,tracer=quote(assign('last_matrix',rbind(observed$y,memory),envir=.GlobalEnv)))
set.seed(90213)
for(key in c('random','model')){
 p<-az.pdf(c(359,2),3,.res=.5,verbose=FALSE)
 f<-if(key=='random')randomTest(p,nsims=15,conf=.8,.res=.5,ncores=1,verbose=FALSE) else modelTest(p,model=data.frame(az=c(1,90,180,270),weight=c(1,2,1,2)),nsims=15,conf=.8,.res=.5,ncores=1,verbose=FALSE)
 save_fit(key,f$data$empirical$x,last_matrix,list(local=f$metadata$local.pval,global=f$metadata$global.pval),2,.8)
 text<-capture.output(print(f));writeLines(text,paste0('scores/',key,'-print.txt'))
 check(paste(key,'printed global'),any(grepl(paste0('p-value: ',format(f$metadata$global.pval,digits=5,trim=TRUE)),text,fixed=TRUE)),TRUE)
 for(i in seq_len(nrow(f$metadata$local.pval))){r<-f$metadata$local.pval[i,];check(paste(key,'printed interval',i),any(grepl(paste0('[',round(r$start,2),', ',round(r$end,2),']'),text,fixed=TRUE)),TRUE)}
 marks<-list()
 trace('.local_mark',where=ns,print=FALSE,tracer=quote({marks[[length(marks)+1]]<<-list(x=x,symbol=symbol)}))
 pdf(paste0('scores/',key,'-plot.pdf'));plot(f,show.local=TRUE,show.legend=FALSE);dev.off()
 untrace('.local_mark',where=ns)
 for(i in seq_len(nrow(f$metadata$local.pval))){r<-f$metadata$local.pval[i,]
  check(paste(key,'plotted cluster',i),any(vapply(marks,function(z) abs(z$x-mean(c(r$start,r$end)))<1e-8 && z$symbol==pval2stars(r$p.value),logical(1))),TRUE)}
}
untrace('.simulation_inference',where=ns)
check('symbol boundaries',pval2stars(c(0,.001,.00101,.01,.0101,.05,.0501,.1,.101,1)),c('***','***','**','**','*','*','+','+','○','○'))
check('legacy printed bound',pval2stars('< 0.05'),'*')
for(n in c(0,4,8,1000)) for(p in c(0,.2,.5,1)) for(r in unique(c(0,n%/%2,n))) for(type in c('tail','single')){
 # Compute binomial probabilities from log combinations with explicit handling of endpoints.
 k<-if(type=='single')r else r:n
 expected<-if(p==0) as.numeric(0 %in% k) else if(p==1) as.numeric(n %in% k) else sum(exp(lchoose(n,k)+k*log(p)+(n-k)*log1p(-p)))
 check(paste('binomial',n,p,r,type),bernoulli.trial(n,p,r,type),expected,2e-12)
}
save_results('S03-helper-results.csv')
