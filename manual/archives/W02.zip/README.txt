Run field.R, replay.R, position.R and verify-current.py. full-group.R regenerates the separate fixed 500-simulation control.
