library(swephR)
for(f in c('ephemeris.R','dates.R','misc.R','mechanics.R','horizon-events.R','crescent-crossovers.R','events.R')) source(file.path('skyscapeR/R',f))
skyscapeR.env<-list(calendar='G',timezone='UTC',dec='geo',refraction=TRUE,atm=1013.25,temp=15,cur.year=2026)
.sky_progress<-function(...) FALSE
.file_position<-function(jd,body,flags,...) {r<-swephR::swe_calc_ut(jd,body,bitwOr(as.integer(flags),2L));stopifnot(all(r$return>=0),all(bitwAnd(r$return,7L)==2L));r}
swe_set_ephe_path(normalizePath('efm-review/ephe'))
x<-read.csv('crossover-validation/comparisons.csv');x<-x[x$lat==40 & x$simulation=='EFM',]
geo<-c(40,0,400);swe_set_topo(0,40,400);out<-list()
for(i in seq_len(nrow(x))){
 a<-x[i,];moonjd<-time2jd(paste(a$date,a$time));day<-time2jd(a$date)
 rise<-!grepl('Set',a$series);sunjd<-.cc_event(day-if(rise)0 else 1,0,if(rise)-1 else 1,geo,geo,TRUE,1013.25,15)
 for(body in 0:1){
  jd<-if(body==0)sunjd else moonjd
  eq<-.cc_calc(jd,body,2050L);top<-.cc_calc(jd,body,2050L+32768L)
  pos<-.cc_position(jd,body,geo,TRUE,1013.25,15)
  derivative<-(.cc_calc(jd+.01,body,2050L)[2]-.cc_calc(jd-.01,body,2050L)[2])/.02
  out[[length(out)+1]]<-data.frame(year=a$year,series=a$series,body=body,jd=jd,geodec=eq[2],topodec=top[2],az=pos$az,alt=pos$alt,derivative=derivative,original=if(body==0)a$sun_original else a$moon_original)
 }
}
write.csv(do.call(rbind,out),'followup-review/40N-coordinates.csv',row.names=FALSE)
