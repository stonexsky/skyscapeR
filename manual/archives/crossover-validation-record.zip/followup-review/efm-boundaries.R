library(swephR)
for(f in c('ephemeris.R','dates.R','misc.R','mechanics.R','horizon-events.R','crescent-crossovers.R','events.R')) source(file.path('skyscapeR/R',f))
skyscapeR.env<-list(calendar='G',timezone='UTC',dec='geo',refraction=TRUE,atm=1013.25,temp=15,cur.year=2026)
.sky_progress<-function(...) FALSE
.file_position<-function(jd,body,flags,...) {r<-swephR::swe_calc_ut(jd,body,bitwOr(as.integer(flags),2L));stopifnot(all(r$return>=0),all(bitwAnd(r$return,7L)==2L));r}
swe_set_ephe_path(normalizePath('efm-review/ephe'))
x<-read.csv('followup-review/efm-residuals.csv');out<-list()
for(i in 1:nrow(x)){
 a<-x[i,];geo<-c(a$lat,0,400);swe_set_topo(0,a$lat,400)
 for(delta in -1:1){day<-time2jd(a$date)+delta;moon<-.cc_event(day,1,1,geo,geo,TRUE,1013.25,15);sun<-.cc_event(day-1,0,1,geo,geo,TRUE,1013.25,15)
 out[[length(out)+1]]<-data.frame(lat=a$lat,year=a$year,series=a$series,day.offset=delta,declination=.cc_calc(moon,1,2050L)[2],original=a$moon_original,phase=moonphase(moon),az.margin=(if(a$series=='SFMSet')-1 else 1)*(.cc_position(moon,1,geo,TRUE,1013.25,15)$az-.cc_position(sun,0,geo,TRUE,1013.25,15)$az))
 }}
write.csv(do.call(rbind,out),'followup-review/efm-boundaries.csv',row.names=FALSE)
