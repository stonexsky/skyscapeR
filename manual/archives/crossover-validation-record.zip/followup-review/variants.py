from pathlib import Path
import pandas as pd
x=pd.read_csv('crossover-validation/comparisons.csv');x=x[(x.simulation=='SIM1')&(x.lat!=40)]
bad=x[x.moon_error.abs()>.02]
good=x[x.moon_error.abs()<=.02].groupby(['lat','series'],group_keys=False).sample(n=5,random_state=42)
pd.concat([bad,good]).to_csv('followup-review/variant-cases.csv',index=False)
s=Path('followup-review/recover.R').read_text().split("x<-read.csv")[0]
s+='''
original.event<-.cc_event; original.observation<-.cc_observation
x<-read.csv('followup-review/variant-cases.csv')
run<-function(i){
 swe_close();swe_set_ephe_path(normalizePath('efm-review/ephe'))
 a<-x[i,];geo<-c(a$lat,0,400);swe_set_topo(0,a$lat,400)
 season<-if(substr(a$series,1,1)=='S')'summer' else 'winter'
 crescent<-if(substr(a$series,2,2)=='F')'first' else 'last'
 out<-list()
 for(variant in c('upper-sun','geometric-moon','both')){
  .cc_event <<- original.event;.cc_observation <<- original.observation
  if(variant %in% c('upper-sun','both')) {
   f<-paste(deparse(original.event),collapse='\\n')
   f<-sub('which.event + 256L + if (refraction)', 'which.event + (if(body==0) 0L else 256L) + if (refraction)',f,fixed=TRUE)
   stopifnot(grepl('if(body==0)',f,fixed=TRUE));.cc_event<<-eval(parse(text=f))
  }
  if(variant %in% c('geometric-moon','both')){
   f<-paste(deparse(original.observation),collapse='\\n')
   f<-sub('moon <- .cc_position(sunjd, 1, geo, refraction, atm, temp)','moon <- .cc_position(sunjd, 1, geo, FALSE, atm, temp)',f,fixed=TRUE)
   stopifnot(grepl('geo, FALSE',f,fixed=TRUE));.cc_observation<<-eval(parse(text=f))
  }
  z<-CC.window(a$year,geo,season,crescent)
  out[[variant]]<-data.frame(lat=a$lat,series=a$series,year=a$year,variant=variant,original=a$moon_original,baseline=a$moon,moon=z$Moon$declination,date=z$Moon$date)
 }
 do.call(rbind,out)
}
z<-parallel::mclapply(seq_len(nrow(x)),run,mc.cores=4,mc.preschedule=FALSE)
bad<-vapply(z,inherits,logical(1),'try-error');if(any(bad)){print(z[bad]);stop('variant failed')}
write.csv(do.call(rbind,z),'followup-review/variant-results.csv',row.names=FALSE)
'''
Path('followup-review/variants.R').write_text(s)
