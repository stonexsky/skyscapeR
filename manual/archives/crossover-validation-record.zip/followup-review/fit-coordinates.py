import pandas as pd,numpy as np
from scipy.optimize import least_squares
x=pd.read_csv('followup-review/40N-coordinates.csv');x=x[(x.original-x.geodec).abs()<1]
for typ in ['all','sun','moon']:
 g=x if typ=='all' else x[x.body==(typ=='moon')]
 y=g.original-g.topodec
 A=np.array([1/np.cos(np.deg2rad(g.topodec)),g.derivative]).T
 fit=least_squares(lambda b:A@b-y,[.26,0],loss='soft_l1',f_scale=.01)
 e=A@fit.x-y
 print(typ,'topocentric + alt correction and timeoffset',fit.x,'median residual',abs(e).median(),'90%',np.quantile(abs(e),.9))
 # Infer latitude and constant altitude from the actual horizon-event azimuths.
 az=np.deg2rad(g.az);dec=np.deg2rad(g.original)
 def pred(b):
  lat,h=np.deg2rad(b)
  return np.rad2deg(np.arcsin(np.sin(lat)*np.sin(h)+np.cos(lat)*np.cos(h)*np.cos(az)))
 r=least_squares(lambda b:pred(b)-g.original,[40,0],loss='soft_l1',f_scale=.01)
 err=pred(r.x)-g.original
 print('azimuth conversion latitude,altitude',r.x,'median residual',abs(err).median(),'90%',np.quantile(abs(err),.9))
