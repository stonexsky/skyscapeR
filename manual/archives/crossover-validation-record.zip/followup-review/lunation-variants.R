library(swephR)
for(f in c('ephemeris.R','dates.R','misc.R','mechanics.R','horizon-events.R','crescent-crossovers.R','events.R')) source(file.path('skyscapeR/R',f))
skyscapeR.env<-list(calendar='G',timezone='UTC',dec='geo',refraction=TRUE,atm=1013.25,temp=15,cur.year=2026)
.sky_progress<-function(...) FALSE
.file_position<-function(jd,body,flags,...) {r<-swephR::swe_calc_ut(jd,body,bitwOr(as.integer(flags),2L));stopifnot(all(r$return>=0),all(bitwAnd(r$return,7L)==2L));r}
swe_set_ephe_path(normalizePath('efm-review/ephe'))

CC.window<-CC
rewrite<-function(x){if(!is.call(x))return(x);if(identical(x[[1]],as.name("<-"))&&identical(x[[2]],as.name("start")))return(quote(start <- solstice - 2 * 29.53059));as.call(lapply(x,rewrite))}
body(CC.window)<-rewrite(body(CC.window))

original.event<-.cc_event; original.observation<-.cc_observation
x<-read.csv('followup-review/variant-cases.csv')
run<-function(i){
 swe_close();swe_set_ephe_path(normalizePath('efm-review/ephe'))
 a<-x[i,];geo<-c(a$lat,0,400);swe_set_topo(0,a$lat,400)
 season<-if(substr(a$series,1,1)=='S')'summer' else 'winter'
 crescent<-if(substr(a$series,2,2)=='F')'first' else 'last'
 out<-list()
 for(variant in c('next','nearest','next-upper','nearest-upper')){
  CC.window<-CC
  start.expr<-if(grepl('^next',variant))quote(start <- conjunctions[which(conjunctions >= solstice)[1]-2L]) else quote(start <- conjunctions[which.min(abs(conjunctions-solstice))-2L])
  change.start<-function(e){if(!is.call(e))return(e);if(identical(e[[1]],as.name('<-'))&&identical(e[[2]],as.name('start')))return(start.expr);as.call(lapply(e,change.start))}
  body(CC.window)<-change.start(body(CC.window))
  .cc_event <<- original.event
  .upper_event <<- original.event
  f<-paste(deparse(original.event),collapse='\n');f<-sub('256L','0L',f,fixed=TRUE);.upper_event<<-eval(parse(text=f))
  adjust<-function(e){
   if(!is.call(e))return(e)
   if(identical(e[[1]],as.name('.cc_event'))&&identical(e[[2]],as.name('day'))&&identical(e[[3]],0)) e[[1]]<-as.name('.upper_event')
   if(identical(e[[1]],as.name('.cc_position'))&&identical(e[[2]],as.name('sunjd'))&&identical(e[[3]],0)) e[[2]]<-quote(original.event(day,0,direction,loc,geo,refraction,atm,temp))
   if(variant=='upper-visibility-geometric'&&identical(e[[1]],as.name('.cc_position'))&&identical(e[[2]],as.name('sunjd'))&&identical(e[[3]],1))e[[5]]<-FALSE
   if(identical(e[[1]],as.name('list'))&&!is.null(names(e))&&'assessment'%in%names(e))e[[which(names(e)=='sunjd')]]<-quote(original.event(day,0,direction,loc,geo,refraction,atm,temp))
   as.call(lapply(e,adjust))
  }
  f<-original.observation;if(grepl('upper',variant))body(f)<-adjust(body(f));.cc_observation<<-f
  z<-CC.window(a$year,geo,season,crescent)
  out[[variant]]<-data.frame(lat=a$lat,series=a$series,year=a$year,variant=variant,original=a$moon_original,baseline=a$moon,moon=z$Moon$declination,date=z$Moon$date)
 }
 do.call(rbind,out)
}
z<-parallel::mclapply(seq_len(nrow(x)),run,mc.cores=4,mc.preschedule=FALSE)
bad<-vapply(z,inherits,logical(1),'try-error');if(any(bad)){print(z[bad]);stop('variant failed')}
write.csv(do.call(rbind,z),'followup-review/lunation-variants.csv',row.names=FALSE)
