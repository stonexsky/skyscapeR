library(swephR)
for(f in c('ephemeris.R','dates.R','misc.R','mechanics.R','horizon-events.R','crescent-crossovers.R','events.R')) source(file.path('skyscapeR/R',f))
skyscapeR.env<-list(calendar='G',timezone='UTC',dec='geo',refraction=TRUE,atm=1013.25,temp=15,cur.year=2026)
.sky_progress<-function(...) FALSE
.file_position<-function(jd,body,flags,...) {r<-swephR::swe_calc_ut(jd,body,bitwOr(as.integer(flags),2L));stopifnot(all(r$return>=0),all(bitwAnd(r$return,7L)==2L));r}
swe_set_ephe_path(normalizePath('efm-review/ephe'))
old<-paste(deparse(EFM),collapse="\n")
old<-sub("sun <- event(day, 0L)","sun <- event(day - 1, 0L)",old,fixed=TRUE)
old<-sub("sun < day || sun >= end","sun < day - 1 || sun >= end - 1",old,fixed=TRUE)
EFM<-eval(parse(text=old))
jobs<-expand.grid(lat=c(40,-60),series=c('SFMSet','AFMSet'),stringsAsFactors=FALSE)
run<-function(i){
 swe_close();swe_set_ephe_path(normalizePath("efm-review/ephe"))
 a<-jobs[i,]; dest<-paste0('followup-review/paired-',a$lat,'-',a$series,'.csv'); if(file.exists(dest))return(TRUE)
 isefm<-grepl('FM',a$series); out<-list()
 for(y in 1620:2047){
  sims<-if(isefm)'EFM' else c('SIM1','SIM2')
  for(sim in sims){
   z<-tryCatch(if(isefm) EFM(y,c(a$lat,0,400),season=if(substr(a$series,1,1)=='S')'spring' else 'autumn',rise=!grepl('Set',a$series)) else CC(y,c(a$lat,0,400),season=if(substr(a$series,1,1)=='S')'summer' else 'winter',crescent=if(substr(a$series,2,2)=='F')'first' else 'last',simulation=sim),error=function(e)e)
   if(inherits(z,'error')){out[[length(out)+1]]<-data.frame(lat=a$lat,series=a$series,simulation=sim,year=y,moon=NA,sun=NA,date=NA,time=NA,error=conditionMessage(z))}else out[[length(out)+1]]<-data.frame(lat=a$lat,series=a$series,simulation=sim,year=y,moon=z$Moon$declination,sun=z$Sun$declination,date=z$Moon$date,time=z$Moon$time,error='')
  }
 }
 write.csv(do.call(rbind,out),dest,row.names=FALSE);cat('DONE',a$lat,a$series,'\n');TRUE
}
z<-parallel::mclapply(seq_len(nrow(jobs)),run,mc.cores=4,mc.preschedule=FALSE)
