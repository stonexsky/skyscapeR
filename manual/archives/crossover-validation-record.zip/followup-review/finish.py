from pathlib import Path
import subprocess,zipfile,pandas as pd
p=Path('skyscapeR/NEWS.md');s=p.read_text();key='## Vignette and help\n\n';s=s.replace(key,key+'* Single circular star-phase plots now reserve side space only where event\n  labels need it, with smaller outer margins and a closer legend.\n');p.write_text(s)
audit=Path('phase-fix/REVIEW.txt');s=audit.read_text();a=s.index('6. VALIDATION ADVANCED');b=s.index('7. ACCEPTED',a)
s=s[:a]+'''6. VALIDATION ADVANCED; FIXES PENDING: original workbooks support broad curve
   agreement with matched smoothing (their saved sigma=1.7 degrees, versus the
   paper's stated 1 degree). Previous-evening sunset pairing improves EFM
   moonset agreement within 0.02 degrees from 2,484/2,568 to 2,562/2,568 at
   0, 60 N and 60 S. Five residuals are at illumination 0.990001–0.990075;
   one is only 0.002 degrees beyond the azimuth crossover boundary. The source
   chooses the following morning in each case. Recommend correcting pairing,
   retaining the physical thresholds rather than tuning them to the spreadsheet.
   The 40 N solar and moonset values closely resemble conversion of event
   azimuths at latitude 40 and altitude -0.15 degrees, rather than the current
   geocentric output. Its moonrise values have an additional systematic offset.
   This is diagnostic evidence, not proof of the original coordinate convention.
   CC: unique matching dates were inferred for all 112 non-40N SIM1 outliers
   using both rounded declinations. A shorter window resolves 42 but changes
   a previously matching control. Solar upper-limb visibility assessment
   improves many borderline cases; tested alternatives still change controls.
   The original scripts/settings are needed to choose among these conventions
   confidently. No EFM or CC numerical changes were applied to the package.
'''+s[b:]
s+='''
COMPACT SINGLE-PHASE PLOT FOLLOW-UP
Circular single-result plots reserve only the side space needed by actual event
labels. Outer margins and leader lengths are reduced and the legend is closer
to the cycle. Multiple-result layouts and astronomical calculations are unchanged.
Real Aldebaran and synthetic long-name/constant-season/linear/multiple cases
were rendered and checked. Full package check and HTML vignette rebuild remain
local release checks. The consolidated source archive includes this adjustment.
'''
audit.write_text(s);Path('final-review/AUDIT.txt').write_text(s)
report='''Further EFM/CC investigation — 6 November 2026

No EFM or CC algorithm changes have been applied to the package. All alternatives
below are isolated experiments; agreement with historical simulations is not
independent observational validation.

EFM
Previous-evening sunset pairing has now been tested for all 428 years at 0,
40N, 60N and 60S, both spring and autumn. Excluding the separately discrepant
40N coordinate series, 2,562/2,568 lunar declinations agree within 0.02 degrees,
compared with 2,484/2,568 before the pairing experiment. Five residual cases
have illumination between 0.9900015 and 0.990075; one has a signed azimuth
margin of only 0.002042 degrees. In all six cases the source declination matches
the following morning. This supports fixing the event pairing while preserving
the physical 0.99 illumination threshold and strict bearing comparison.

40N coordinate diagnosis
For all four EFM solar series and both moonset series, converting the computed
horizon-event azimuth with latitude 40 degrees and altitude -0.15 degrees gives
median errors of approximately 0.0024–0.0045 degrees relative to the source.
This improves substantially on the direct geocentric comparison. Moonrise has
an additional offset: after that conversion, residuals are almost perfectly
anticorrelated with lunar declination rate (r approximately -0.9995). Dividing
by that rate corresponds to approximately 31 minutes of motion. This is an
inference about possible conversion/timing conventions, not evidence that the
original scripts used those exact settings. Do not modify the ephemeris to
fit this series. The other latitudes strongly support the current ephemeris.

CC
For each of the 112 SIM1 discrepancies outside 40N, a search within 100 days
before to 150 days after the relevant solstice found exactly one candidate
matching BOTH source solar and lunar declinations within 0.025 degrees. These
are inferred dates consistent with rounded source coordinates, not dates
present in the supplied workbooks. Seven inferred events fail the current
visibility threshold by only 0.013–0.116 degrees. For 57 cases, the inferred
source observing date differs from the current model's first/last visible
crescent date within the same lunation.

The fixed solstice-minus-two-mean-synodic-month window resolves 42/112 outliers
but changes one of 60 randomly selected matching controls (five per latitude/
event combination, fixed random seed 42). The control is summer first crescent
1963 at the equator: a conjunction sits near the starting-window boundary.
Using the first conjunction after the solstice minus two lunations behaves
similarly. Using the nearest conjunction minus two preserves all 60 controls
but resolves only 31/112 outliers.

Assessing visibility at upper-limb sunset/sunrise, while retaining centre-disc
azimuths for crossover comparison, resolves 100/112 outliers with the shorter
window, but changes 2/60 matching controls (one due to the window). Using
upper-limb solar events for both visibility and bearing comparison resolves
103/112 but changes 5/60 controls. Geometric lunar altitude at assessment and
combined variants also failed to preserve all controls. These are exploratory
results on selected problem cases and a small control sample, not full-series
validation of a replacement algorithm. There is no justified universal CC fix
yet. The original scripts, visibility timing and coordinate-output conventions
would be the most useful further evidence.

Numerical checks
Ephemeris checksums are unchanged. An initial parallel diagnostic run produced
file-state errors and was discarded. The recovery and variant runs close and
reopen Swiss Ephemeris in each worker; the final recovery contains all 112 cases
without errors. Source snapshots for the existing astronomical implementation
remain in the preceding validation archive. R sources/CSV files here document
all experimental changes. The single-phase plotting change is separate and
does not alter astronomical calculations.
'''
Path('followup-review/FINDINGS.txt').write_text(report)
# Refresh the cumulative source delivery without rerunning the old audit builder.
archive=Path('final-review/skyscapeR-2.0-consolidated-2026-11-06.zip')
with zipfile.ZipFile(archive) as z:items={n:z.read(n) for n in z.namelist()}
for name in ['R/plotting.R','NEWS.md']:
 p=Path('skyscapeR')/name;items[str(p)]=p.read_bytes()
patch=subprocess.check_output(['git','-C','skyscapeR','diff','--binary','HEAD'])
Path('final-review/skyscapeR-today.patch').write_bytes(patch)
items['skyscapeR-today.patch']=patch;items['AUDIT.txt']=audit.read_bytes()
items['validation/compact-star-phases.png']=Path('followup-review/phase-after.png').read_bytes()
items['validation/phase-plot-check.log']=Path('followup-review/plot-check.log').read_bytes()
items['validation/EFM-CC-follow-up.txt']=report.encode()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for n,b in items.items():z.writestr(n,b)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
analysis=Path('crossover-validation/Crossover-validation.zip')
with zipfile.ZipFile(analysis) as z:items={n:z.read(n) for n in z.namelist()}
for p in Path('followup-review').iterdir():
 if p.suffix in ['.R','.py','.csv','.txt'] and p.name not in ['plotting-before.R']:
  items[str(p)]=p.read_bytes()
items['followup-review/compact-star-phases.png']=Path('followup-review/phase-after.png').read_bytes()
with zipfile.ZipFile(analysis,'w',zipfile.ZIP_DEFLATED) as z:
 for n,b in items.items():z.writestr(n,b)
print('Updated consolidated source and validation archives.')
