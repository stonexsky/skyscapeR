from pathlib import Path
import pandas as pd
x=pd.read_csv('crossover-validation/comparisons.csv');x=x[(x.simulation=='SIM1')&(x.lat!=40)&(abs(x.moon_error)>.02)]
x.to_csv('followup-review/cc-outliers.csv',index=False)
s=Path('crossover-validation/run.R').read_text().split('jobs<-')[0]
s+='''
CC.window<-CC
rewrite<-function(x){if(!is.call(x))return(x);if(identical(x[[1]],as.name("<-"))&&identical(x[[2]],as.name("start")))return(quote(start <- solstice - 2 * 29.53059));as.call(lapply(x,rewrite))}
body(CC.window)<-rewrite(body(CC.window))
x<-read.csv('followup-review/cc-outliers.csv')
run<-function(i){
 a<-x[i,];geo<-c(a$lat,0,400);swe_set_topo(0,a$lat,400)
 season<-if(substr(a$series,1,1)=='S')'summer' else 'winter'
 crescent<-if(substr(a$series,2,2)=='F')'first' else 'last'
 direction<-if(crescent=='first')1 else -1
 z<-CC.window(a$year,geo,season,crescent)
 a$window.moon<-z$Moon$declination;a$window.date<-z$Moon$date
 mid<-swe_julday(a$year,if(season=='summer')6L else 12L,21L,0,1L)
 candidates<-list()
 for(day in mid+(-100:150)){
  sjd<-.cc_event(day,0,direction,geo,geo,TRUE,1013.25,15)
  if(!is.finite(sjd))next
  sd<-.cc_calc(sjd,0,2050L)[2]
  if(abs(sd-a$sun_original)>.025)next
  mjd<-.cc_event(if(direction==1)sjd+1e-7 else sjd-.5,1,direction,geo,geo,TRUE,1013.25,15)
  if(!is.finite(mjd)||direction*(mjd-sjd)<=0||abs(mjd-sjd)>.5)next
  md<-.cc_calc(mjd,1,2050L)[2]
  if(abs(md-a$moon_original)>.025)next
  newmoons<-.cc_newmoons(sjd-10,sjd+10)
  nm<-if(direction==1)tail(newmoons[newmoons<sjd],1) else head(newmoons[newmoons>sjd],1)
  if(!length(nm))next
  # Evaluate the original visibility formula directly even when it fails.
  moon<-.cc_position(sjd,1,geo,TRUE,1013.25,15)
  sun<-.cc_position(sjd,0,geo,TRUE,1013.25,15)
  sg<-.cc_calc(sjd,0,2050L);mg<-.cc_calc(sjd,1,2050L);rad<-pi/180
  sep<-acos(max(-1,min(1,sin(sg[2]*rad)*sin(mg[2]*rad)+cos(sg[2]*rad)*cos(mg[2]*rad)*cos((sg[1]-mg[1])*rad))))/rad
  radius<-asin(1737.4/(moon$eq[3]*149597870.7))/rad
  lower<-moon$alt-radius
  pos<-.cc_position(mjd,1,geo,TRUE,1013.25,15)
  base<-.cc_crescent(nm,direction,geo,geo,TRUE,1013.25,15,'UTC','G')
  candidates[[length(candidates)+1]]<-data.frame(date=jd2time(mjd,'UTC','G'),moon=md,sun=sd,margin=lower+sep/3-11.3,diff=.cc_wrap(pos$az-sun$az),lower=lower,sep=sep,base.date=if(is.null(base))NA_character_ else jd2time(base$moonjd,'UTC','G'),base.margin=if(is.null(base))NA_real_ else base$margin,conjunction=jd2time(nm,'UTC','G'))
 }
 a$matches<-length(candidates)
 if(length(candidates)){
  cs<-do.call(rbind,candidates);j<-which.min(abs(cs$moon-a$moon_original)+abs(cs$sun-a$sun_original));b<-cs[j,];names(b)<-paste0('original.',names(b));a<-cbind(a,b)
 }else{
  for(name in c('date','moon','sun','margin','diff','lower','sep','base.date','base.margin','conjunction'))a[[paste0('original.',name)]]<-NA
 }
 if(i%%20==0)cat(i,'/',nrow(x),'\\n')
 a
}
rows<-parallel::mclapply(seq_len(nrow(x)),run,mc.cores=4)
stopifnot(!any(vapply(rows,inherits,logical(1),'try-error')))
write.csv(do.call(rbind,rows),'followup-review/cc-recovered.csv',row.names=FALSE)
'''
Path('followup-review/recover.R').write_text(s)
