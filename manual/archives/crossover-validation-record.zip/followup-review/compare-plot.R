source('skyscapeR/R/dates.R');source('skyscapeR/R/stars.R')
x<-readRDS('followup-review/ald.rds')
for(mode in c('before','after')){
 source(if(mode=='before')'followup-review/plotting-before.R' else 'skyscapeR/R/plotting.R')
 png(paste0('followup-review/phase-',mode,'.png'),width=1050,height=1050,res=150,type='cairo');plot(x);dev.off()
}
