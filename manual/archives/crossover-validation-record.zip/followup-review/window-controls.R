library(swephR)
for(f in c('ephemeris.R','dates.R','misc.R','mechanics.R','horizon-events.R','crescent-crossovers.R','events.R')) source(file.path('skyscapeR/R',f))
skyscapeR.env<-list(calendar='G',timezone='UTC',dec='geo',refraction=TRUE,atm=1013.25,temp=15,cur.year=2026)
.sky_progress<-function(...) FALSE
.file_position<-function(jd,body,flags,...) {r<-swephR::swe_calc_ut(jd,body,bitwOr(as.integer(flags),2L));stopifnot(all(r$return>=0),all(bitwAnd(r$return,7L)==2L));r}
swe_set_ephe_path(normalizePath('efm-review/ephe'))

CC.window<-CC
rewrite<-function(x){if(!is.call(x))return(x);if(identical(x[[1]],as.name("<-"))&&identical(x[[2]],as.name("start")))return(quote(start <- solstice - 2 * 29.53059));as.call(lapply(x,rewrite))}
body(CC.window)<-rewrite(body(CC.window))
x<-read.csv('followup-review/variant-cases.csv');x<-x[abs(x$moon_error)<=.02,]
rows<-lapply(seq_len(nrow(x)),function(i){a<-x[i,];z<-CC.window(a$year,c(a$lat,0,400),if(substr(a$series,1,1)=='S')'summer' else 'winter',if(substr(a$series,2,2)=='F')'first' else 'last');a$new.moon<-z$Moon$declination;a$new.date<-z$Moon$date;a})
write.csv(do.call(rbind,rows),'followup-review/window-controls.csv',row.names=FALSE)
