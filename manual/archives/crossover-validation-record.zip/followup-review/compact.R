source('skyscapeR/R/ephemeris.R')
s <- readLines('phase-fix/check.R'); eval(parse(text=s[seq_len(which(grepl('results<-data.frame',s))[1]-1)]))
source('skyscapeR/R/plotting.R')
load('skyscapeR/data/malta_horizons.rda')
r<-swe_fixstar2_ut(',alf Tau',swe_julday(-3249,1,1,12,1L),2048L+16384L+16L+2L)
st<-synthetic(r$xx[2]);st$coord$RA<-r$xx[1];st$app.mag<-swe_fixstar2_mag(',alf Tau')$mag
st$name<-'Aldebaran';st$Bayer<-'alf Tau'
x<-star.phases(st,-3249,malta_horizons[[1]],k=.2)
saveRDS(x,'followup-review/ald.rds')
for(w in c(5,7)) {
 png(paste0('followup-review/compact-',w,'.png'),width=w*150,height=w*150,res=150,type='cairo')
 plot(x)
 dev.off()
}
