from pathlib import Path
import urllib.request, hashlib, json
root=Path('efm-review'); dest=root/'ephe';dest.mkdir(exist_ok=True)
for name, expected in json.loads((root/'ephemeris-sha256.json').read_text()).items():
    path=dest/name
    urllib.request.urlretrieve('https://raw.githubusercontent.com/aloistr/swisseph/master/ephe/'+name,path)
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected, name+' changed upstream'
