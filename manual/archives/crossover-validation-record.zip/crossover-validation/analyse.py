from pathlib import Path
import pandas as pd,numpy as np,json
root=Path('crossover-validation')
o=pd.read_csv(root/'original-modern.csv');files=list(root.glob('results-*.csv'))
x=pd.concat([pd.read_csv(p) for p in files],ignore_index=True)
m=x.merge(o,on=['lat','series','year'],validate='many_to_one')
for b in ['moon','sun']:m[b+'_error']=m[b]-m[b+'_original']
m.to_csv(root/'comparisons.csv',index=False)
rows=[]
for key,g in m.groupby(['lat','series','simulation']):
 e=g.moon_error.abs();s=g.sun_error.abs()
 rows.append(dict(zip(['latitude','series','simulation'],key),n=len(g),valid=int(e.notna().sum()),median_abs_moon=e.median(),median_abs_sun=s.median(),within_002=int((e<=.02).sum()),within_1=int((e<=1).sum()),max_abs_moon=e.max(),mean_moon_error=g.moon_error.mean()))
stats=pd.DataFrame(rows);stats.to_csv(root/'summary.csv',index=False)
print(stats.round(4).to_string(index=False))
