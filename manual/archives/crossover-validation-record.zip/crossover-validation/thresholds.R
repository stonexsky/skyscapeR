library(swephR)
for(f in c('ephemeris.R','dates.R','misc.R','mechanics.R','horizon-events.R','crescent-crossovers.R','events.R')) source(file.path('skyscapeR/R',f))
skyscapeR.env<-list(calendar='G',timezone='UTC',dec='geo',refraction=TRUE,atm=1013.25,temp=15,cur.year=2026)
.sky_progress<-function(...) FALSE
.file_position<-function(jd,body,flags,...) {r<-swephR::swe_calc_ut(jd,body,bitwOr(as.integer(flags),2L));stopifnot(all(r$return>=0),all(bitwAnd(r$return,7L)==2L));r}
swe_set_ephe_path(normalizePath('efm-review/ephe'))
x<-read.csv('crossover-validation/pairing-residuals.csv')
for(i in 1:nrow(x)){
 loc<-c(x$lat[i],0,400);swe_set_topo(0,x$lat[i],400);day<-time2jd(x$date[i])
 for(delta in 0:1){t<-.cc_event(day+delta,1,1,loc,loc,TRUE,1013.25,15);print(c(year=x$year[i],offset=delta,moon=.cc_calc(t,1,2050L)[2],phase=moonphase(t)))}
}
