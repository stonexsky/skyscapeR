import openpyxl,csv,json,warnings
warnings.filterwarnings('ignore',category=UserWarning)
rows=[];configs={}
for lat,name in [(40,'40N'),(0,'0'),(60,'60N'),(-60,'60S')]:
 w=openpyxl.load_workbook(f'upload/Dist{name}-revJHA.xlsx',data_only=True,read_only=True)
 vals=list(w['Simul'].values)
 for c in range(1,33,4):
  series=vals[0][c].split()[0]
  for i in range(428):rows.append([lat,series,1620+i,vals[8+i][c],vals[8+i][c+1]])
 configs[name]={}
 for s in w:
  if s.title in ('Simul','Decl','Graf_Dec'):continue
  v=list(s.values)
  configs[name][s.title]={'source_column':v[0][0],'sigma':v[1][1],'scale':v[2][1],'shift':v[3][1]}
 print(name,configs[name])
with open('crossover-validation/original-modern.csv','w') as f:
 o=csv.writer(f);o.writerow(['lat','series','year','sun_original','moon_original']);o.writerows(rows)
json.dump(configs,open('crossover-validation/graph-settings.json','w'),indent=2)
