library(swephR)
for(f in c('ephemeris.R','dates.R','misc.R','mechanics.R','horizon-events.R','crescent-crossovers.R','events.R')) source(file.path('skyscapeR/R',f))
skyscapeR.env<-list(calendar='G',timezone='UTC',dec='geo',refraction=TRUE,atm=1013.25,temp=15,cur.year=2026)
.sky_progress<-function(...) FALSE
.file_position<-function(jd,body,flags,...) {r<-swephR::swe_calc_ut(jd,body,bitwOr(as.integer(flags),2L));stopifnot(all(r$return>=0),all(bitwAnd(r$return,7L)==2L));r}
swe_set_ephe_path(normalizePath('efm-review/ephe'))
CC0<-CC
rewrite<-function(x){if(!is.call(x))return(x);if(identical(x[[1]],as.name("<-"))&&identical(x[[2]],as.name("start")))return(quote(start <- solstice - 2 * 29.53059));as.call(lapply(x,rewrite))}
body(CC)<-rewrite(body(CC))
orig<-read.csv('crossover-validation/original-modern.csv')
rows<-list()
for(lat in c(0,60,-60)){
 path<-paste0('crossover-validation/results-',lat,'-SFC.csv');if(!file.exists(path))next
 a<-read.csv(path);a<-merge(a[a$simulation=='SIM1',],orig,by=c('lat','series','year'))
 a<-a[abs(a$moon-a$moon_original)>.02,]
 for(i in seq_len(nrow(a))){z<-CC(a$year[i],c(lat,0,400),season='summer',crescent='first');a$new_moon[i]<-z$Moon$declination;a$new_date[i]<-z$Moon$date}
 rows[[length(rows)+1]]<-a
}
write.csv(do.call(rbind,rows),'crossover-validation/start-window-outliers.csv',row.names=FALSE)
