library(swephR)
for(f in c('ephemeris.R','dates.R','misc.R','mechanics.R','horizon-events.R','crescent-crossovers.R','events.R')) source(file.path('skyscapeR/R',f))
skyscapeR.env<-list(calendar='G',timezone='UTC',dec='geo',refraction=TRUE,atm=1013.25,temp=15,cur.year=2026)
.sky_progress<-function(...) FALSE
.file_position<-function(jd,body,flags,...) {r<-swephR::swe_calc_ut(jd,body,bitwOr(as.integer(flags),2L));stopifnot(all(r$return>=0),all(bitwAnd(r$return,7L)==2L));r}
swe_set_ephe_path(normalizePath('efm-review/ephe'))
CC0<-CC
rewrite<-function(x){if(!is.call(x))return(x);if(identical(x[[1]],as.name("<-"))&&identical(x[[2]],as.name("start")))return(quote(start <- solstice - 2 * 29.53059));as.call(lapply(x,rewrite))}
body(CC)<-rewrite(body(CC))
print(system.time({for(sim in c("SIM1","SIM2")){for(season in c("summer","winter")){for(crescent in c("first","last")){z<-CC(1620,c(40,0,400),season,crescent,sim);print(c(sim,season,crescent,z$Moon$declination,z$Sun$declination,z$Moon$date))}}}}))
