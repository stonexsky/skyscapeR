from pathlib import Path
import pandas as pd,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path('crossover-validation');m=pd.read_csv(p/'comparisons.csv');o=pd.read_csv(p/'original-modern.csv')
series=['SFM','AFM','SFMSet','AFMSet','SFC','WFC','SLC','WLC']
titles=['Spring full Moon rise','Autumn full Moon rise','Spring full Moon set','Autumn full Moon set','Summer first crescent','Winter first crescent','Summer last crescent','Winter last crescent']
xx=np.arange(-33,33.001,.1)
def density(values):
 values=np.asarray(values);values=values[np.isfinite(values)]
 return np.mean(np.exp(-.5*((xx[:,None]-values[None,:])/1.7)**2)/(1.7*np.sqrt(2*np.pi)),axis=1)
fig,axes=plt.subplots(2,4,figsize=(16,8),layout='constrained')
for ax,k,title in zip(axes.flat,series,titles):
 g=o[(o.lat==40)&(o.series==k)]
 ax.plot(xx,density(g.moon_original),color='#202a35',lw=2,label='Original spreadsheet')
 for sim,h in m[(m.lat==40)&(m.series==k)].groupby('simulation'):
  ax.plot(xx,density(h.moon),color='#b74232' if sim!='SIM2' else '#217d86',ls='--' if sim!='SIM2' else ':',lw=2,label='Current '+sim)
 ax.set_title(title,fontsize=12);ax.set_xlabel('Lunar declination (°)');ax.grid(alpha=.15);ax.set_xlim((-17,17) if 'FM' in k else (-33,33));ax.set_ylim(bottom=0);ax.legend(fontsize=8)
fig.suptitle('Original simulations versus skyscapeR at 40°N\n428 years (1620–2047); all curves use the workbook’s σ = 1.7°',fontsize=17)
fig.savefig(p/'crossover-comparison.png',dpi=170)
