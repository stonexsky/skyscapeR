library(swephR)
for(f in c('ephemeris.R','dates.R','misc.R','mechanics.R','horizon-events.R','crescent-crossovers.R','events.R')) source(file.path('skyscapeR/R',f))
skyscapeR.env<-list(calendar='G',timezone='UTC',dec='geo',refraction=TRUE,atm=1013.25,temp=15,cur.year=2026)
.sky_progress<-function(...) FALSE
.file_position<-function(jd,body,flags,...) {r<-swephR::swe_calc_ut(jd,body,bitwOr(as.integer(flags),2L));stopifnot(all(r$return>=0),all(bitwAnd(r$return,7L)==2L));r}
swe_set_ephe_path(normalizePath('efm-review/ephe'))
x<-read.csv('efm-review/EFM-1620-2047.csv')
swe_set_topo(0,40,400)
x$topo<-vapply(x$jd,function(t)swe_calc_ut(t,1L,2L+2048L+32768L)$xx[2],numeric(1))
write.csv(x,'crossover-validation/efm-topocentric.csv',row.names=FALSE)
