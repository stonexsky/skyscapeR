from pathlib import Path
import pandas as pd,zipfile
root=Path('crossover-validation')
files=list(root.glob('results-*.csv'));assert len(files)==32
m=pd.read_csv(root/'comparisons.csv');assert len(m)==20544
assert m.moon.notna().all();assert not m.duplicated(['lat','series','simulation','year']).any()
s=pd.read_csv(root/'summary.csv')
cc=s[(s.simulation=='SIM1')&(s.latitude!=40)]
efm=s[(s.simulation=='EFM')&s.series.isin(['SFM','AFM'])&(s.latitude!=40)]
with open(root/'README.txt','a') as f:
 f.write('\nCompleted modern comparison totals\n')
 f.write(f'All {len(m):,} current calculations returned results.\n')
 f.write(f'Rising EFM outside 40N: {efm.within_002.sum()}/{efm.n.sum()} within 0.02 degrees.\n')
 f.write(f'CC SIM1 outside 40N: {cc.within_002.sum()}/{cc.n.sum()} within 0.02 degrees.\n')
 f.write('\nFull per-series summary:\n'+s.round(5).to_string(index=False)+'\n')
archive=root/'Crossover-validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in root.iterdir():
  if p.suffix in ('.csv','.json','.png','.R','.py','.txt') and p.name!='current-summary.txt':z.write(p,p)
 for name in ['ephemeris.R','dates.R','misc.R','mechanics.R','horizon-events.R','crescent-crossovers.R','events.R']:
  p=Path('skyscapeR/R')/name;z.write(p,p)
 for name in ['ephemeris-sha256.json','download-ephemeris.py']:
  p=Path('efm-review')/name;z.write(p,p)
print('EFM rise',efm.within_002.sum(),efm.n.sum(),'CC',cc.within_002.sum(),cc.n.sum(),'archive',archive.stat().st_size)
