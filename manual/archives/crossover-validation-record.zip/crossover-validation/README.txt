Validation against Silva & Pimenta simulation workbooks — 6 November 2026

This is an analysis archive, NOT an installable package update. The astronomical
package source has not been changed by this investigation. Experimental variants
are confined to separate analysis scripts and R processes.

Inputs
CrossoverMoonDecs_JHA.xlsx and Dist0/40N/60N/60S-revJHA.xlsx, supplied by Fabio
Silva. Original files remain unchanged. SHA256 hashes identify the inputs.
The files provide annual paired Sun/Moon declinations, not calendar event dates
or times. Row 9 is the first year; 428 consecutive years follow. Modern series
start in 1620. Ancient series in the first workbook are headed -2998/428.
The modern 40N values in both workbooks are identical for all eight tested series.

Scope
All 428 modern years (1620–2047), at latitudes 0, 40N, 60N and 60S, longitude 0,
elevation 400 m. Four EFM rise/set/season combinations and four CC season/crescent
combinations; both CC SIM1 and SIM2 evaluated. Annual pairing uses the source
series' year, with no adjustment to improve agreement. Ancient series and the
SSFM/WSFM columns have not been validated in this pass. The ancient year-number
convention should be confirmed before treating that series as an exact benchmark.

Settings
Current working skyscapeR 2.0 sources, swephR 0.3.2, R 4.3.3. Gregorian calendar,
UTC, refraction enabled, pressure 1013.25 hPa, temperature 15 C, EFM minimum
illumination 0.99, geocentric declinations. Atmospheric values are package defaults,
not recovered settings from the original simulations. Swiss Ephemeris files
sepl_12/semo_12/sepl_18/semo_18 used; checksums supplied. Position calls verify
that Swiss file ephemerides were used. The package namespace is not installed
in this analysis process, so provenance correctly reports skyscapeR version NA.
Source snapshots and hashes identify the code used instead.

Graph construction
The saved graph workbooks use NORMDIST(...,sigma,FALSE), average 428 densities,
and apply display multipliers of +1 or -1. Their active sigma is 1.7 degrees;
all eight main series have zero declination shift. Cached densities reproduce
numerically using these settings. This differs from the paper's stated sigma
of 1 degree. These saved workbook settings do not prove which exact settings
were used for the final published artwork. The comparison PNG uses 1.7 degrees
for both original and current curves; each panel is a positive unit-area density.

Findings
1. Rising EFMs at 0 and +/-60 degrees reproduce the original rounded lunar
   declinations very closely in most years (median absolute errors about
   0.002–0.005 degrees). There are occasional event-selection differences.
2. Setting EFMs currently pair a morning moonset with the same civil day's
   evening sunset. Source solar declinations instead support the previous
   evening's sunset. An isolated variant using that pairing was run for all
   428 years, spring and autumn, at 0 and 60N: agreement within 0.02 degrees
   rises from 1,659/1,712 to 1,710/1,712 lunar events. Solar agreement improves
   from a roughly 0.38-degree offset to median errors about 0.002–0.003 degrees.
   This is strong evidence for correcting the setting-event pairing. It is
   not a complete validation for terrain, high latitudes or all epochs.
   The two residual cases are 1913 autumn set at 0 degrees and 2023 spring set
   at 60N. Their selected events have illuminated fractions 0.990003 and
   0.9900015; the source declinations match the following morning instead.
   These sit exceptionally close to the 0.99 threshold and are consistent with
   a numerical/ephemeris threshold difference, not evidence to tune the cutoff.
3. The 40N source series has systematic sub-degree offsets not present in the
   other three latitude series. Its rising EFM median lunar errors are about
   0.23–0.46 degrees. No cause is established; do not attribute them to pressure,
   temperature, coordinates or Alcyone without further evidence.
4. CC reproduces broad distributions, but event-level discrepancies remain.
   SIM1/SIM2 is not explicitly identified in the source sheets. Summer 40N
   curves agree better with SIM2, whereas several other source series agree
   better with SIM1. It is not justified to assume one common mode for all files.
5. CC's current starting conjunction can be nearly three lunations before the
   solstice: it takes the last conjunction before the solstice, then steps back
   two conjunctions. This is not equivalent to taking the first conjunction
   after solstice minus two synodic months. A limited alternative-window test
   fixes 14 of 22 summer-first-crescent outliers at the equator; it does not fix
   all discrepancies or establish the correct complete CC implementation.
   In the 40N 1620 winter-last case, the current result is 25 September with
   lunar declination -0.622 degrees, versus -23.19 in the source. Moving the
   start window changes selection to 21 January 1621, -19.920 degrees, still
   not a match. This requires further investigation, not a cosmetic curve fit.

Files
summary.csv: per-series absolute lunar and solar errors, counts within 0.02 and
1 degree. These tolerances describe agreement, not physical visibility accuracy.
comparisons.csv: every annual result and original value, signed errors, and the
current calculated event date/time (not an original date recovered from Excel).
paired-*.csv: isolated previous-sunset experiment results.
start-window-outliers.csv: limited CC window experiment on baseline outliers.
original*.csv / graph-settings.json: extracted inputs and active graph settings.
run.R: complete baseline calculation; pairing-experiment.R: EFM candidate fix.
Other scripts document extraction, analysis, plots and diagnostic cases.

Reproduction
Use the bundled R source snapshot as skyscapeR/R, put the four graph workbooks
in upload/, and provide the four Swiss Ephemeris files in efm-review/ephe/.
Install swephR; run run.R with Rscript from the archive root. Python extraction
uses openpyxl in read-only mode; analysis uses pandas/numpy and plots matplotlib.
The source input CSVs are included, so extraction is unnecessary unless checking
the spreadsheets themselves. No spreadsheet was edited. Large ephemeris and
workbook binaries are omitted from this archive; hashes identify them.

Next steps
Implement and verify the EFM previous-sunset pairing across the supported
workflow; investigate remaining threshold cases and the 40N offsets. Clarify
original CC modes and event selection, then test the starting-window correction
without treating it as a complete fix. If available, original scripts or full
dated rise/set records would distinguish coordinate and visibility conventions.

Completed modern comparison totals
All 20,544 current calculations returned results.
Rising EFM outside 40N: 2561/2568 within 0.02 degrees.
CC SIM1 outside 40N: 5024/5136 within 0.02 degrees.

Full per-series summary:
 latitude series simulation   n  valid  median_abs_moon  median_abs_sun  within_002  within_1  max_abs_moon  mean_moon_error
      -60    AFM        EFM 428    428          0.00423         0.00260         428       428       0.01134         -0.00442
      -60 AFMSet        EFM 428    428          0.00495         0.38634         415       415       9.35304         -0.18586
      -60    SFC       SIM1 428    428          0.00376         0.00266         420       424       5.40226          0.00009
      -60    SFC       SIM2 428    428          0.00593         0.00402         263       272      12.42340          1.07520
      -60    SFM        EFM 428    428          0.00398         0.00243         427       427       4.53773          0.01488
      -60 SFMSet        EFM 428    428          0.00473         0.38240         410       410      10.28836          0.25051
      -60    SLC       SIM1 428    428          0.00297         0.00266         425       425       3.59006          0.00548
      -60    SLC       SIM2 428    428          0.00302         0.00267         416       416       7.04846          0.11854
      -60    WFC       SIM1 428    428          0.00335         0.00253         423       423       7.95640          0.00634
      -60    WFC       SIM2 428    428          0.00370         0.00316         337       337      15.78560         -1.56593
      -60    WLC       SIM1 428    428          0.00293         0.00242         419       421       4.23522         -0.01111
      -60    WLC       SIM2 428    428          0.00311         0.00260         384       386      17.78363         -0.78260
        0    AFM        EFM 428    428          0.00259         0.00234         426       426       5.08078         -0.01970
        0 AFMSet        EFM 428    428          0.00265         0.38462         408       408       9.81620         -0.29535
        0    SFC       SIM1 428    428          0.00262         0.00290         406       407      18.40479         -0.46435
        0    SFC       SIM2 428    428          0.00431         0.00428         263       267      28.29007          2.30159
        0    SFM        EFM 428    428          0.00249         0.00258         427       427       4.63671          0.01299
        0 SFMSet        EFM 428    428          0.00264         0.38434         422       422       9.64289          0.08628
        0    SLC       SIM1 428    428          0.00257         0.00277         411       416      21.31065         -0.33230
        0    SLC       SIM2 428    428          0.00285         0.00314         362       367      21.31487          0.91696
        0    WFC       SIM1 428    428          0.00279         0.00243         407       409      18.21081          0.45860
        0    WFC       SIM2 428    428          0.00438         0.00402         267       270      19.90544         -2.40718
        0    WLC       SIM1 428    428          0.00275         0.00258         410       413      21.02805          0.35006
        0    WLC       SIM2 428    428          0.00328         0.00288         357       360      29.73256         -1.09223
       40    AFM        EFM 428    428          0.23096         0.26051           0       416      10.16393          0.28359
       40 AFMSet        EFM 428    428          0.35397         0.64791           0       419       8.97096          0.22579
       40    SFC       SIM1 428    428          0.39720         0.28668           0       290      21.12733         -2.00504
       40    SFC       SIM2 428    428          0.37260         0.28531           0       400      21.12733          0.02838
       40    SFM        EFM 428    428          0.46467         0.26533           0       415       9.91690          0.34554
       40 SFMSet        EFM 428    428          0.34946         0.12231           0       415       9.89436          0.56063
       40    SLC       SIM1 428    428          0.38693         0.28510           0       361      21.13736         -0.86165
       40    SLC       SIM2 428    428          0.37517         0.28301           0       408       9.85558          0.40075
       40    WFC       SIM1 428    428          0.48674         0.34843           1       304      16.74743          1.17695
       40    WFC       SIM2 428    428          0.50382         0.35129           1       269      19.73969         -1.19978
       40    WLC       SIM1 428    428          0.69731         0.35146           1       245      22.56795          1.68677
       40    WLC       SIM2 428    428          0.68141         0.35150           1       252      22.56795          1.10849
       60    AFM        EFM 428    428          0.00436         0.00260         425       425       4.96054         -0.02942
       60 AFMSet        EFM 428    428          0.00445         0.38348         419       419       8.22557         -0.12614
       60    SFC       SIM1 428    428          0.00357         0.00243         423       423      13.51513         -0.06551
       60    SFC       SIM2 428    428          0.00456         0.00314         325       325      15.17091          1.58021
       60    SFM        EFM 428    428          0.00486         0.00234         428       428       0.01344          0.00465
       60 SFMSet        EFM 428    428          0.00457         0.38834         410       410      10.36240          0.26023
       60    SLC       SIM1 428    428          0.00284         0.00249         427       428       0.18998         -0.00024
       60    SLC       SIM2 428    428          0.00307         0.00277         386       387      16.58762          0.80282
       60    WFC       SIM1 428    428          0.00357         0.00267         426       426       4.76233         -0.01389
       60    WFC       SIM2 428    428          0.00584         0.00395         270       275      15.88744         -1.29677
       60    WLC       SIM1 428    428          0.00313         0.00260         427       427       2.87926          0.00823
       60    WLC       SIM2 428    428          0.00317         0.00266         422       422       6.96626         -0.06269
