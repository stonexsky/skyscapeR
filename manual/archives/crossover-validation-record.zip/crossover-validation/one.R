library(swephR)
for(f in c('ephemeris.R','dates.R','misc.R','mechanics.R','horizon-events.R','crescent-crossovers.R','events.R')) source(file.path('skyscapeR/R',f))
skyscapeR.env<-list(calendar='G',timezone='UTC',dec='geo',refraction=TRUE,atm=1013.25,temp=15,cur.year=2026)
.sky_progress<-function(...) FALSE
.file_position<-function(jd,body,flags,...) {r<-swephR::swe_calc_ut(jd,body,bitwOr(as.integer(flags),2L));stopifnot(all(r$return>=0),all(bitwAnd(r$return,7L)==2L));r}
swe_set_ephe_path(normalizePath('efm-review/ephe'))
z<-EFM(1620,c(40,0,400));print(z)
t<-time2jd(paste(z$Moon$date,z$Moon$time));for(d in seq(-1,1,by=.25)){print(c(d,swe_calc_ut(t+d,1L,2050L)$xx[2],swe_calc_ut(t+d,0L,2050L)$xx[2]))}
