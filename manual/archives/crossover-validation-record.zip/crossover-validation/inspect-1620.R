library(swephR)
for(f in c('ephemeris.R','dates.R','misc.R','mechanics.R','horizon-events.R','crescent-crossovers.R','events.R')) source(file.path('skyscapeR/R',f))
skyscapeR.env<-list(calendar='G',timezone='UTC',dec='geo',refraction=TRUE,atm=1013.25,temp=15,cur.year=2026)
.sky_progress<-function(...) FALSE
.file_position<-function(jd,body,flags,...) {r<-swephR::swe_calc_ut(jd,body,bitwOr(as.integer(flags),2L));stopifnot(all(r$return>=0),all(bitwAnd(r$return,7L)==2L));r}
swe_set_ephe_path(normalizePath('efm-review/ephe'))
swe_set_topo(0,40,400)
for(nm in .cc_newmoons(time2jd("1620/09/01"),time2jd("1621/02/01"))){
 for(offset in 0:1){
 b<-.cc_crescent(nm,-1,c(40,0,400),c(40,0,400),TRUE,1013.25,15,"UTC","G")
 if(offset==1&&!is.null(b)) b<-.cc_observation(b$day-1,nm,-1,c(40,0,400),c(40,0,400),TRUE,1013.25,15)
 if(!is.null(b))print(c(date=jd2time(b$moonjd,"UTC","G"),offset=offset,moon=.cc_calc(b$moonjd,1L,2050L)[2],sun=.cc_calc(b$sunjd,0L,2050L)[2],diff=b$diff,margin=b$margin))
 }}
