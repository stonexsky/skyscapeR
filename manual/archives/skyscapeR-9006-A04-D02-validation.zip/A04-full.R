suppressPackageStartupMessages(library(skyscapeR))
stopifnot(as.character(packageVersion("skyscapeR"))=="2.0.9006")
jd0 <- 2451545.5
R <- pi/180
rows <- list()
check <- function(case,item,actual,expected,tol,unit) {
  rows[[length(rows)+1]] <<- data.frame(case,item,actual,expected,tol,unit,
    pass=isTRUE(abs(actual-expected)<=tol))
}
# Independent one-second scan, followed by scalar bisection on sign changes.
scanroots <- function(f,seconds) {
  y <- f(seconds)
  idx <- which(head(y,-1)*tail(y,-1)<0)
  roots <- vapply(idx,function(i) uniroot(f,seconds[i+0:1],tol=1e-7)$root,numeric(1))
  data.frame(t=roots,dir=ifelse(y[idx]<0,"rise","set"))
}
# Prescribed diurnal tracks; start offset avoids grid-aligned analytic roots.
for (lat in c(50,-35)) {
 track <- function(t) {
   H <- 2*pi*(t+.03137)
   cbind(az=(atan2(-sin(H),-sin(lat*R)*cos(H))/R)%%360,
         alt=asin(cos(lat*R)*cos(H))/R)
 }
 prof <- list(flat=cbind(c(0,360),0),raised=cbind(c(0,360),5),
   ridge=cbind(c(0,93,94,95,96,97,360),c(0,0,14,14,14,0,0)),
   notch=cbind(c(0,88,89,91,92,360),c(7,7,-1,-1,7,7)),
   step=cbind(c(0,94,94.02,125,125.02,360),c(0,0,11,11,0,0)))
 for (nm in names(prof)) {
  z <- prof[[nm]]; height <- approxfun(z[,1],z[,2])
  clearance <- function(t) {x<-track(t/86400);x[,2]-height(x[,1])}
  ref <- scanroots(clearance,0:86400)
  actual <- skyscapeR:::.horizon_crossings(function(t)as.numeric(track(t)),0,
    z[,1],z[,2],.all=TRUE,.duration=1)*86400
  key <- paste(lat,nm); check(key,"count",length(actual),nrow(ref),0,"events")
  if (length(actual)==nrow(ref)) for (i in seq_along(actual)) {
   check(key,paste(i,ref$dir[i]),actual[i],ref$t[i],.02,"seconds")
   check(key,paste("direction",i),sign(clearance(actual[i]+.1)-clearance(actual[i]-.1)),
         ifelse(ref$dir[i]=="rise",1,-1),0,"sign")
   check(key,paste("azimuth",i),track(actual[i]/86400)[1],track(ref$t[i]/86400)[1],.001,"deg")
  }
  if(nm %in% c("flat","raised")){
   hour <- acos(sin(z[1,2]*R)/cos(lat*R))/(2*pi)
   exact <- sort(((c(hour,1-hour)-.03137)%%1)*86400)
   check(key,"closed-form time",max(abs(actual-exact)),0,.02,"seconds")
  }
 }
}
# Analytic even-multiplicity touch; paired roots two seconds apart in one time cell.
for (gap in c(0,1)) {
 position <- function(t)c(90,gap^2-(86400*t-29.23)^2)
 roots <- skyscapeR:::.horizon_crossings(position,0,c(0,360),c(0,0),
                                          .duration=60/86400,.all=TRUE)*86400
 check(paste("tangency",gap),"count",length(roots),if(gap==0)0 else 2,0,"events")
 if (length(roots)==2) check("narrow emergence","roots",max(abs(roots-c(28.23,30.23))),0,.02,"seconds")
}
# Modern airless topocentric JPL centres. Use separate interpolation in Python.
ref <- read.csv("ref/jpl-events.csv")
loc <- c(35.90083,14.34,158)
for(body in c("Sun","Moon")) for(profile in c("flat","ridge")){
 z <- if(profile=="flat") cbind(c(0,360),0) else cbind(c(0,70,95,120,180,270,360),c(3,3,8,2,6,1,3))
 hor <- createHor(az=z[,1],alt=z[,2],loc=loc,verbose=FALSE)
 events <- riseset(loc=hor,date="2000/01/02",obj=tolower(body),calendar="G",timezone="UTC",refraction=FALSE,verbose=FALSE)
 for(dir in c("rise","set")){
  q <- subset(ref,object==body & skyline==profile & direction==dir)[1,]
  obs <- events[[dir]]; t <- (time2jd(paste(obs$date,obs$time),"UTC","G")-jd0)*86400
  key <- paste("JPL",body,profile,dir)
  check(key,"time",t,q$seconds,3,"seconds")
  check(key,"azimuth",obs$azimuth,q$az,.015,"deg")
 }
}
# Independent Swiss positions and sign brackets for the named-star public path,
# including a ridge which hides the star soon after it emerges. Choose local
# midnight so the first two crossings are on the ridge rather than a western set.
sloc <- c(50,100,0)
for (refr in c(FALSE,TRUE)) {
 z <- cbind(c(0,92,93,94,95,96,360),c(0,0,12,12,12,0,0))
 hor <- createHor(az=z[,1],alt=z[,2],loc=sloc,verbose=FALSE)
 horizon <- approxfun(z[,1],z[,2])
 swephR::swe_set_topo(sloc[2],sloc[1],0)
 pos <- function(t) {
  jd<-jd0+t/86400
  eq<-swephR::swe_fixstar2_ut(",del Ori",jd,34818L)
  # Match stellar flags in riseset (topocentric, equatorial, Swiss).
  stopifnot(eq$return>=0)
  x<-swephR::swe_azalt(jd,1L,sloc[c(2,1,3)],1013.25,15,eq$xx[1:3])$xaz
  c((x[1]+180)%%360,x[if(refr)3 else 2])
 }
 clearance<-function(tt)vapply(tt,function(t){p<-pos(t);p[2]-horizon(p[1])},numeric(1))
 refstar<-scanroots(clearance,seq(0,172800,by=5))
 result<-riseset(loc=hor,date="2000/01/02",obj="Mintaka",timezone="UTC",calendar="G",
                 refraction=refr,atm=1013.25,temp=15,verbose=FALSE)
 for(dir in c("rise","set")){
  s<-refstar$t[which(refstar$dir==dir)[1]]
  obs<-result[[dir]]
  t<-(time2jd(paste(obs$date,obs$time),"UTC","G")-jd0)*86400
  check(paste("Mintaka",refr,dir),"first event",t,s,1.1,"seconds")
  check(paste("Mintaka",refr,dir),"bearing",obs$azimuth,pos(s)[1],.001,"deg")
 }
 write.csv(refstar,paste0("A04-Mintaka-",refr,"-events.csv"),row.names=FALSE)
}
# Both hemispheres: missing event fields for an always-hidden star.
events<-riseset(loc=c(-50,0,0),date="2000/01/02",obj="Polaris",timezone="UTC",
                refraction=FALSE,verbose=FALSE)
check("always hidden","missing rows",sum(is.na(events$rise),is.na(events$set)),8,0,"fields")
# Search date boundary: a one-minute interval starting 30s before a known root.
position<-function(t)c(90,86400*(t-jd0)-30)
edge<-skyscapeR:::.horizon_crossings(position,jd0,c(0,360),c(0,0),.duration=60/86400)
check("boundary","upward crossing",(edge[1]-jd0)*86400,30,.02,"seconds")

# At UTC-02:30, midnight follows the first UT lunar rise by eleven minutes.
# The next lunar rise falls on the following local date, inside the 48 h search.
flat<-createHor(az=c(0,360),alt=c(0,0),loc=loc,verbose=FALSE)
nextday<-riseset(loc=flat,date="2000/01/02",obj="moon",calendar="G",
                 timezone="UTC-02:30",refraction=FALSE,verbose=FALSE)
r<-nextday$rise
target<-subset(ref,object=="Moon" & skyline=="flat" & direction=="rise" & seconds>9000)[1,]
t<-(time2jd(paste(r$date,r$time),"UTC-02:30","G")-jd0)*86400
check("next local date","timestamp",t,target$seconds,3,"seconds")
check("next local date","date label",as.numeric(substr(r$date,nchar(r$date)-1,nchar(r$date))),3,0,"day")
# Exercise the separate constant-altitude Solar System interface, matching centre/airless.
for(body in c("Sun","Moon")){
 result<-riseset(loc=loc,alt=0,date="2000/01/02",obj=tolower(body),calendar="G",
                 timezone="UTC",refraction=FALSE,verbose=FALSE)
 for(dir in c("rise","set")){
  q<-subset(ref, object==body & skyline=="flat" & direction==dir)[1,]
  obs<-result[[dir]]
  sec<-(time2jd(paste(obs$date,obs$time),"UTC","G")-jd0)*86400
  check(paste("JPL scalar",body,dir),"time",sec,q$seconds,3,"seconds")
  check(paste("JPL scalar",body,dir),"bearing",obs$azimuth,q$az,.015,"deg")
 }
}

results<-do.call(rbind,rows)
write.csv(results,"A04-full-results.csv",row.names=FALSE)
print(subset(results,!pass));stopifnot(all(results$pass))
