suppressPackageStartupMessages(library(skyscapeR))
stopifnot(as.character(packageVersion("skyscapeR"))=="2.0.9006")
dir.create("curves",showWarnings=FALSE)
scenarios <- data.frame(case=c("rising","falling","north","ridge","measured","refracted","pole","celestial-pole","wider"),
  centre=c(90,90,359,90,90,90,90,0,90),lat=c(50,50,50,50,35.90085,50,90,50,50),
  width=c(2,2,2,4,2,2,2,2,2),hm=c(.5,.5,.5,.25,.5,.5,.5,.5,1),
  elevation=c(0,0,0,0,158.3,0,0,0,0))
scenarios<-rbind(scenarios,data.frame(case=c("survey","near-pole"),centre=c(96,0),lat=c(51.76675,50),width=2,hm=.5,elevation=0))
write.csv(scenarios,"D02-design.csv",row.names=FALSE)
shapes <- list(rising=cbind(c(0,75,105,360),c(5,0,15,5)),
falling=cbind(c(0,75,105,360),c(5,15,0,5)),
north=cbind(c(0,10,350,360),c(5,10,0,5)),
ridge=cbind(c(0,87,89,91,93,360),c(2,2,13,13,2,2)),
measured=as.matrix(read.csv("ref/kuncizzjoni.csv")),
refracted=cbind(c(0,75,105,360),c(5,0,15,5)),
pole=cbind(c(0,360),2), 'celestial-pole'=cbind(c(0,360),50),
wider=cbind(c(0,75,105,360),c(5,0,15,5)))
survey<-as.matrix(read.csv("ref/canrooska.csv")[,1:2])
shapes$survey<-rbind(c(0,survey[1,2]),survey,c(360,survey[1,2]))
shapes[["near-pole"]]<-cbind(c(0,360),47)
# Independently vary integration, calculation and output spacing from a fixed baseline.
grid <- data.frame(label=c("default","integration","calculation","output","fine"),
                    res=c(.1,.1,.05,.1,.05),prec=c(.1,.05,.1,.1,.05),
                    out=c(.01,.01,.01,.005,.005))
summaries<-list()
for(i in seq_len(nrow(scenarios))){
 s<-scenarios[i,]; nm<-s$case; shape<-shapes[[nm]]
 profile<-data.frame(az=shape[,1],h=shape[,2],u=s$hm)
 write.csv(profile,paste0("curves/",nm,"-terrain.csv"),row.names=FALSE)
 hor<-createHor(az=profile$az,alt=profile$h,loc=c(s$lat,0,s$elevation),
                alt.unc=s$hm,verbose=FALSE)
 pdf<-az.pdf(s$centre,s$width,verbose=FALSE)
 skyscapeR.vars(refraction=(nm=="refracted"),temp=15,atm=1013.25)
 for(j in seq_len(nrow(grid))){
  g<-grid[j,]
  if (nm=="celestial-pole") {
    failure<-tryCatch({coordtrans(pdf,hor,.res=g$res,.prec=g$prec,.output.res=g$out,verbose=FALSE);""},error=conditionMessage)
    stopifnot(grepl("zero or nonfinite transformed uncertainty width",failure,fixed=TRUE))
    writeLines(failure,paste0("curves/",nm,"-expected-error.txt"))
    next
  }
  obj<-coordtrans(pdf,hor,.res=g$res,.prec=g$prec,.output.res=g$out,verbose=FALSE)
  d<-obj$data[[1]]; hdr<-hpdi(obj,mass=.8)[[1]]
  base<-paste0("curves/",nm,"-",g$label)
  write.csv(d,paste0(base,".csv"),row.names=FALSE)
  write.csv(hdr,paste0(base,"-hdr.csv"),row.names=FALSE)
 }
}
# Tabulate the package's specified Swiss refraction convention for both references.
h<-seq(-5,25,by=.005)
true<-vapply(h,function(a) 2*a-swephR::swe_refrac_extended(a,0,1013.25,15,0,0)$return,numeric(1))
write.csv(data.frame(h,true),"ref/refraction.csv",row.names=FALSE)
# A summed density on a shared irregular skyline is linear in its input density.
skyscapeR.vars(refraction=FALSE)
hor<-createHor(az=c(0,75,105,360),alt=c(5,0,15,5),loc=c(50,0,0),alt.unc=.5,verbose=FALSE)
pdf<-az.pdf(c(87,94),2,verbose=FALSE)
individual<-coordtrans(pdf,list(hor,hor),verbose=FALSE)
individualSum<-spd(individual,xrange=c(-8,20),.res=.05,normalise=TRUE)
sumAz<-spd(pdf,xrange=c(55,120),.res=.05,normalise=TRUE)
sumDec<-coordtrans(sumAz,hor,xrange=c(-8,20),.output.res=.05,verbose=FALSE)
area<-function(x,y)sum(diff(x)*(head(y,-1)+tail(y,-1))/2)
areaSum<-with(sumDec$data,area(x,y))
L1<-with(sumDec$data,area(x,abs(y/areaSum-individualSum$data$y)))
write.csv(data.frame(areaSum,L1),"D02-summed.csv",row.names=FALSE)
stopifnot(abs(areaSum-1)<.001,L1<.005)
