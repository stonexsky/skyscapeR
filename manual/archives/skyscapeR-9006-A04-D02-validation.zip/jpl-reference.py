from pathlib import Path
from io import StringIO
import numpy as np,pandas as pd
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq
out=[]
for body in ['Sun','Moon']:
 data=Path('ref',body+'.txt').read_text().split('$$SOE')[1].split('$$EOE')[0]
 rows=pd.read_csv(StringIO(data),header=None)
 az,alt=np.radians(rows[[4,5]].to_numpy()).T
 t=(rows[1].to_numpy()-2451545.5)*86400
 v=np.array([np.cos(alt)*np.sin(az),np.cos(alt)*np.cos(az),np.sin(alt)]).T
 spline=CubicSpline(t,v)
 coarse=CubicSpline(t[::2],v[::2])
 def angles(t,interp=spline):
  e,n,u=interp(t).T
  return np.degrees(np.arctan2(e,n))%360,np.degrees(np.arctan2(u,np.hypot(e,n)))
 for profile in ['flat','ridge']:
  def clear(t,interp=spline):
   a,h=angles(t,interp)
   return h if profile=='flat' else h-np.interp(a,[0,70,95,120,180,270,360],[3,3,8,2,6,1,3])
  tgrid=np.arange(0,172801,60);y=clear(tgrid)
  for i in np.where(y[:-1]*y[1:]<0)[0]:
   sec=brentq(clear,*tgrid[i:i+2])
   coarse_sec=brentq(lambda x:clear(x,coarse),sec-2,sec+2)
   assert abs(coarse_sec-sec)<0.05
   out.append(dict(coarsening_s=coarse_sec-sec,object=body,skyline=profile,direction='rise' if y[i]<0 else 'set',seconds=sec,az=angles(sec)[0]))
pd.DataFrame(out).to_csv('ref/jpl-events.csv',index=False)
