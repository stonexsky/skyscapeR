# Run from this directory with skyscapeR 2.0.9006 and modern Swiss ephemeris files.
suppressPackageStartupMessages(library(skyscapeR))
stopifnot(as.character(packageVersion("skyscapeR")) == "2.0.9006")
rad <- pi / 180
loc <- c(50, 0, 0)
az <- c(0, 65, 75, 115, 125, 360)
profiles <- list(flat = rep(0, 6), raised = rep(5, 6), east = c(0, 0, 5, 5, 0, 0))
expected <- function(dec, height, direction) {
  east <- acos((sin(dec*rad) - sin(loc[1]*rad)*sin(height*rad)) /
               (cos(loc[1]*rad)*cos(height*rad))) / rad
  if (direction == "rise") east else 360 - east
}
# The internal solver terminates its root search at 0.01 s.
# At 15 degrees/hour this is ~0.000042 degrees of rotation.
tol <- 0.001
track <- function(day) {
  H <- 2*pi*day
  c((atan2(-sin(H), -sin(loc[1]*rad)*cos(H))/rad) %% 360,
    asin(cos(loc[1]*rad)*cos(H))/rad)
}
rows <- list()
record <- function(path, profile, object, event, observed, reference) {
  pass <- if (is.na(reference)) is.na(observed) else isTRUE(abs(observed-reference) <= tol)
  rows[[length(rows)+1L]] <<- data.frame(path,profile,object,event,observed,reference,
                                         error_deg=observed-reference,pass)
}
for (profile in names(profiles)) {
  heights <- profiles[[profile]]
  horizon <- createHor(az=az,alt=heights,loc=loc,verbose=FALSE)
  roots <- skyscapeR:::.horizon_crossings(track,0,az,heights)
  result <- riseset(loc=horizon, date="2000/01/01",obj="Mintaka",timezone="UTC",
                    calendar="G",refraction=FALSE,verbose=FALSE)
  # Independent spherical calculation using a catalogue declination taken
  # at noon, fixed before consulting either event. Shares the ephemeris.
  swephR::swe_set_topo(0,50,0)
  eq <- swephR::swe_fixstar2_ut(",del Ori",2451545,32768L+2048L+2L)
  stopifnot(eq$return > 0)
  for (i in seq_along(roots)) {
    event <- c("rise","set")[i]
    h <- if (profile=="raised" || (profile=="east" && i==1)) 5 else 0
    record("solver",profile,"dec = 0",event,track(roots[i])[1],expected(0,h,event))
    record("riseset",profile,"Mintaka",event,result[[event]]$azimuth,
           expected(eq$xx[2],h,event))
  }
}
polar <- riseset(loc=horizon,date="2000/01/01",obj="Polaris",timezone="UTC",
                 calendar="G",refraction=FALSE,verbose=FALSE)
for (event in c("rise","set")) {
  stopifnot(all(is.na(polar[[event]])))
  record("riseset","east","Polaris",event,polar[[event]]$azimuth,NA_real_)
}
results <- do.call(rbind,rows)
write.csv(results,"A04-results.csv",row.names=FALSE)
print(results)
stopifnot(all(results$pass))
