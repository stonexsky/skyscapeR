suppressPackageStartupMessages(library(skyscapeR))
stopifnot(as.character(packageVersion("skyscapeR")) == "2.0.9006")
skyscapeR.vars(refraction=FALSE)
set.seed(9006)
n <- 1e6
zAz <- rnorm(n)
zAlt <- rnorm(n)
probs <- c(.025,.5,.975)
rad <- pi/180
# Predeclared absolute tolerance for quantiles includes sampling uncertainty,
# grids, finite input tails and the package's conditional Gaussian approximation.
tol <- .02
hor <- createHor(az=c(0,360),alt=c(2,2),alt.unc=.5,loc=c(50,0,0),verbose=FALSE)
rows <- list()
for (centre in c(90,359,0)) {
  bearing <- ((centre + 2*zAz) %% 360)*rad
  height <- (2 + .5*zAlt)*rad
  dec <- asin(sin(50*rad)*sin(height) + cos(50*rad)*cos(height)*cos(bearing))/rad
  reference <- unname(quantile(dec,probs))
  pdf <- az.pdf(centre,2,verbose=FALSE)
  for (step in c(.1,.05)) {
    g <- coordtrans(pdf,hor,.res=step,.prec=step,verbose=FALSE)$data[[1]]
    stopifnot(all(is.finite(g$y)), all(g$y>=0))
    mass <- c(0,cumsum(diff(g$x)*(head(g$y,-1)+tail(g$y,-1))/2))
    area <- tail(mass,1)
    estimates <- approx(mass/area,g$x,xout=probs,ties="ordered")$y
    rows[[length(rows)+1L]] <- data.frame(centre,step,prob=probs,estimate=estimates,
        reference,error_deg=estimates-reference,area,
        pass=abs(estimates-reference)<=tol & abs(area-1)<=1e-6)
  }
}
results <- do.call(rbind,rows)
write.csv(results,"D02-results.csv",row.names=FALSE)
print(results)
stopifnot(all(results$pass))
