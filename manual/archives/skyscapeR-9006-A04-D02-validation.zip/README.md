# Synthetic validation checks for skyscapeR 2.0.9006

## Reproduction

Install the specified package version and its dependencies. Make the modern Swiss planetary and lunar ephemeris files available to skyscapeR, for example by setting SE_EPHE_PATH before starting R. The stellar catalogue ships with skyscapeR. From the extracted directory, run each script in a fresh R session.

    Rscript A04.R
    Rscript D02.R

Each script writes a CSV and stops if a check fails. All angles and density quantiles in the tables use degrees. The reference input checksums and session information document this run.

## A04 subset, synthetic stellar skyline crossings

At latitude 50 N, longitude 0, elevation 0 m, refraction disabled, the solver was exercised with a prescribed zero-declination track. The public riseset() function was separately exercised with Mintaka and Polaris on 1 January 2000 UTC. The three profiles were level at zero, level at five degrees, and a five-degree ridge across the eastern crossing with a level western skyline. The reference solves the spherical altitude equation for azimuth. The named-star reference uses a fixed noon declination from the same Swiss ephemeris. Its purpose is to isolate the crossing calculation. For Polaris, both complete event records must be missing.

All 14 event checks passed. The maximum discrepancy for the prescribed track was below 0.000001 degrees and for Mintaka was 0.000022 degrees. The angular tolerance was 0.001 degrees. This exercise covers azimuth and event presence. Timing, grazing or multiple crossings, moving bodies and refraction remain outside its scope.

## D02 subset, propagation across north

Each input is a Gaussian bearing with standard deviation two degrees at latitude 50 N, horizon altitude two degrees and altitude standard deviation half a degree. For centres at 90, 359 and zero degrees the reference directly transforms one million pairs of independent Gaussian draws through the spherical altitude equation. The same seeded standard-normal draws are reused across centres. The package uses a Gaussian approximation to the conditional declination distribution. The reference propagates each draw directly.

At calculation and azimuth integration spacings of 0.1 and 0.05 degrees, the script compared the median and equal-tailed 95% interval endpoints, with an absolute tolerance of 0.02 degrees. All 18 quantile comparisons passed. All six output densities integrated to one within 0.000001. Maximum quantile discrepancy was 0.00505 degrees. This includes Monte Carlo sampling variation. These cases assess individual PDFs on a constant skyline with refraction disabled.

## S03

Global and local scoring were already tested in S03 in the manual for this release. They were not rerun here.

## Completed study protocol

Use fresh R sessions. Python requires NumPy, SciPy and pandas. From this directory run:

    python jpl-reference.py
    Rscript A04-full.R
    Rscript D02-full.R
    python D02-reference.py

The A04 full table contains one row per assertion, including expected and observed values, units and tolerances. The JPL tables are airless topocentric centre directions for Malta. Their exact request URLs and raw responses are in ref/. The independent solution interpolates East–North–Up vectors and bisects sign changes. Comparison with the half-rate reference grid checks interpolation. Internal timing tolerance is 0.02 s for analytic tracks, 1.1 s for whole-second public timestamps against the same ephemeris, and 3 s and 0.015 degrees for external comparisons, allowing for time labelling and ephemeris conventions. The reference scan uses one-second samples for day-long ideal tracks and five seconds for the named star. The two-second emergence has analytic roots; it is scored directly. A body centre crossing does not establish first naked-eye visibility.

D02 uses 524,288 scrambled Sobol pairs for direct altitude/bearing propagation and 8,192 midpoint probability strata for quadrature of the documented conditional Gaussian. Atmospheric settings are held fixed. The altitude correction table uses the same Swiss convention; this tests numerical propagation, not atmospheric realism. Input terrain 'measured' in the machine-readable files is the archived Kunċizzjoni terrain model (Tore Lomsdalen, Andrew Smith's Horizon). 'survey' is the Canrooska row theodolite profile, linearly interpolated between observations; source URL and original row locators accompany the measurements. See D02-full-results.csv, D02-quantiles.csv, D02-features.csv, D02-summed.csv and D02-pole-limit.csv. Modes use a common smoothed grid and 5% prominence. Package 80% highest-density regions use hpdi() on the native output grid; the direct reference uses the smoothed sample histogram. 'pole' means a geographic-pole observer. 'near-pole' and 'celestial-pole' describe sightlines approaching the celestial pole. The latter raises the documented zero-width diagnostic. No substituted density or increased input uncertainty is used.

For the nine nonsingular cases away from the celestial pole the maximum quantile discrepancy from direct propagation is under 0.008 degrees. The near-celestial-pole case has a 0.1715-degree discrepancy on the fine grid. Its agreement with independent conditional-model quadrature (within 0.0007 degrees) isolates the model approximation. The ridge has three prominent modes; the default grid fragments its middle 80% interval.
