"""Compare full altitude propagation and an independently integrated conditional Gaussian."""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.special import ndtr, ndtri
from scipy.stats import qmc
from scipy.integrate import cumulative_trapezoid
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks
from scipy.optimize import brentq

curves=Path('curves')
design=pd.read_csv('D02-design.csv')
points=ndtri(qmc.Sobol(2,scramble=True,seed=9006).random_base2(19))
atmos=pd.read_csv('ref/refraction.csv')
P=np.array([.025,.5,.975])
summary=[]; features=[]; details=[]
def intervals(x,y):
 idx=np.argsort(-y)
 threshold=y[idx[np.searchsorted(np.cumsum(y[idx]),.8*y.sum())]]
 mask=y>=threshold
 return zip(x[mask & ~np.r_[False,mask[:-1]]],x[mask & ~np.r_[mask[1:],False]])
def modes(x,y):
 peaks=find_peaks(y,prominence=.05*max(y))[0]
 return x[peaks]
for s in design.itertuples(index=False):
 p=pd.read_csv(curves/(s.case+'-terrain.csv'))
 def altitude(a):return np.interp(a%360,p.az,p.h)
 def transform(a,h):
  if s.case=='refracted': h=np.interp(h,atmos.h,atmos.true)
  a,h,phi=np.radians(a),np.radians(h),np.radians(s.lat)
  return np.degrees(np.arcsin(np.clip(np.sin(phi)*np.sin(h)+np.cos(phi)*np.cos(h)*np.cos(a),-1,1)))
 a=s.centre+s.width*points[:,0]
 draws=np.sort(transform(a,altitude(a)+s.hm*points[:,1]))
 rawq=np.quantile(draws,P)
 if s.case=='celestial-pole':
  pd.DataFrame({'prob':P,'direct_quantile':rawq}).to_csv('D02-pole-limit.csv',index=False)
  continue
 # Equal-probability midpoint quadrature over 8192 bearings. Integrate the
 # conditional normal analytically in declination using its CDF.
 aa=s.centre+s.width*ndtri((np.arange(8192)+.5)/8192)
 aa1=transform(aa,altitude(aa)-4*s.hm);aa2=transform(aa,altitude(aa)+4*s.hm)
 mu=(aa1+aa2)/2; sigma=abs(aa2-aa1)/8
 def mixcdf(x):return np.mean(ndtr((x-mu)/sigma))
 mixq=np.array([brentq(lambda x:mixcdf(x)-pr,-90,90) for pr in P])
 for label in ['default','integration','calculation','output','fine']:
  d=pd.read_csv(curves/(s.case+'-'+label+'.csv'));x=d.x.to_numpy();y=d.y.to_numpy()
  c=cumulative_trapezoid(y,x,initial=0);area=c[-1];c/=area
  truecdf=np.searchsorted(draws,x)/len(draws)
  gs=np.arange(0,len(x),max(1,len(x)//800))
  matched=np.array([mixcdf(xx) for xx in x[gs]])
  est=np.interp(P,c,x)
  row=dict(case=s.case,grid=label,mass_error=area-1,
          cdf_direct=max(abs(c-truecdf)),cdf_model=max(abs(c[gs]-matched)),
          max_q_direct=max(abs(est-rawq)),max_q_model=max(abs(est-mixq)))
  for pr,z,v,w in zip(P,est,rawq,mixq):details.append(dict(case=s.case,grid=label,p=pr,package=z,direct=v,conditional=w))
  summary.append(row)
  if label not in ['default','fine']:continue
  # Direct-reference feature locations use the probability in 0.02-degree
  # bins smoothed at 0.06 degrees. Apply identical smoothing to package modes.
  ticks=np.arange(np.floor(draws[0])-1,np.ceil(draws[-1])+1,.02)
  xx=(ticks[:-1]+ticks[1:])/2
  histogram=gaussian_filter1d(np.histogram(draws,ticks)[0].astype(float),3)
  fitted=gaussian_filter1d(np.interp(xx,x,y,left=0,right=0),3)
  hdr=pd.read_csv(curves/(s.case+'-'+label+'-hdr.csv'))
  for origin,mm,hh in [('package',modes(xx,fitted),hdr.to_numpy()),('direct',modes(xx,histogram),list(intervals(xx,histogram)))]:
   features.append(dict(case=s.case,grid=label,origin=origin,modes=' / '.join(f'{m:.3f}' for m in mm),
           hdr80=' / '.join(f'{a:.3f} to {b:.3f}' for a,b in hh)))
pd.DataFrame(summary).to_csv('D02-full-results.csv',index=False)
pd.DataFrame(features).to_csv('D02-features.csv',index=False)
pd.DataFrame(details).to_csv('D02-quantiles.csv',index=False)
