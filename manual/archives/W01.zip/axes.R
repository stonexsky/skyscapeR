source("plots.R")
out<-list()
for(coord in c("az","dec"))for(width in c(4,10))for(local in c(FALSE,TRUE))for(zoom in c(FALSE,TRUE)){
 x<-fit
 if(coord=="dec"){x$metadata$coord<-"dec"; x$data$empirical$x<-seq(-90,90,length.out=361);x$data$null.hyp$x<-x$data$empirical$x;x$metadata$local.pval<-data.frame(type="+",start=-8,end=5,p.value=.02)}
 limits<-if(zoom){if(coord=="az") c(340,380) else c(-17,23)}else range(x$data$empirical$x)
 before<-serialize(x,NULL)
 pdf(NULL,width=width,height=4);events<-list()
 plot(x,xrange=limits,show.local=local)
 minor<-Filter(function(e)e$kind=="axis" && identical(e$args$tcl,-.10),events)
 major<-Filter(function(e)e$kind=="axis" && identical(e$args[[1]],1) && is.numeric(e$args$labels),events)
 stopifnot(length(minor)==1,length(major)==1)
 a<-major[[1]]$args; b<-minor[[1]]$args$at
 stopifnot(all(a$at>=min(limits)-1e-9 & a$at<=max(limits)+1e-9),all(b>=min(limits)&b<=max(limits)), !any(b %in% a$at), identical(before,serialize(x,NULL)),isTRUE(all.equal(a$labels,if(coord=="az") a$at%%360 else a$at)))
 out[[length(out)+1]]<-data.frame(coord,width,local,zoom,major=length(a$at),minor=length(b))
 dev.off()
}
r<-do.call(rbind,out);write.csv(r,"axes.csv",row.names=FALSE)
