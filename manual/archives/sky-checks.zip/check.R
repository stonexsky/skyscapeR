library(skyscapeR)
D<-pi/180
g<-readRDS(system.file("extdata","milky-way-layers.rds",package="skyscapeR"))
stopifnot(identical(dim(g),c(3600L,1201L)),identical(sort(unique(as.integer(g))),0:4))
lookup<-function(l,b) skyscapeR:::.galactic_classes(cos(b*D)*cos(l*D),cos(b*D)*sin(l*D),sin(b*D),diag(3))
# Every stored cell, including edge rows and seam, is visited at its centre.
for(j in seq_len(ncol(g))){l<-seq(-180,179.9,by=.1);b<--60+(j-1)/10
  stopifnot(identical(lookup(l,b),as.integer(g[,j])))}
stopifnot(all(lookup(c(-180,180,540),0)==lookup(180,0)),all(lookup(c(0,0),c(-61,61))==0))
f<-expand.grid(l=seq(284.95,289.05,.1),b=seq(-4.05,.05,.1))
inside<-with(f,acos(pmin(1,sin(-2*D)*sin(b*D)+cos(-2*D)*cos(b*D)*cos((l-287)*D)))/D<=2)
f<-f[inside,]; ix<-1L+(floor((f$l+180)*10+.5)%%3600); iy<-1L+floor((f$b+60)*10+.5)
flux<-weighted.mean(skyscapeR:::.mw_radiance()[as.integer(g[cbind(ix,iy)])+1],cos(f$b*D))
mag.grid <- -2.5*log10(flux/3600^2); lon<-f$l*pi/180; latr<-f$b*pi/180; brightness<-skyscapeR:::.mw_radiance()[skyscapeR:::.galactic_classes(cos(latr)*cos(lon),cos(latr)*sin(lon),sin(latr),diag(3))+1L]; mag<- -2.5*log10(weighted.mean(brightness,cos(f$b*D))/3600^2); print(c(mag=mag,cell_tie_check=mag.grid));stopifnot(abs(mag-20.7)<1e-8)
lat<-seq(-60,60,by=.1)
png("milky-way-classes.png",width=2000,height=650,res=170)
par(mar=c(3.6,4,1,1),las=1,mgp=c(2.3,.7,0))
col<-c("white","#aebfd0","#49596a","#69a79b","#256b63")
image(l,lat,matrix(as.integer(g),nrow(g)),col=col,xaxs="i",ylim=c(-40,40),useRaster=TRUE,
   xlab="Galactic longitude (°)",ylab="Galactic latitude (°)")
legend("topright",c("Ordinary","Dark","Bright","Brightest"),ncol=4,fill=col[-1],bty="n",cex=.75)
dev.off()
hor<-createHor(az=0:359,alt=rep(0,360),loc=c(51,-1,100),verbose=FALSE)
pdf(NULL)
for(style in c("publication-colour","publication-mono")){
 for(k in c(0,.2))for(flag in c(TRUE,FALSE)){
   args<-list(hor=hor,jd=2451545,style=style,k=k,band.extinction=flag)
   s<-do.call(sketchSky,args); t<-skyStep(hor,s,minutes=1)
   stopifnot(identical(s$publication.band.k,if(flag) k else 0),
             identical(t$settings$band.extinction,flag),identical(t$publication.band.k,s$publication.band.k))
 }
 a<-sketchSky(hor,jd=2451545,style=style,k=.2);stopifnot(isTRUE(a$settings$band.extinction),a$publication.band.k==.2)
}
dev.off()
alt<-c(5,15,45,90)
trans<-10^(-.4*.2/(sin(alt*D)+.025*exp(-11*sin(alt*D))))
stopifnot(max(abs(trans-skyscapeR:::.band_transmission(alt,.2)))<1e-12)
write.csv(data.frame(alt,transmission=trans,Carina_mag=mag,half_cell_convention_mag=mag.grid),"photometry.csv",row.names=FALSE)
