Run Rscript check.R.
Current package run: skyscapeR 2.0.9015, revision fec1c516e8cf9b8caa0bb560fe797dc1c7847b18. Run commands in the extracted directory.
