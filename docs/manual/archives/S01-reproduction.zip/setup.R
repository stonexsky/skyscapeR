suppressPackageStartupMessages(library(skyscapeR))
skyscapeR.vars(refraction=FALSE)
makehor <- function(lat,rough=FALSE) {
  xx<-seq(0,360,by=10)
  h<-if(rough) 4+3*sin(2*pi*xx/120)+1.5*cos(2*pi*xx/60) else rep(2,length(xx))
  createHor(az=xx,alt=h,loc=c(lat,0,0),alt.unc=1,verbose=FALSE)
}
H<-list(makehor(46,TRUE),makehor(-30,TRUE))
settings <- function(route,res=2,grid=30,width=c(22,32),family="normal",cutoff=1e-4) {
 list(family=family,unc=width,coord=if(route=="az") "az" else "dec",quick=route=="shared",
      xrange=if(route=="az") c(0,360) else c(-90,90),resolution=res,normalise=FALSE,
      source.res=grid,source.cutoff=cutoff,
      transform=list(hor=if(route=="paired") H else H[[1]],refraction=FALSE,atm=1013.25,temp=15,
                     .res=if(route=="shared") res else .5,.prec=.2,.output.res=.1))
}
observed <- function(draw,s,route) {
 p<-az.pdf(draw,s$unc,pdf=s$family,.res=s$source.res,.cutoff=s$source.cutoff,verbose=FALSE)
 if(route=="shared"){
  h<-coordtrans(spd(p,.res=s$resolution),H[[1]],xrange=s$xrange,.res=s$resolution,verbose=FALSE)
  return(h$data$y)
 }
 if(route=="paired")p<-coordtrans(p,s$transform$hor,.res=.5,.prec=.2,.output.res=.1,verbose=FALSE)
 spd(p,xrange=s$xrange,.res=s$resolution)$data$y
}
