"""Independent outer datasets and fresh null draws for every fit."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import ctypes, subprocess, os
import numpy as np
import pandas as pd
from scipy.stats import binomtest
if __name__=='__main__' or not Path('score.so').exists():
    subprocess.run(['g++','-O3','-std=c++17','-shared','-fPIC','score.cpp','-o','score.so'],check=True)
lib=ctypes.CDLL(str(Path('score.so').resolve()))
ptr=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
lib.ranks.argtypes=[ptr,ctypes.c_int,ctypes.c_int,ctypes.c_double,ctypes.c_int,ctypes.c_int,ptr]
def score(matrix,step,tails,circular):
    matrix=np.ascontiguousarray(matrix[:,:-1] if circular else matrix)
    out=np.zeros(2);lib.ranks(matrix,*matrix.shape,step,tails,int(circular),out)
    return out
# All conditions have 2000 independent outer observations. Clustered bearings
# are rounded onto exactly the same allowed support as null bearings.
conditions=[
 ('az-standard','az',12,39,2,0,0),('paired-standard','paired',12,39,2,0,0),
 ('shared-standard','shared',2,19,2,0,0),('az-small','az',4,39,2,0,0),
 ('az-large','az',24,39,2,0,0),('az-one-tail','az',12,39,1,0,0),
 ('az-finer','az-fine',12,39,2,0,0),('az-more-sims','az',12,99,2,0,0),
 ('az-ties','tied',4,19,2,0,0),('az-below-resolution','az',12,9,2,0,0),
 ('az-weak','az',12,39,2,3,24),('az-medium','az',12,39,2,6,24),
 ('az-narrow','az',12,39,2,6,6),('paired-narrow','paired',12,39,2,6,6),
 ('shared-richer','shared-richer',2,39,2,0,0),('shared-flat','shared-flat',2,19,2,0,0),('az-default-input','az-default-input',12,39,2,0,0)]
def batch(job):
    ci,start=job
    name,bank,n,B,tails,k,sigma=conditions[ci]
    info=pd.read_csv('banks/'+bank+'.csv').iloc[0]
    m=np.fromfile('banks/'+bank+'.bin','<f8').reshape(int(info.rows),int(info.cols))
    step=info.step;support=int(360/step);quick=info.route=='shared';circle=info.route=='az'
    out=[]
    for i in range(start,start+50):
        rng=np.random.default_rng(np.random.SeedSequence([9007,ci,i]))
        draw=rng.integers(support,size=(B+1,n))
        if k: draw[0,:k]=np.rint(rng.normal(0,sigma,k)/step).astype(int)%support
        if bank=='az-default-input':
            x=np.arange(361)*100
            M=m[0,(x-draw[:,0,None])%support].copy()
            for j in range(1,n): M+=m[j%2,(x-draw[:,j,None])%support]
        elif quick: M=m[draw[:,0]*support+draw[:,1]]
        else:
            M=m[draw[:,0]].copy()
            for j in range(1,n): M+=m[draw[:,j]+support*(j%2)]
        pg,pl=score(M,.01 if quick else info.out,tails,circle)
        out.append((name,i,pg,pl))
    return out
if __name__=='__main__':
    with ProcessPoolExecutor(max_workers=6) as ex:
        chunks=ex.map(batch,[(c,s) for c in range(len(conditions)) for s in range(0,2000,50)])
        with open('outer.csv','w') as f:
            f.write('case,index,global_p,any_local_p\n')
            for chunk in chunks:
                f.writelines(','.join(map(str,row))+'\n' for row in chunk);f.flush()
    data=pd.read_csv('outer.csv');rows=[]
    for name,bank,n,B,tails,k,sigma in conditions:
        d=data[data.case==name];assert len(d)==2000
        for alpha in [.01,.05,.10]:
            for metric in ['global_p','any_local_p']:
                count=int((d[metric]<=alpha).sum())
                lo,hi=binomtest(count,len(d)).proportion_ci(method='wilson')
                rows.append((name,bank,n,B,tails,k,sigma,alpha,metric,count,len(d),count/len(d),lo,hi,
                             np.floor(alpha*(B+1)+1e-10)/(B+1)))
    pd.DataFrame(rows,columns=['case','bank','sample_size','B','tails','cluster_n','cluster_sd','alpha','metric','reject','outer','rate','lower95','upper95','attainable']).to_csv('rates.csv',index=False)
