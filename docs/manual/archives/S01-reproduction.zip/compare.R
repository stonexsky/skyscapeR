source("setup.R")
rows<-list()
for(route in c("az","shared","paired")){
 s<-settings(route);draw<-c(30,120)
 sim<-skyscapeR:::.random_curve(draw,s)
 emp<-observed(draw,s,route)
 rows[[route]]<-data.frame(route,max_abs=max(abs(sim-emp)),length=length(emp))
}
write.csv(do.call(rbind,rows),paste0("same-draw-",packageVersion("skyscapeR"),".csv"),row.names=FALSE)
