# S01 — calibration of the uniform-orientation null

Each of 17 conditions uses 2,000 independent outer datasets and fresh null draws per dataset. 13 conditions use uniform centres and four inject a cluster. All inputs use a complete circle with north sampled once, a fixed family, paired widths and fixed site order. "Any local p" is the smallest maximum-cluster-adjusted probability returned for the observed dataset, or one when there is no cluster. Each interval in rates.csv is a pointwise 95% Wilson interval over independent outer datasets. Rates at 1%, 5% and 10% use an inclusive threshold. Finite-B ranks move in steps of 1/(B+1); ties can reduce rejection further.

Use R with skyscapeR 2.0.9007, Python with NumPy, pandas and SciPy, and a C++17 compiler (g++). Run in the extracted directory on a Unix-like system:

    Rscript banks.R
    Rscript public.R
    python calibrate.py
    python verify.py

The R scripts produce each basis density via package functions. For the azimuth and site-specific routes, the simulation sums the contributions in input order. The shared-horizon route precomputes the entire nonlinear path for every ordered pair of allowed bearings. The 0.01-degree case uses rotation of periodic package templates. Sixteen independently generated public fits verify these reconstructions and the rank implementation. Each route is also compared on one and two workers with the same seed. On systems with an ordinary R installation the worker override can be left unset. All run-specific library paths were supplied outside these scripts. The fresh simulation output is outer.csv and rates.csv; the public replay summary is public-checks.csv. The recorded workers.csv and public-checks.csv summarise direct verification. Running compare.R under 2.0.9006 and then 2.0.9007 reproduces the same-input diagnostic, using setup.R in both builds. Session versions are recorded in versions.txt.

Source grids are 6° for the main azimuth and site-paired comparisons, 60° and 30° for the two-observation shared routes, 30° for the uniform-family ties, and 0.01° for the additional azimuth comparison. Score grids are specified in banks.R; the shared route returns a 0.01° declination grid. The source cutoff is 0.0001. The six-direction and twelve-direction shared cases deliberately allow exhaustive evaluation of the transform. Sources of each simulated draw are independently uniform on the support. Power alternatives place three or six out of twelve bearings around 0°, then round to the same support; they do not select or tune the cluster after examining the data. Settings, seeds, numerical references and every p-value are included.
