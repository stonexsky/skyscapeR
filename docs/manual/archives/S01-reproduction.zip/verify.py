from calibrate import score
import numpy as np,pandas as pd
from pathlib import Path
rows=[]
for pp in sorted(Path('public').glob('*-p.csv')):
    key=pp.name[:-6];bank=key.rsplit('-',1)[0]
    s=pd.read_csv('banks/'+bank+'.csv').iloc[0]
    m=np.fromfile('banks/'+bank+'.bin','<f8').reshape(s.rows,s.cols)
    rng=pd.read_csv('public/'+key+'-draws.csv').to_numpy()
    idx=np.rint(rng/s.step).astype(int);support=int(360/s.step)
    shared=s.route=='shared'
    if bank=='az-default-input':
        x=np.arange(361)*100
        bankmat=m[0,(x-idx[:,0,None])%support].copy()
        for j in range(1,idx.shape[1]):bankmat+=m[j%2,(x-idx[:,j,None])%support]
    elif shared: bankmat=m[idx[:,0]*support+idx[:,1]]
    else:
        bankmat=m[idx[:,0]].copy()
        for j in range(1,idx.shape[1]):bankmat+=m[idx[:,j]+(j%2)*support]
    raw=np.fromfile('public/'+key+'-matrix.bin','<f8').reshape(bankmat.shape)
    delta=np.max(abs(bankmat-raw))
    observed=pd.read_csv(pp).to_numpy()[0]
    ranks=score(bankmat,.01 if shared else s.out,2,s.route=='az')
    native=score(raw,.01 if shared else s.out,2,s.route=='az')
    rows.append(dict(key=key,max_error=delta,global_public=observed[0],local_public=observed[1],
                     global_bank=ranks[0],local_bank=ranks[1],global_native=native[0],local_native=native[1]))
df=pd.DataFrame(rows);df.to_csv('public-checks.csv',index=False);print(df.to_string(index=False))
assert len(df)==16 and (df.max_error<1e-12).all()
for field in ['global','local']:
    assert (df[field+'_bank']==df[field+'_public']).all() and (df[field+'_native']==df[field+'_public']).all()
