source("setup.R")
stopifnot(as.character(packageVersion("skyscapeR"))=="2.0.9007")
dir.create("banks",showWarnings=FALSE)
saveBank <- function(id,route,step,out,widths,family="normal",nested=FALSE) {
  centres<-seq(0,360-step,by=step)
  if(nested) {
    pairs<-expand.grid(second=centres,first=centres)
    jobs<-seq_len(nrow(pairs))
    f<-function(i) observed(as.numeric(unlist(pairs[i,c("first","second")])),settings(route,out,step,widths,family),route)
  } else {
    jobs<-seq_len(2*length(centres))
    f<-function(i){
      k<-1+(i-1)%/%length(centres)
      s<-settings(route,out,step,widths[k],family)
      if(route=="paired")s$transform$hor<-H[[k]]
      observed(centres[1+(i-1)%%length(centres)],s,route)
    }
  }
  m<-parallel::mclapply(jobs,f,mc.cores=4)
  stopifnot(all(vapply(m,is.numeric,logical(1))))
  mat<-do.call(rbind,m);writeBin(as.double(t(mat)),paste0("banks/",id,".bin"),endian="little")
  write.csv(data.frame(id,route,step,out,widths=paste(widths,collapse="/"),family,nested,rows=nrow(mat),cols=ncol(mat)),paste0("banks/",id,".csv"),row.names=FALSE)
}
saveBank("az","az",6,1,c(6,9))
saveBank("az-fine","az",6,.5,c(6,9))
saveBank("tied","az",30,2,c(40,40),"uniform")
saveBank("paired","paired",6,1,c(6,9))
saveBank("shared","shared",60,2,c(40,50),nested=TRUE)

saveBank("shared-richer","shared",30,1,c(16,24),nested=TRUE)
H[[1]]<-makehor(46,FALSE)
saveBank("shared-flat","shared",60,2,c(40,50),nested=TRUE)
# For the 0.01-degree support, store one periodic template per width and
# index its rotation at the score-grid bearings when assembling each dataset.
p<-az.pdf(c(0,0),c(2,4),.res=.01,.cutoff=1e-4,verbose=FALSE)
m<-t(vapply(1:2,function(i) head(spd(subset(p,i),xrange=c(0,360),.res=.01)$data$y,-1),numeric(36000)))
writeBin(as.double(t(m)),"banks/az-default-input.bin",endian="little")
write.csv(data.frame(id="az-default-input",route="az",step=.01,out=1,widths="2/4",family="normal",nested=FALSE,rows=2,cols=36000),"banks/az-default-input.csv",row.names=FALSE)
