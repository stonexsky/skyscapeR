source("setup.R")
if(nzchar(Sys.getenv("S01_RSCRIPT"))) parallel:::setDefaultClusterOptions(rscript=Sys.getenv("S01_RSCRIPT"))
dir.create("public",showWarnings=FALSE)
ns<-asNamespace("skyscapeR")
trace(".simulation_inference",where=ns,print=FALSE,tracer=quote({
 assign("matrix_seen",rbind(observed$y,memory),envir=.GlobalEnv)
}))
for(id in c("az","az-fine","tied","paired","shared","shared-richer","shared-flat","az-default-input")){
 info<-read.csv(paste0("banks/",id,".csv"))
 route<-info$route
 H[[1]]<-makehor(46,id!="shared-flat")
 width<-as.numeric(strsplit(info$widths,"/",fixed=TRUE)[[1]])
 n<-if(route=="shared")2 else 12
 centres<-seq(0,360-info$step,info$step); w<-rep(width,length.out=n)
 s<-settings(route,info$out,info$step,w,info$family)
 sites<-rep(H,length.out=n)
 for(seed in c(44,9007)){
  set.seed(seed+1);draw<-sample(centres,n,replace=TRUE)
  p<-az.pdf(draw,w,.res=info$step,pdf=info$family,.cutoff=s$source.cutoff,verbose=FALSE)
  if(route=="paired") dec<-coordtrans(p,sites,.res=.5,.prec=.2,.output.res=.1,verbose=FALSE)
  run<-function(workers) {
   set.seed(seed)
   opts<-list(nsims=19,conf=.95,tails=2,.res=info$out,ncores=workers,verbose=FALSE)
   args<-switch(route,az=list(pdf=p),shared=list(pdf=p,hor=H[[1]]),paired=list(pdf=dec,az=p,hor=sites))
   do.call(randomTest,c(args,opts))
  }
  one<-run(1)
  key<-paste0("public/",id,"-",seed)
  set.seed(seed); draws<-rbind(draw,t(replicate(19,sample(centres,n,replace=TRUE))))
  write.csv(draws,paste0(key,"-draws.csv"),row.names=FALSE)
  writeBin(as.double(t(matrix_seen)),paste0(key,"-matrix.bin"),endian="little")
  lo<-one$metadata$local.pval
  local<-if(nrow(lo)) min(lo$p.value) else 1
  write.csv(data.frame(global=one$metadata$global.pval,local=local),paste0(key,"-p.csv"),row.names=FALSE)
  if(seed==44 && id %in% c("az","shared","paired")) {
   two<-run(2)
   cat(id, "worker comparison:",paste(all.equal(one$data,two$data),collapse=" / "),"\n");saveRDS(list(one=one,two=two),paste0("public/",id,"-workers.rds"))
   stopifnot(identical(one$metadata$global.pval,two$metadata$global.pval),
      identical(one$metadata$local.pval,two$metadata$local.pval),
      identical(one$data,two$data))
   cat(id,"one and two workers agree\n")
  }
 }
}
untrace(".simulation_inference",where=ns)
