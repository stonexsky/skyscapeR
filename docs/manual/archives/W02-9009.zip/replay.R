suppressPackageStartupMessages(library(skyscapeR));library(swephR)
ver<-as.character(packageVersion("skyscapeR")); out<-paste0("run-",ver);dir.create(out,showWarnings=FALSE)
saveTable<-function(x,n)write.csv(x,file.path(out,paste0(n,".csv")),row.names=FALSE)
skyscapeR.vars(refraction=TRUE,timezone="UTC",calendar="J")
# Controlled raw instrument fixture, separate from published true bearings.
loc<-c(35.84,14.57,100)
raw<-data.frame(id=c("east","west"),circle=c(2.25,358.75),sun.circle=c(358.75,2.25),magnetic=c(359,1),correction=c(3,-3))
saveTable(raw,"01-raw-control")
comp<-reduct.compass(loc,raw$magnetic,magdec=raw$correction,alt=c(2,2))
saveTable(comp,"02-compass")
theo<-reduct.theodolite(matrix(loc,1),raw$circle,az.sun=raw$sun.circle,date="2026/02/20",time="11:07:17",tz="Europe/Malta",alt=c(2,2))
saveTable(theo,"03-theodolite")
single<-tryCatch(as.character(reduct.theodolite(loc,2.25,az.sun=358.75,date="2026/02/20",time="11:07:17",tz="Europe/Malta")$True.Azimuth),error=conditionMessage)
saveTable(data.frame(single),"03-single")
# Maltese entrance edges are published reduced bearings.
idx<-which(malta_entrances$Phase=="Ggantija")
sites<-malta_entrances[idx,];hors<-malta_horizons[idx]
w<-(sites[['Az R']]-sites[['Az L']])%%360; centres<-(sites[['Az L']]+w/2)%%360
inputs<-data.frame(sites,horizon=vapply(hors,function(h)as.character(h$metadata$name),character(1)),width=w,centre=centres)
saveTable(inputs,"04-assignment")
h<-hors[[1]];a<-c(sites[['Az L']][1],sites[['Az R']][1])
edge<-data.frame(az=a,alt=hor2alt(h,a),dec=az2dec(a,h))
saveTable(edge,"05-mnajdra")
p<-az.pdf(centres,w/2,pdf="uniform",.res=.1,name=sites$Name,verbose=FALSE)
D<-coordtrans(p,hors,.res=.1,.prec=.1,.output.res=.05,verbose=FALSE)
store<-function(obj,n){saveTable(do.call(rbind,lapply(seq_along(obj$data),function(i)data.frame(site=sites$Name[i],obj$data[[i]]))),n)}
store(p,"06-azpdf");store(D,"07-decpdf");saveTable(spd(D,.res=.1)$data,"08-sum")
saveTable(hpdi(D,mass=.68)[[1]],"09-hdr")
set.seed(42);fit<-randomTest(D,az=p,hor=hors,nsims=39,ncores=1,.res=.5,verbose=FALSE)
saveTable(data.frame(global=fit$metadata$global.pval,B=39),"10-random");saveTable(fit$metadata$local.pval,"10-local")
# Fixed candidate weights exercise the second group route without implying a historical hypothesis.
set.seed(42);mt<-modelTest(p,data.frame(x=c(100,140,190,250),w=c(1,4,4,1)),nsims=39,ncores=1,.res=.5,verbose=FALSE)
saveTable(data.frame(global=mt$metadata$global.pval,B=39),"11-specified")
# Reproduce the published group target search even if the smaller replay has another peak.
cached<-readRDS(system.file("extdata","ggantija-random-500.rds",package="skyscapeR"))
pk<-subset(cached$metadata$local.pval,type=="+" & p.value<.05)[1,]
period<-c(-3399,-3099)
screen<-findTargets(c(pk$start,pk$end),period,dates=TRUE)
saveTable(screen$stellar,"12-candidates");target<-skyObject("Gacrux",period)
saveTable(data.frame(epoch=rownames(target$decs),dec=target$decs[,1]),"13-band")
i<-match("Skorba West",sites$Name);h2<-hors[[i]];year<--3249
ph<-star.phases("Gacrux",year,h2); ev<-ph$metadata$events
saveTable(ev,"14-events");day<-ev$date.julian[ev$event=="heliacal rising"]
jd<-time2jd(day,calendar="J",timezone="UTC")
rs<-riseset(h2,jd=jd+5,obj="Gacrux",calendar="J",timezone="UTC",verbose=FALSE)$rise
saveTable(rs,"15-rise")
t<-time2jd(paste(rs$date,rs$time),"UTC","J")+20/1440
sky<-sketchSky(h2,jd=t,style="natural")
pos<-as.numeric(sky$stars["gam Cru",c("az","alt")])
saveTable(data.frame(site=sites$Name[i],jd=t,az=pos[1],alt=pos[2],left=sites[['Az L']][i],right=sites[['Az R']][i],clearance=pos[2]-hor2alt(h2,pos[1])),"16-sketch")
# Perturb one upstream choice at a time.
pairs<-hors;pairs[c(1,i)]<-pairs[c(i,1)]
bad<-coordtrans(p,pairs,.res=.1,.prec=.1,.output.res=.05,verbose=FALSE)
shift<-function(a,b)abs(weighted.mean(a$x,a$y)-weighted.mean(b$x,b$y))
saveTable(data.frame(site=sites$Name,shift=mapply(shift,D$data,bad$data)),"17-swapped")
skyscapeR.vars(refraction=FALSE)
newD<-coordtrans(p,hors,.res=.1,.prec=.1,.output.res=.05,verbose=FALSE)
set.seed(42);again<-randomTest(D,az=p,hor=hors,nsims=39,ncores=1,.res=.5,verbose=FALSE)
saveTable(data.frame(stored_identical=identical(fit$data,again$data),global=again$metadata$global.pval,
 mean_shift_deg=mean(mapply(shift,D$data,newD$data))),"18-atmosphere")
north<-az.pdf(0,2,pdf="uniform",.res=.1,verbose=FALSE)
saveTable(coordtrans(north,h,.res=.1,verbose=FALSE)$data[[1]],"19-north")
photo<-importPanorama("archive-mask.png",loc,az.lim=c(330,30),alt.lim=c(-4,6))
status<-tryCatch({coordtrans(az.pdf(180,1,pdf="uniform",verbose=FALSE),photo,verbose=FALSE);"finite"},error=conditionMessage)
saveTable(data.frame(status),"20-partial")
