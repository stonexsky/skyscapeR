from pathlib import Path
import numpy as np,pandas as pd
b=Path("run-2.0.9009");old=Path("run-2.0.9004")
def read(p,key):return pd.read_csv(p/(key+'.csv'))
checks=[]
def test(case,val):
 checks.append((case,bool(val)))
raw=read(b,'01-raw-control'); c=read(b,'02-compass');t=read(b,'03-theodolite')
test('magnetic + correction modulo 360',np.allclose(c['True.Azimuth']%360,(raw.magnetic+raw.correction)%360))
test('solar-circle difference modulo 360',np.allclose(t['True.Azimuth'],(t['Sun.Az']+raw.circle-raw['sun.circle'])%360))
test('single three-coordinate site',read(b,'03-single').single.iloc[0]==161.23)
site=read(b,'04-assignment')
test('17 distinct, ordered entrances',len(site)==17 and site.Name.is_unique)
edge=read(b,'05-mnajdra')
test('published Mnajdra edges in order',np.allclose(edge.az,[90.94,99.14]) and np.allclose(edge.dec,[1.71,-5.48]))
for name in ['06-azpdf','07-decpdf']:
 d=read(b,name);test(name+' ordering',d.site.drop_duplicates().tolist()==site.Name.tolist())
 test(name+' finite nonnegative',np.all(np.isfinite(d[['x','y']])) and (d.y>=0).all())
 if name=='07-decpdf':
  areas=[np.trapezoid(x.y,x.x) for _,x in d.groupby('site',sort=False)]
  test('individual declination density masses',np.max(abs(np.array(areas)-1))<1e-9)
decs=read(b,'07-decpdf')
spd=read(b,'08-sum')
ref=sum(np.interp(spd.x,d.x,d.y,left=0,right=0) for _,d in decs.groupby('site',sort=False))
test('summed density equals individual contributions',max(abs(spd.y-np.where(ref<1e-5,0,ref)))<1e-8)
for key in ['10-random','11-specified']:
 x=read(b,key);test(key+' rank resolution',abs(x['global'][0]*40-round(x['global'][0]*40))<1e-10)
cand=read(b,'12-candidates');band=read(b,'13-band')
g=cand[cand.identifier=='gam Cru']
test('band and screened Gacrux agree',len(g)==1 and np.allclose(band.dec,[g['min.dec'].iloc[0],g['max.dec'].iloc[0]],atol=.005))
pos=read(b,'16-sketch').iloc[0]
test('dated sketch points into Skorba West above terrain',pos.left<pos.az<pos.right and pos.clearance>0)
r=read(b,'15-rise').iloc[0]
test('archived crossing agrees in date/time',r['date']==read(old,'15-rise').iloc[0]['date'] and r['time']==read(old,'15-rise').iloc[0]['time'])
test('archived crossing bearing within 0.001 degree',abs(r.azimuth-read(old,'15-rise').iloc[0].azimuth)<.001)
test('archive to final sketch within 0.001 degree',np.max(abs(np.array([pos.az,pos.alt])-read(old,'16-sketch').loc[0,['az','alt']].to_numpy(dtype=float)))<.001)
swap=read(b,'17-swapped')
test('only swapped rows change',set(swap.loc[swap['shift']>1e-8,'site'])=={'Skorba West','Mnajdra South'})
at=read(b,'18-atmosphere').iloc[0]
test('stored refraction preserved',bool(at.stored_identical));test('fresh transform responds to refraction',at.mean_shift_deg>.01)
n=read(b,'19-north');test('north-wrap density integrates to one',abs(np.trapezoid(n.y,n.x)-1)<1e-8)
test('partial skyline rejects outside density', 'coverage' in read(b,'20-partial').status[0]);test('archived outside-sector result finite',read(old,'20-partial').status[0]=='finite')
for end in ['global','local']:
 x=pd.read_csv('cached-500-'+end+'.csv');y=pd.read_csv('replayed-500-'+end+'.csv')
 test('original 500 '+end+' reproduced',x.equals(y))
change=[]
for f in sorted(b.glob('*.csv')):
 x=pd.read_csv(old/f.name);y=pd.read_csv(f)
 equal=x.equals(y)
 if not equal and list(x.columns)==list(y.columns) and x.shape==y.shape:
  numeric=x.select_dtypes('number').columns.intersection(y.select_dtypes('number').columns)
  equal=all(np.allclose(x[c],y[c],rtol=0,atol=1e-9,equal_nan=True) if c in numeric else x[c].equals(y[c]) for c in x.columns)
 change.append((f.stem,len(x),len(y),equal))
pd.DataFrame(change,columns=['handoff','archived_rows','current_rows','equal_to_1e_9']).to_csv('comparison.csv',index=False)
q=pd.DataFrame(checks,columns=['case','pass']);q.to_csv('W02-checks.csv',index=False)
print(q[~q['pass']]);assert q['pass'].all()
