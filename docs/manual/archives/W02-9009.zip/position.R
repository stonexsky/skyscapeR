suppressPackageStartupMessages(library(skyscapeR));library(swephR)
folder<-paste0('run-',packageVersion("skyscapeR"))
x<-read.csv(file.path(folder,'16-sketch.csv'))
h<-malta_horizons[[match("Skorba West",malta_entrances$Name)]]
loc<-as.numeric(h$metadata$georef);swe_set_topo(loc[2],loc[1],loc[3])
options(digits=17)
rad<-pi/180
direct<-function(t){
 eq<-swe_fixstar2_ut(",gam Cru",t,34818L);stopifnot(eq$return>=0)
 ra<-eq$xx[1]*rad;dec<-eq$xx[2]*rad;phi<-loc[1]*rad
 H<-(15*swe_sidtime(t)+loc[2])*rad-ra
 a<-(atan2(-cos(dec)*sin(H),sin(dec)*cos(phi)-cos(dec)*cos(H)*sin(phi))/rad)%%360
 alt<-asin(sin(phi)*sin(dec)+cos(phi)*cos(dec)*cos(H))/rad
 apparent<-swe_refrac_extended(alt,loc[3],1013.25,15,.0065,0L)$return
 c(az=a,alt=apparent)
}
rs<-read.csv(file.path(folder,'15-rise.csv'))
jd<-time2jd(paste(rs$date,rs$time),"UTC","J")
record<-direct(jd+20/1440)
result<-data.frame(jd_difference_sec=(x$jd-(jd+20/1440))*86400,az_residual=x$az-record[1],alt_residual=x$alt-record[2])
write.csv(result,file.path(folder,'21-position-reference.csv'),row.names=FALSE)
stopifnot(abs(result$jd_difference_sec)<.001,abs(result$az_residual)<.001,abs(result$alt_residual)<.02)
