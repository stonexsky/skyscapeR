suppressPackageStartupMessages(library(skyscapeR))
if(nzchar(Sys.getenv("SKY_TEST_RSCRIPT")))parallel:::setDefaultClusterOptions(rscript=Sys.getenv("SKY_TEST_RSCRIPT"))
skyscapeR.vars(refraction=TRUE)
rows<-which(malta_entrances$Phase=="Ggantija")
d<-malta_entrances[rows,];h<-malta_horizons[rows]
width<-(d[["Az R"]]-d[["Az L"]])%%360
az<-az.pdf((d[["Az L"]]+width/2)%%360,width/2,pdf="uniform",name=d$Name,verbose=FALSE)
dec<-coordtrans(az,h,verbose=FALSE)
set.seed(42);fit<-randomTest(dec,az=az,hor=h,nsims=500,ncores=6,verbose=FALSE)
cached<-readRDS(system.file("extdata","ggantija-random-500.rds",package="skyscapeR"))
for(key in c("cached","replayed")){
 z<-if(key=="cached")cached else fit
 write.csv(z$metadata$local.pval,paste0(key,"-500-local.csv"),row.names=FALSE)
 write.csv(data.frame(B=z$metadata$nsims,p=z$metadata$global.pval),paste0(key,"-500-global.csv"),row.names=FALSE)
}
