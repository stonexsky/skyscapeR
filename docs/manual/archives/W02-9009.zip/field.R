suppressPackageStartupMessages(library(skyscapeR))
# The measurements are constructed controls. Solar bearing is shared with
# sunAz(), while direction arithmetic is independent of the reducer.
sites<-matrix(c(35.84,14.57,100,51.18,-1.83,105),ncol=3,byrow=TRUE)
bearing<-c(2.25,358.75);reference<-c(358.75,2.25)
tz<-c("Europe/Malta","Europe/London");time<-c("11:07:17","10:10:31");date<-"2026/02/20"
test<-reduct.theodolite(sites,az=bearing,az.sun=reference,date=date,time=time,tz=tz,alt=c(2,3))
s<-vapply(1:2,function(i)sunAz(sites[i,],paste("2026-02-20",time[i]),tz[i]),numeric(1))
expected<-(round(s,2)+bearing-reference)%%360
out<-data.frame(latitude=test$Latitude,expected_lat=sites[,1],longitude=test$Longitude,expected_lon=sites[,2],true=test$True.Azimuth,expected)
write.csv(out,paste0("field-",packageVersion("skyscapeR"),".csv"),row.names=FALSE)
if(as.character(packageVersion("skyscapeR"))=="2.0.9009")stopifnot(isTRUE(all.equal(test$True.Azimuth,expected)),all(test$Latitude==sites[,1]),all(test$Longitude==sites[,2]))
