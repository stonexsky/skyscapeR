source('common.R')
metrics<-list()
for(coord in c('az','dec')) for(family in c('normal','uniform')) {
 centres<-if(coord=='az') c(0,1,180,359) else c(-90,-89,0,89,90)
 for(mu in centres) for(dx in c(1,.1,.01,.005)) for(cut in c(1e-5,.02)){
   sigma<-2
   p<-if(coord=='az') az.pdf(mu,sigma,pdf=family,.res=dx,.cutoff=cut,verbose=FALSE) else dec.pdf(mu,sigma,pdf=family,.res=dx,.cutoff=cut,verbose=FALSE)
   g<-p$data[[1]]
   x<-if(coord=='az') seq(0,360-dx,by=dx) else seq(-90,90,by=dx)
   delta<-x-mu
   if(coord=='az')delta<-(delta+180)%%360-180
   y<-if(family=='normal') exp(-.5*(delta/sigma)^2)/(sqrt(2*pi)*sigma) else ifelse(abs(delta)<=sigma+1e-10,1/(2*sigma),0)
   y[y<cut]<-0
   obs<-numeric(length(x));idx<-round((g$x-x[1])/dx)+1;obs[idx]<-g$y
   label<-paste(coord,family,mu,dx,cut)
   check(paste('pointwise',label),max(abs(obs-y)),0,1e-10)
   # Raw moments about the specified centre, using signed shortest angles for azimuth.
   metrics[[length(metrics)+1]]<-data.frame(coord,family,mu,dx,cut,observed_mass=sum(obs)*dx,reference_mass=sum(y)*dx,observed_first=sum(obs*delta)*dx,reference_first=sum(y*delta)*dx,observed_second=sum(obs*delta^2)*dx,reference_second=sum(y*delta^2)*dx)
 }
}
write.csv(do.call(rbind,metrics),'D01-moments.csv',row.names=FALSE)
for (coord in c('az','dec')){
 pdf<-if(coord=='az') az.pdf(c(359,1),c(2,2),.res=.1,verbose=FALSE) else dec.pdf(c(-10,10),c(2,2),.res=.1,verbose=FALSE)
 bounds<-if(coord=='az') c(0,360) else c(-90,90)
 s<-spd(pdf,xrange=bounds,.res=.1);n<-spd(pdf,xrange=bounds,.res=.1,normalise=TRUE)
 x<-s$data$x;mu<-if(coord=='az') c(359,1) else c(-10,10)
 expected<-Reduce('+',lapply(mu,function(m){u<-x-m;if(coord=='az')u<-(u+180)%%360-180
 y<-exp(-.5*(u/2)^2)/(sqrt(2*pi)*2);ifelse(y>=pdf$metadata$param$.cutoff,y,0)}))
 check(paste(coord,'sum'),s$data$y,expected,1e-9)
 check(paste(coord,'normalised trapezoid'),sum(diff(x)*(head(n$data$y,-1)+tail(n$data$y,-1))/2),1,1e-10)
}
for(index in list(2L,c(2L,1L),c(2L,2L),integer())){
 d<-dec.pdf(c(-10,12),c(1,2),name=c('A','B'),verbose=FALSE);z<-subset(d,index)
 id<-paste(index,collapse=',')
 check(paste('dec centres subset',id),z$metadata$dec,d$metadata$dec[index])
 check(paste('curve order',id),z$data,d$data[index])
 check(paste('name order',id),z$metadata$name,d$metadata$name[index])
}
hdr_cases<-list(tie=list(x=0:4,y=c(1,3,1,3,1),mass=.3,target=c(1,3,1,3)),gap=list(x=c(0,1,4,5),y=c(2,3,3,2),mass=1,target=c(0,4,1,5)),single=list(x=0:2,y=c(1,5,1),mass=.5,target=c(1,1)),truncated=list(x=0:2,y=c(3,2,1),mass=.8,target=c(0,1)))
for(label in names(hdr_cases)){
 h<-hdr_cases[[label]];regions<-hpdi(data.frame(x=h$x,y=h$y),mass=h$mass)
 check(paste('HDR endpoints',label),as.numeric(regions),h$target)
 inside<-Reduce('|',lapply(seq_len(nrow(regions)),function(i) h$x>=regions[i,1]&h$x<=regions[i,2]))
 check(paste('HDR achieved mass',label),sum(h$y[inside])/sum(h$y)>=h$mass,TRUE)
}
# Continuous independent quadrature; cut the Gaussian at the selected density height.
for(dx in c(1,.1,.01)){
 d<-dec.pdf(0,2,.res=dx,.cutoff=.02,verbose=FALSE)$data[[1]]
 edge<-2*sqrt(-2*log(.02*sqrt(2*pi)*2))
 mass<-integrate(function(x) exp(-.5*(x/2)^2)/(sqrt(2*pi)*2),-edge,edge)$value
 check(paste('quadrature cutoff mass',dx),sum(d$y)*dx,mass,2*dx*.03)
}
for(family in c('normal','uniform')){
 width<-100; mu<-0; dx<-1
 a<-az.pdf(mu,width,pdf=family,.res=dx,.cutoff=0,verbose=FALSE)$data[[1]]
 reference<-Reduce('+',lapply(-4:4,function(k){
  delta<-a$x+360*k-mu
  if(family=='uniform') ifelse(abs(delta)<=width,1/(2*width),0) else exp(-.5*(delta/width)^2)/(sqrt(2*pi)*width)
 }))
 check(paste('wide periodic',family),max(abs(a$y-reference)),0,1e-10)
}
save_results('D01-results.csv')
