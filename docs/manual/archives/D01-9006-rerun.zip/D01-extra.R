source('common.R')
for(width in c(100,360,720,1e6)){
  p<-az.pdf(359,width,.res=.5,.cutoff=0,verbose=FALSE)
  d<-p$data[[1]];turns<-if(width>1000) 0 else ceiling(10*width/360)+2
  expected<-if(width>1000)rep(1/360,nrow(d)) else Reduce('+',lapply(-turns:turns,function(k) stats::dnorm(d$x-359+360*k,0,width)))
  check(paste('periodic Gaussian',width),max(abs(expected-d$y)),0,1e-12)
  sp<-spd(p,xrange=c(0,360),.res=.25)$data
  check(paste('SPD closes',width),sp$y[1],tail(sp$y,1),1e-12)
  check(paste('interpolated last half-bin',width),sp$y[nrow(sp)-1],mean(c(tail(d$y,1),d$y[1])),1e-12)
}
p<-az.pdf(c(-1,359,719),100,pdf='uniform',.res=.1,verbose=FALSE)
check('centre invariant after a turn',p$data[[1]]$y,p$data[[3]]$y,1e-12)
save_results('D01-extra-results.csv')
