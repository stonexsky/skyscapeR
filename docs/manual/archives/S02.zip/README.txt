Run Rscript model.R, Rscript transformed.R, then python3 calibrate.py. aspect.csv and wind-weights.csv store the weights used for the landscape examples.
Run with skyscapeR 2.0.9016. Run commands in the extracted directory.
