library(skyscapeR)
skyscapeR.vars(dec="geo",timezone="UTC",calendar="G")
