from pathlib import Path
import pandas as pd
import astronomy as A
import zipfile
b=Path(__file__).parent
e=pd.read_csv(b/'events.csv')
case=e.query("lat==0 and year==1913 and mode=='autumn' and b=='Moon'").iloc[0]
pd.DataFrame([{'jd':case.jd,'package_fraction':float((b/'phase.txt').read_text()),'reference_fraction':A.Illumination(A.Body.Moon,A.Time(case.jd-2451545)).phase_fraction}]).to_csv(b/'phase.csv',index=False)
with zipfile.ZipFile('manual/archives/crossover-validation-record.zip') as z:
    table=pd.read_csv(z.open('crossover-validation/original-modern.csv'))
e['series']=e['mode'].map({'spring':'SFMSet','autumn':'AFMSet','SIM1':'SFC','SIM2':'SFC'})
joined=e.merge(table,on=['lat','series','year'])
joined['original']=joined.sun_original.where(joined.b=='Sun',joined.moon_original)
joined['residual']=joined.dec-joined.original
joined.to_csv(b/'archival-comparison.csv',index=False)
