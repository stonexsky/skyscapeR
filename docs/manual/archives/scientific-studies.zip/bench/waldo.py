from scipy.optimize import brentq
from pathlib import Path
import astronomy as A
import csv
site=A.Observer(39+7/60+24/3600,-(98+47/60+55/3600),0)
base=A.Time.Make(1944,10,13,0,0,0)
with (Path(__file__).parent/'waldo-input.csv').open('w') as f:
    w=csv.writer(f); w.writerow(['mean_SE','apparent_hour','UTC'])
    for angle,minute in [(55+51/60,40),(55+18/60,45),(54+40/60+30/3600,50)]:
        def hour(utc):
            t=base.AddDays(utc/24)
            return (A.SiderealTime(t)+site.longitude/15-A.Equator(A.Body.Sun,t,site,True,True).ra+12)%24
        target=8+minute/60
        ut=brentq(lambda u:hour(u)-target,14,17)
        w.writerow([angle,target,str(base.AddDays(ut/24))[11:19]])
