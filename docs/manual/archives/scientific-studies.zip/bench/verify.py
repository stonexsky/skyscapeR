from pathlib import Path
import pandas as pd
import numpy as np
p=Path(__file__).parent
def read(name): return pd.read_csv(p/(name+'.csv'))
t=read('terrain')
assert len(t)==8 and t['max'][0]<.005 and t['max'][6]>.5
c=read('curvature')
assert len(c)==2 and max(abs(c.result-c.expected))<1e-8
g=read('gradient'); assert len(g)==2 and (g.result-g.expected).abs().max()<2e-9
w=read('waldo')
assert len(w)==3 and abs(w.error.mean()-.07950)<.001
f=read('field'); assert len(f)==3 and f.solar_error.abs().max()<.00036 and f.compass_error.abs().max()<1e-10
m=read('magnetic'); assert len(m)==25 and m.error.abs().max()<.00007
d=read('photo'); assert len(d)==8 and d.az_error.abs().max()<.25 and d.alt_error.abs().max()<20/360
d=read('lunar'); assert len(d)==4 and (d.model-d.reference).abs().max()<.019
d=read('planets'); assert len(d)==10 and (d.package-d.reference_continuous).abs().max()<.0025
d=read('crossovers'); assert len(d)==64
failed=d.loc[d.package_date!=d.independent_date]
assert len(failed)==2 and set(zip(failed.latitude,failed.year,failed['mode']))=={(0,1913,'autumn')}
assert d.az_error.abs().max()<.0021 and d.dec_error.abs().max()<.00045
print('All recorded scientific results reproduced, including the 1913 disagreement.')
