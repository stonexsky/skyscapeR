source("bench/load.R")
v <- read.csv("bench/waldo-input.csv")
# The deflection is east of the southward prolongation of the line to the post.
base <- 10.123456
v$bearing <- reduct.theodolite(c(39+7/60+24/3600,-(98+47/60+55/3600),0),az=rep(base,3),date="1944/10/13",time=v$UTC,tz="UTC",az.sun=base+180-v$mean_SE)$True.Azimuth
v$polaris <- (67+95)/3600
v$error <- (v$bearing-v$polaris+180)%%360-180
write.csv(v,"bench/waldo.csv",row.names=FALSE)
