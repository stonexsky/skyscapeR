source("bench/load.R")
v <- read.csv("bench/igrf-reference.csv")
v$model <- mag.dec(as.matrix(v[c("lat","lon")]),v$date)
v$error <- (v$model-v$reference+180)%%360-180
write.csv(v,"bench/magnetic.csv",row.names=FALSE)
