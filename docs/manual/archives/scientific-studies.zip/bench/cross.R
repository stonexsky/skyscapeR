source("bench/load.R")
rows <- list()
for (lat in c(0,40,60,-60)) for(year in c(1913,2022)) for(mode in c("spring","autumn","SIM1","SIM2")) {
 loc <- c(lat,0,400)
 x <- if(mode %in% c("spring","autumn")) EFM(year,loc,season=mode,rise=FALSE) else CC(year,loc,season="summer",crescent="first",simulation=mode)
 for (b in c("Moon","Sun")) {
 v <- x[[b]]
 jd <- if("jd" %in% names(v)) v$jd else time2jd(paste(v$date,v$time),timezone="UTC")
 rows[[length(rows)+1L]] <- data.frame(lat,year,mode,b,jd,az=v$azimuth,dec=v$declination)
 }
}
write.csv(do.call(rbind,rows),"bench/events.csv",row.names=FALSE)
tab <- do.call(rbind,rows)
case <- subset(tab,lat==0 & year==1913 & mode=="autumn" & b=="Moon")
# EFM prints a whole-second clock, so recover the unrounded centre crossing.
day <- floor(case$jd+.5)-.5
instant <- skyscapeR:::.cc_event(day,1L,1,c(0,0,400),c(0,0,400),TRUE,1013.25,15)
writeLines(sprintf("%.10f",moonphase(instant)),"bench/phase.txt")
