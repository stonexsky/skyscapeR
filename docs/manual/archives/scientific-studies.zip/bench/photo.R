source("bench/load.R")
w <- 1440; h <- 360; dx <- 360/w; dy <- 20/h
x <- seq_len(w)-.5
a <- (x*dx+2)*pi/180
sky <- 2 + 2*sin(3*a)+.5*cos(7*a)
# Rotate each camera-frame horizon vector about the east axis, using a rigid 3-D rotation.
rotate <- function(az,el){
 t <- 1.2*pi/180; e <- el*pi/180
 east <- cos(e)*sin(az); north <- cos(e)*cos(az); up <- sin(e)
 data.frame(az=(atan2(east,north*cos(t)-up*sin(t))*180/pi)%%360,
            alt=asin(north*sin(t)+up*cos(t))*180/pi)
}
truth <- rotate(a,sky)
edge <- round((10-sky)/dy)
img <- array(0,c(h,w,4)); img[,,4] <- outer(seq_len(h),edge,">")
file <- tempfile(fileext=".png"); png::writePNG(img,file)
controls <- seq(1,w,by=180)
ctl <- data.frame(x=x[controls],y=edge[controls],az=truth$az[controls],alt=truth$alt[controls])
p <- importPanorama(file,c(51,0,0),alt.lim=c(-10,10),points=ctl)
test <- seq(91,w,by=180)
predaz <- (x[test]*dx+p$metadata$image$azimuth[1])%%360
predalt <- approx(p$data$az,p$data$alt,predaz)$y
write.csv(data.frame(x=x[test],az=truth$az[test],alt=truth$alt[test],az_error=(predaz-truth$az[test]+180)%%360-180,alt_error=predalt-truth$alt[test]),"bench/photo.csv",row.names=FALSE)
unlink(c(file,p$metadata$image$path))
