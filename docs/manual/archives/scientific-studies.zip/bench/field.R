source("bench/load.R")
s <- read.csv("bench/sights.csv"); site <- as.matrix(s[c("lat","lon","elev")])
delta <- function(a,b) (a-b+180)%%360-180
compass <- reduct.compass(site,s$magnetic,magdec=s$D)
solar <- reduct.theodolite(site,s$rt,gsub("-","/",substr(s$stamp,1,10)),substr(s$stamp,12,19),"UTC",az.sun=s$rs)
write.csv(data.frame(s,compass=compass$True.Azimuth,solar=solar$True.Azimuth,compass_error=delta(compass$True.Azimuth,s$target),solar_error=delta(solar$True.Azimuth,s$target)),"bench/field.csv",row.names=FALSE)
