source("bench/load.R")
write.csv(data.frame(year=c(2015,2015,2025,2025),limit=c("north minor","south minor","north major","south major"),model=c(nmnLX(2015),smnLX(2015),nMjLX(2025),sMjLX(2025)),reference=c(18.140,-18.134,28.710,-28.719)),"bench/lunar.csv",row.names=FALSE)
for (planet in c("Venus","Mercury","Mars","Jupiter","Saturn")) {
 v <- planet.extremes(planet,2025)
 write.csv(data.frame(planet,lo=round(2025-skyscapeR:::period(planet)*.75),hi=round(2025+skyscapeR:::period(planet)*.75),min=v$min.dec,max=v$max.dec),paste0("bench/",planet,".csv"),row.names=FALSE)
}
