from pathlib import Path
import math
import pandas as pd
import numpy as np
from scipy.optimize import minimize_scalar
import astronomy as A
from functools import lru_cache
B=Path(__file__).parent
def geo(body,t):
    return A.EquatorFromVector(A.RotateVector(A.Rotation_EQJ_EQD(t),A.GeoVector(body,t,True))).dec
def horizontal(body,t,obs,ref=A.Refraction.Airless):
    eq=A.Equator(body,t,obs,True,True)
    return A.Horizon(t,obs,eq.ra,eq.dec,ref)
def date(t):
    return str(t)[:10]
out=[]
for p in ['Mercury','Venus','Mars','Jupiter','Saturn']:
    s=pd.read_csv(B/(p+'.csv')).iloc[0]
    body=A.Body[p]
    start=A.Time.Make(int(s.lo),1,1,12,0,0).ut
    end=A.Time.Make(int(s.hi),1,1,12,0,0).ut
    days=np.arange(start,end+1)
    dec=np.array([geo(body,A.Time(d)) for d in days])
    for sign,key in [(1,'min'),(-1,'max')]:
        vals=sign*dec
        candidates=np.where((vals[1:-1]<=vals[:-2])&(vals[1:-1]<=vals[2:]))[0]+1
        opt=min([vals[0],vals[-1]]+[minimize_scalar(lambda d:sign*geo(body,A.Time(d)),bounds=(days[i]-1,days[i]+1),method='bounded',options={'xatol':.00001}).fun for i in candidates])
        out.append([p,key,s[key],sign*min(vals),sign*opt])
pd.DataFrame(out,columns=['planet','limit','package','reference_noon','reference_continuous']).to_csv(B/'planets.csv',index=False)
events=pd.read_csv(B/'events.csv')
def midnight(t):
    return math.floor(t.ut+.5)-.5
def pick(lat,yr,mode):
    obs=A.Observer(lat,0,400)
    seasons=A.Seasons(yr)
    @lru_cache(None)
    def setting(body,day):
        return A.SearchAltitude(body,obs,A.Direction.Set,A.Time(day),1.0,-.56)
    def az(body,t): return horizontal(body,t,obs).azimuth
    if mode in ('spring','autumn'):
        eq=seasons.mar_equinox if mode=='spring' else seasons.sep_equinox
        for i in range(-61,66):
            day=midnight(eq)+i
            m=setting(A.Body.Moon,day)
            if m is None or not eq.ut-60<=m.ut<=eq.ut+65 or A.Illumination(A.Body.Moon,m).phase_fraction<.99: continue
            suns=[s for d in (day-1,day) if (s:=setting(A.Body.Sun,d)) and s.ut<m.ut]
            if not suns: continue
            s=max(suns,key=lambda t:t.ut)
            if (az(A.Body.Moon,m)-az(A.Body.Sun,s))*(1 if mode=='autumn' else -1)>0: return m,s
    else:
        sol=seasons.jun_solstice
        ns=[]; t=sol.AddDays(-180)
        while t.ut<sol.ut+150:
            t=A.SearchMoonPhase(0,t,32); ns.append(t); t=t.AddDays(2)
        start=[t for t in ns if t.ut<=sol.ut][-3]
        for n in ns:
            if n.ut<start.ut: continue
            first=None
            for i in range(9):
                if first is not None and (mode=='SIM1' or i>first+1): break
                s=setting(A.Body.Sun,midnight(n)+i)
                if s is None or s.ut<=n.ut: continue
                eq=A.Equator(A.Body.Moon,s,obs,True,True)
                lower=horizontal(A.Body.Moon,s,obs,A.Refraction.Normal).altitude-math.degrees(math.asin(1737.4/(eq.dist*149597870.7)))
                elong=A.AngleBetween(A.GeoVector(A.Body.Moon,s,True),A.GeoVector(A.Body.Sun,s,True))
                if lower<=0 or elong>=90 or lower+elong/3<11.3: continue
                m=A.SearchAltitude(A.Body.Moon,obs,A.Direction.Set,s,.5,-.56)
                if m is None: continue
                if first is None:first=i
                if (az(A.Body.Moon,m)-az(A.Body.Sun,s)+180)%360-180<0: return m,s
    return None,None
out=[]
for (lat,year,mode),group in events.groupby(['lat','year','mode']):
    obs=A.Observer(lat,0,400)
    for body,selected in zip(['Moon','Sun'],pick(int(lat),int(year),mode)):
        row=group[group.b==body].iloc[0]
        t=A.Time(row.jd-2451545.0); b=A.Body[body]
        out.append([lat,year,mode,body,date(t),date(selected) if selected else None,
                    (selected.ut-t.ut)*1440 if selected else None,
                    (row.az-horizontal(b,t,obs).azimuth+180)%360-180,row.dec-geo(b,t)])
pd.DataFrame(out,columns=['latitude','year','mode','body','package_date','independent_date','minutes','az_error','dec_error']).to_csv(B/'crossovers.csv',index=False)
