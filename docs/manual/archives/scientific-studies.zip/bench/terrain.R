source("bench/load.R")
library(terra)
cr <- "+proj=aeqd +lat_0=51 +lon_0=0 +datum=WGS84 +units=m"
build <- function(cell,flat=FALSE) {
 n <- 2*ceiling(2200/cell)+1L
 dem <- rast(nrow=n,ncol=n,xmin=-n*cell/2,xmax=n*cell/2,ymin=-n*cell/2,ymax=n*cell/2,crs=cr)
 xy <- xyFromCell(dem,seq_len(ncell(dem)))
 r <- sqrt(rowSums(xy^2)); a <- atan2(xy[,1],xy[,2])
 values(dem) <- if(flat) rep(0,length(r)) else r*(.12+.05*cos(6*a)-((r-1167)/2500)^2)
 dem
}
study <- data.frame(cell=c(10,25,50,10,10,10,10,10),radial=c(10,10,10,50,250,10,10,10),az=c(1,1,1,1,1,5,15,1),range=c(rep(2000,7),900))
a <- seq(0,359.75,.25)
for(i in seq_len(nrow(study))){
 s <- study[i,]
 p <- createHor(loc=c(51,0,0),dem=build(s$cell),max.distance=s$range,eye.height=0,az.step=s$az,distance.step=s$radial,curvature=FALSE,panorama=FALSE,ncores=1,verbose=FALSE)
 expected <- atan(.12+.05*cos(6*a*pi/180)-((min(1167,s$range)-1167)/2500)^2)*180/pi
 err <- approx(p$data$az,p$data$alt,a)$y-expected
 study$rmse[i] <- sqrt(mean(err^2)); study$max[i] <- max(abs(err)); study$peak[i] <- max(p$data$alt)
}
write.csv(study,"bench/terrain.csv",row.names=FALSE)
# On a sphere the line of sight tangent to level terrain has dip acos(R/(R+h)).
dip <- do.call(rbind,lapply(c(0,.13),function(k){
 r <- 6371008.8/(1-k); h <- .12
 p <- createHor(loc=c(51,0,0),dem=build(40,TRUE),eye.height=h,max.distance=2000,distance.step=5,az.step=15,curvature=TRUE,refraction.k=k,panorama=FALSE,ncores=1,verbose=FALSE)
 data.frame(k,expected=-acos(r/(r+h))*180/pi,result=p$data$alt[1])
}))
write.csv(dip,"bench/curvature.csv",row.names=FALSE)
# The small-angle tangent on level ground under a constant vertical gradient has
# slope -sqrt(2 h (1-2c)/R). Test the default path, plus a different gradient.
gradients <- c(-10,0)
patat <- do.call(rbind,lapply(gradients,function(g){
 lat <- 51*pi/180; h <- .12
 radius <- 1/sqrt((sin(lat)/6356752.314245)^2+(cos(lat)/6378137)^2)
 coeff <- .252*1013.25*(34.2+g)/(15+273.15)^2
 expected <- -sqrt(2*h*(1-2*coeff)/radius)*180/pi
 p <- createHor(loc=c(51,0,0),dem=build(40,TRUE),eye.height=h,max.distance=2000,distance.step=5,az.step=15,curvature=TRUE,atm=1013.25,temp=15,tempgrad=g,panorama=FALSE,ncores=1,verbose=FALSE)
 data.frame(gradient=g,expected,result=p$data$alt[1])
}))
write.csv(patat,"bench/gradient.csv",row.names=FALSE)
