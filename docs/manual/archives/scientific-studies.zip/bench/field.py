from pathlib import Path
import pandas as pd
import subprocess
import astronomy as A
sites=[(39.742476,-105.1786,1830.14,'2003-10-17T19:30:30Z',39.751,-105.1788,8.6),
       (35.84,14.57,100,'2026-02-20T10:07:17Z',35.847,14.569,-2.5),
       (-23,-67,2400,'2025-06-03T14:18:20Z',-23.004,-66.999,3.9)]
rows=[]
for lat,lon,elev,stamp,tlat,tlon,d in sites:
    t=A.Time.Parse(stamp); o=A.Observer(lat,lon,elev)
    e=A.Equator(A.Body.Sun,t,o,True,True)
    sun=A.Horizon(t,o,e.ra,e.dec,A.Refraction.Airless).azimuth
    if stamp.startswith('2003'): sun=194.34024 # Reda & Andreas, NREL/TP-560-34302, Appendix A
    target=float(subprocess.check_output(['/usr/bin/python3','-c',f"from pyproj import Geod; print(Geod(ellps='WGS84').inv({lon},{lat},{tlon},{tlat})[0])"]))%360
    r_s=358.75
    rows.append([lat,lon,elev,stamp,target,d,(target-d)%360,r_s,(r_s+target-sun)%360,sun])
pd.DataFrame(rows,columns=['lat','lon','elev','stamp','target','D','magnetic','rs','rt','sun']).to_csv(Path(__file__).parent/'sights.csv',index=False)
