Scientific validation of skyscapeR 2.0.9016
Run from a directory containing this bench/ folder. Install the package, R dependencies
terra, png, oce, swephR, and Swiss planetary and lunar files covering 1800-2399.
Python requires numpy, pandas, scipy and pyproj. field.py uses /usr/bin/python3 for pyproj.
The included Astronomy Engine and ppigrf modules preserve the independent numerical
references used. Input IGRF14.shc is the IAGA coefficient file distributed with ppigrf.
Run python bench/field.py, python bench/waldo.py and python bench/magnet.py first.
Run the R scripts terrain.R, photo.R, field.R, waldo.R, magnet.R, limits.R and cross.R
from the parent directory, then python bench/reference.py. The CSVs contain the inputs,
returned quantities and signed discrepancies. Tolerances apply to the examples only.
H03 uses analytic terrain in a local azimuthal equidistant CRS; H05 uses a synthetic
rigidly tilted camera. F01 uses three synthetic baselines and a separate archival
survey. A06 uses Fred Espenak's published extrema (monthly lunar standstills);
A07 compares centre settings with an independent -0.56 degree geometric threshold.
Sources:
https://github.com/cosinekitty/astronomy
https://github.com/IAGA-VMOD/ppigrf
https://astropixels.com/ephemeris/moon/lunarstandstill2001.html
https://archive.org/details/examplesofgoodpr00unit (printed pages 41, 62-63)
https://doi.org/10.1016/j.solener.2003.12.003
For the archival contrast, place the manual's crossover-validation-record.zip in
manual/archives/ and run python bench/historical.py after the R crossover run.
Run python bench/verify.py to reproduce the reported bounds and the exceptional date.
