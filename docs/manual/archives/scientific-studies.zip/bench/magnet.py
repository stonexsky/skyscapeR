from pathlib import Path
from datetime import datetime
import pandas as pd
import numpy as np
import ppigrf
B=Path(__file__).parent
sites=[(v,w) for v,w in [(35.84,14.57),(-23,-67),(55,-5),(0,115),(70,25)]]
rows=[]
for epoch in [datetime(1900,1,1),datetime(1950,7,1),datetime(2000,2,29),datetime(2025,1,1),datetime(2029,7,1)]:
    for lat,lon in sites:
        e,n,u=ppigrf.igrf(lon,lat,0,epoch,coeff_fn=str(B/'IGRF14.shc'))
        rows.append([lat,lon,epoch.strftime('%Y/%m/%d'),np.degrees(np.arctan2(e,n)).item()])
pd.DataFrame(rows,columns=['lat','lon','date','reference']).to_csv(B/'igrf-reference.csv',index=False)
