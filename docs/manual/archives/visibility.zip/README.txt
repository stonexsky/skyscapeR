Run Rscript phases.R, Rscript scan.R, Rscript refine.R, then python3 export.py. Uses the package fixed-star catalogue and Swiss planetary/lunar files for each epoch. On Windows use one core for mclapply.
Current package run: skyscapeR 2.0.9015, revision fec1c516e8cf9b8caa0bb560fe797dc1c7847b18. Run commands in the extracted directory.
