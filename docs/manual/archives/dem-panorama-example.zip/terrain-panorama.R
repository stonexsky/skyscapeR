library(skyscapeR)
library(terra)

# Synthetic terrain in metres, with a foreground rise and a higher ridge.
dem <- rast(xmin=499450, xmax=500550, ymin=5699450, ymax=5700550,
            resolution=5, crs="EPSG:32630")
xy <- xyFromCell(dem, seq_len(ncell(dem)))
east <- xy[, 1] - 500000
north <- xy[, 2] - 5700000
values(dem) <- 100 + 15 * exp(-((east-80)/35)^2 - ((north+30)/90)^2) +
    88 * exp(-((east-270)/70)^2 - ((north-40)/200)^2)
h <- createHor(dem=dem, loc=c(500000, 5700000), loc.crs="EPSG:32630",
               name="Two ridges", eye.height=1.6, max.distance=500,
               az.step=1, distance.step=2.5, panorama=TRUE, width=1024,
               image.dir="terrain-images", ncores=1)
stopifnot(file.exists(h$metadata$image$path))
print(h$metadata$image[c("path", "width", "height", "projection", "sampling")])
saveRDS(h, "two-ridges.rds")
# Open the eastern sector of the generated terrain.
png("terrain-east.png", width=1100, height=390)
plot(h, xrange=c(35,145), yrange=c(-3,21), use.image=TRUE)
dev.off()
