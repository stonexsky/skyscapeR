from itertools import product
import csv
from pathlib import Path
# Integer Julian day number from a March-based civil year, independent of Swiss.
def jd(y,m,d,cal):
 a=(14-m)//12;Y=y+4800-a;M=m+12*a-3
 n=d+(153*M+2)//5+365*Y+Y//4
 return n-Y//100+Y//400-32045 if cal=='G' else n-32083
assert jd(2000,1,1,'G')==2451545 and jd(1970,1,1,'G')==2440588
assert jd(-4712,1,1,'J')==0 and jd(1582,10,15,'G')==2299161
rows=[]
for (y,m,d),cal,(h,mi,sec),off in product([(-4712,1,1),(-3499,6,21),(-1,12,31),(0,2,29),(1,1,1),(1582,10,4),(1582,10,15),(1900,3,1),(2000,2,29),(2024,12,31)],'GJ',[(0,0,0),(11,59,59),(12,0,0),(23,59,59)],[-3.5,0,5.75]):
 s=f'{y}/{m:02}/{d:02} {h:02}:{mi:02}:{sec:02}'
 rows.append([s,cal,off,jd(y,m,d,cal)-.5+(h*3600+mi*60+sec-off*3600)/86400])
with open('calendar.csv','w') as f:
 w=csv.writer(f);w.writerow(['civil','calendar','offset','jd']);w.writerows(rows)
