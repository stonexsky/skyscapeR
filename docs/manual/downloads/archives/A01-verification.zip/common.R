if(nzchar(Sys.getenv("TRIO_LIB"))) .libPaths(c(Sys.getenv("TRIO_LIB"),.libPaths()))
suppressPackageStartupMessages(library(skyscapeR))
stopifnot(as.character(packageVersion("skyscapeR"))=="2.0.9005")
results <- list()
check <- function(label,actual,expected,tol=0) {
  numeric_pair <- is.numeric(actual) && is.numeric(expected)
  error <- if(numeric_pair && length(actual)==length(expected) && length(actual)) max(abs(as.vector(actual)-as.vector(expected))) else NA_real_
  pass <- if(numeric_pair && length(actual)==length(expected) && length(actual)) isTRUE(error<=tol) else identical(as.character(actual),as.character(expected))
  format_value <- function(x) paste(head(x,8),collapse=" | ")
  results[[length(results)+1L]] <<- data.frame(label,pass,error,tol,actual=format_value(actual),expected=format_value(expected))
}
save_results <- function(name) write.csv(do.call(rbind,results),name,row.names=FALSE)
