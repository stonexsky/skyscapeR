# S03, corrected 2.0.9006

Install the archived package (SHA-256 0a97b65385bb253b75b287f160b6e79da63a0ddae29b6be31c5ad6902c6cd6d2), then run from the extracted directory. TRIO_LIB optionally specifies an installed R library. Python S03 requires numpy and pandas.

Rscript S03.R
Rscript S03-extra.R
python historical.py

Each results table records expected and returned values. D01 retains the same original 173 assertions. S03 validates declination and noncircular fixtures on a line and full azimuth grids on a circle. baseline/ contains the two original 2.0.9005 public simulation matrices for fixed-input replay. The original 2.0.9005 run is separately archived in the manual.
