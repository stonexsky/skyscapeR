"""Independent rank and cluster oracle; a full turn has one north direction."""
import numpy as np,pandas as pd
from pathlib import Path
from itertools import groupby
rows=[];history=[]
def segments(v,x,wrap):
    groups=[list(g) for _,g in groupby(np.flatnonzero(v>0),key=lambda i,c=iter(range(len(v))):i-next(c))]
    if wrap and len(groups)>1 and groups[0][0]==0 and groups[-1][-1]==len(x)-1:
        groups=[groups[-1]+groups[0]]+groups[1:-1]
    return [g for g in groups if len(g)>1 and (x[g[-1]]-x[g[0]])%360>=.5-1e-10]
def ref(M,x,conf,tails,wrap):
    matrix=M[:, :-1] if wrap and x[-1]==360 and x[0]==0 else M
    x=x[:matrix.shape[1]]
    sd=matrix.std(axis=0,ddof=1);live=matrix.max(axis=0)>matrix.min(axis=0)
    sd[~live]=1
    upper=np.quantile(matrix,1-(1-conf)/tails,axis=0)
    positive=np.maximum(matrix-upper,0)/sd;positive[:,~live]=0
    negative=np.zeros_like(positive)
    if tails==2:
        negative=np.maximum(np.quantile(matrix,(1-conf)/tails,axis=0)-matrix,0)/sd
        negative[:,~live]=0
    total=(positive+negative).sum(axis=1)
    allruns=[];maxima=[]
    for up,down in zip(positive,negative):
        runs=[(sign,g,s[g].sum()) for sign,s in [('+',up),('-',down)] for g in segments(s,x,wrap)]
        allruns.append(runs);maxima.append(max([0]+[a[2] for a in runs]))
    loc=[(sign,x[g[0]],x[g[-1]],sum(np.asarray(maxima)>=score-1e-12)/len(M)) for sign,g,score in allruns[0]]
    return sum(total>=total[0]-1e-12)/len(M),loc
for f in sorted(Path('scores').glob('*-curves.csv')):
    key=f.name.split('-curves')[0];d=pd.read_csv(f);x=d.iloc[:,0].values;M=d.iloc[:,1:].values.T
    params=pd.read_csv(f.with_name(key+'-global.csv')).iloc[0];actual=pd.read_csv(f.with_name(key+'-local.csv'))
    for space in (['circular'] if 'seam' in key or key in ['model','random','fixed-random','fixed-model'] else ['linear']):
        gp,loc=ref(M,x,params.conf,int(params.tails),space=='circular')
        got=list(actual.itertuples(index=False,name=None))
        equal=len(got)==len(loc) and all(a[0]==b[0] and np.allclose(a[1:],b[1:],atol=1e-11,rtol=0) for a,b in zip(got,loc))
        rows.append(dict(case=key,space=space,global_actual=params['global'],global_ref=gp,local_actual=str(got),local_ref=str(loc),global_pass=abs(params['global']-gp)<1e-11,local_pass=equal))
    if key.startswith('isolated'):
        history.append(dict(case=key,b=round(params['global']*len(M)-1),B=len(M)-1,current=params['global'],legacy_tail_on_same_ranks=round(params['global']*len(M)-1)/len(M)))
pd.DataFrame(rows).to_csv('S03-score-results.csv',index=False);pd.DataFrame(history).to_csv('S03-rank-history.csv',index=False)
