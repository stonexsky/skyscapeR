source('common.R')
for(key in c("random","model")){
 d<-read.csv(paste0("baseline/",key,"-curves.csv"))
 x<-d[[1]];obs<-data.frame(x,y=d[[2]]);sim<-t(as.matrix(d[-c(1,2)]))
 run<-function(obs,sim,files=character()) skyscapeR:::.simulation_inference(obs,nrow(sim),list(seq_len(nrow(sim))),files,if(length(files)) NULL else sim,.8,2,circular=TRUE)
 f<-run(obs,sim)
 out<-paste0('scores/fixed-',key)
 file.copy(paste0('baseline/',key,'-curves.csv'),paste0(out,'-curves.csv'),overwrite=TRUE)
 write.csv(f$local,paste0(out,'-local.csv'),row.names=FALSE)
 write.csv(data.frame(global=f$global,tails=2,conf=.8),paste0(out,'-global.csv'),row.names=FALSE)
 # Move the origin without changing the curves; a closing copy is assigned after rotation.
 unique_points<-seq_len(length(x)-1)
 for(shift in c(1L,180L)){
  ordered<-c(tail(unique_points,-shift),head(unique_points,shift))
  ordered<-c(ordered,ordered[1])
  g<-run(data.frame(x,y=obs$y[ordered]),sim[,ordered])
  check(paste(key,'rotation global',shift),g$global,f$global)
  check(paste(key,'rotation local',shift),sort(g$local$p.value),sort(f$local$p.value))
 }
 path<-tempfile();writeBin(as.double(sim),path);disk<-run(obs,sim,path);unlink(path)
 check(paste(key,'disk global'),disk$global,f$global)
 check(paste(key,'disk local'),as.character(disk$local),as.character(f$local))
}
save_results('S03-extra-results.csv')
