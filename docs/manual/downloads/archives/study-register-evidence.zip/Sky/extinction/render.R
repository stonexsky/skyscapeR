source("scenes.R")
png("Milky-Way-horizon-extinction.png",width=1740,height=1030,res=145,type="cairo")
par(mfrow=c(2,2),oma=c(.1,.2,1.5,.1),mar=c(3,3.4,2.7,.65),mgp=c(1.8,.5,0),tcl=-.25)
for(i in 1:2){
 obj <- if(i==1)n else s
 x <- if(i==1)c(45,105) else c(205,265)
 yr <- c(-2,28)
 ref <- NULL
 for(k in c(0,.2)){
  view <- obj
  # Isolate the band's transfer; above-atmosphere classes, stellar fluxes and sky background are identical.
  view$light$k <- k
  f <- skyRadiance(view,x,yr,c(160,80))
  if(k==0) ref <- f else {
    tr <- skyscapeR:::.band_transmission(f$altitude,k)
    stopifnot(isTRUE(all.equal(as.vector(f$milky.way),as.vector(ref$milky.way*tr),tolerance=1e-12)),
              identical(ref$direct,f$direct))
  }
  plot.new();plot.window(x,yr,xaxs="i",yaxs="i")
  skyscapeR:::.draw_sketch_sky(view)
  if(i==1){
    u <- h$azimuth>=x[1] & h$azimuth<=x[2]
    a<-h$azimuth[u];b<-h$bank4[u];g<-pmin(b,h$existing[u])
    polygon(c(a,rev(a)),c(b,rep(-2,length(a))),col="#313D37",border=NA)
    polygon(c(a,rev(a)),c(b,rev(g)),col="#DADBD5",border=NA)
  }else rect(x[1],-2,x[2],0,col="#313D37",border=NA)
  axis(1,at=seq(x[1],x[2],10));axis(2,at=c(0,5,10,15,20,25),las=1)
  title(xlab="True azimuth (°)",ylab="Altitude (°)")
  mtext(if(i==1)"Northern Thornborough · 3500 BCE" else "30° S, 149° E · 21 June 2026, 14:00 UTC",3,line=1.45,cex=1.02)
  mtext(if(k==0)"No extinction of band light" else "Band extinction · 0.20 mag per airmass",3,line=.2,cex=.95)
 }
}
dev.off()
