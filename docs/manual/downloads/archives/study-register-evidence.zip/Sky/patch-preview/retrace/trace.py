"""Rebuild and review the outer envelope of the diffuse-light map in Galactic coordinates."""
import numpy as np
from PIL import Image
import pandas as pd
from scipy.ndimage import median_filter, gaussian_filter1d, map_coordinates, label, binary_fill_holes
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
G=np.array([[-.0548755604,-.8734370902,-.4838350155],[.4941094279,-.4448296300,.7469822445],[-.8676661490,-.1980763734,.4559837762]])
rgb=np.array(Image.open('source-map.png').convert('RGB'));h,w=rgb.shape[:2]
step=.25
lon=np.arange(-180,180,step);lat=np.arange(-60,60+step,step)
L,B=np.meshgrid(lon,lat)
def sky(l,b):
 l,b=np.deg2rad(l),np.deg2rad(b)
 xyz=np.stack([np.cos(l)*np.cos(b),np.sin(l)*np.cos(b),np.sin(b)],axis=-1)@G
 ra=np.arctan2(xyz[...,1],xyz[...,0]);dc=np.arcsin(np.clip(xyz[...,2],-1,1))
 return ((.5-ra/(2*np.pi))*w-.5)%w,(.5-dc/np.pi)*h-.5
x,y=sky(L,B)
def resample(im):
 return map_coordinates(np.pad(im.astype(float),((0,0),(1,1)),mode='wrap'),[y,x+1],order=1,mode='nearest')
tone=resample(rgb@np.array([.2126,.7152,.0722]))
# Approximate 1-degree spherical Gaussian with local longitude scaling.
sigma=1/2.35482/step
smoothed=np.vstack([gaussian_filter1d(r,sigma/np.cos(np.deg2rad(b)),mode='wrap') for b,r in zip(lat,tone)])
smoothed=gaussian_filter1d(smoothed,sigma,axis=0,mode='nearest')
def regional_level(rows,p):
 return median_filter(np.percentile(smoothed[rows],p,axis=0),size=21,mode='wrap') # 5-degree neighbourhood
background=regional_level((abs(lat)>=35)&(abs(lat)<=50),50)
bright=regional_level(abs(lat)<=12,90)
contrast=(smoothed-background)/(bright-background)
def envelope(fraction):
 # Select the main connected body, accounting for longitude wrap. Enclosed holes
 # are internal to the outer envelope; connected indentations remain.
 exceed=np.tile(contrast>=fraction,(1,3));labs,n=label(exceed,structure=np.ones((3,3)))
 central=labs[:,len(lon):2*len(lon)];ids,ct=np.unique(central[abs(lat)<12],return_counts=True)
 primary=ids[ids>0][np.argmax(ct[ids>0])]
 return binary_fill_holes(labs==primary)[:,len(lon):2*len(lon)]
levels=[.25,.35,.45];masks={f:envelope(f) for f in levels}
# Extract the outer paths as explicit vertices. Mask is periodic; keep seam endpoints.
paths={}
for f,mask in masks.items():
 fig,ax=plt.subplots()
 paths[f]=ax.contour(np.r_[lon,180],lat,np.c_[mask,mask[:,0]],levels=[.5]).allsegs[0]
 plt.close(fig)
 assert not (mask[0].any() or mask[-1].any())
pd.DataFrame([(f,i,j,l,b) for f,segments in paths.items() for i,seg in enumerate(segments) for j,(l,b) in enumerate(seg)],columns=['contrast_fraction','path','vertex','longitude','latitude']).to_csv('candidate-contours.csv',index=False)
old=pd.read_csv('previous-outline.csv')
oldpaths=[q[['longitude','latitude']].values for _,q in old.groupby('edge')]
for f,mask in masks.items():
 ix=np.argmin(abs(lon));print(f,'centre intervals',lat[np.flatnonzero(np.diff(mask[:,ix]))]+step/2)
def line(ax,segments,color,world=False,lw=1):
 for s in segments:
  if world:a,b=sky(s[:,0],s[:,1]);limit=w/2
  else:a,b=(s[:,0]+180)%360-180,s[:,1];limit=180
  for sel in np.split(np.arange(len(a)),1+np.flatnonzero(abs(np.diff(a))>limit)):
   ax.plot(a[sel],b[sel],c=color,lw=lw)
oldcolor='#ffc370';newcolor='#63eee2'
fig=plt.figure(figsize=(13,8.1));gs=fig.add_gridspec(2,6,left=.04,right=.985,bottom=.11,top=.86,hspace=.23,wspace=.2,height_ratios=[1.3,1])
for i,(segments,color,title) in enumerate([(oldpaths,oldcolor,'A   Previous outline'),(paths[.35],newcolor,'B   New outer envelope')]):
 ax=fig.add_subplot(gs[0,3*i:3*i+3]);ax.imshow(rgb,extent=(-.5,w-.5,h-.5,-.5));line(ax,segments,color,True,.85);ax.set(xlim=(0,w),ylim=(h,0));ax.axis('off');ax.set_title(title,loc='left',fontsize=13)
field=(abs(lat)<=23);columns=abs(lon)<=27
galrgb=np.uint8(np.clip(np.stack([resample(rgb[:,:,i])[field][:,columns] for i in range(3)],axis=-1),0,255))
extent=[lon[columns][0]-step/2,lon[columns][-1]+step/2,lat[field][0]-step/2,lat[field][-1]+step/2]
for i,title in enumerate(['C   Centre region · source only','D   Previous outline','E   New outer envelope']):
 ax=fig.add_subplot(gs[1,i*2:i*2+2]);ax.imshow(galrgb,origin='lower',extent=extent)
 if i:line(ax,oldpaths if i==1 else paths[.35],oldcolor if i==1 else newcolor,lw=1)
 ax.set(xlim=(27,-27),ylim=(-22,22),xticks=[20,0,-20],yticks=[-20,0,20]);ax.set_title(title,loc='left',fontsize=12);ax.set_xlabel('Galactic longitude (°)',fontsize=9)
 if i==0:ax.set_ylabel('Galactic latitude (°)',fontsize=9)
 ax.tick_params(labelsize=8)
fig.text(.04,.96,'A new trace of the Milky Way’s outer envelope',size=20)
fig.text(.04,.906,'The same source pixels underlie each comparison. The lower row enlarges the central field in Galactic coordinates.',size=11)
fig.text(.04,.038,'Candidate threshold: 35% of local band-to-background contrast after 1° smoothing. Source: NASA/Goddard SVS, ESA/Gaia/DPAC, Deep Star Maps 2020.',size=9)
fig.savefig('Milky-Way-outline-candidate.png',dpi=210,bbox_inches='tight',pad_inches=.15)
