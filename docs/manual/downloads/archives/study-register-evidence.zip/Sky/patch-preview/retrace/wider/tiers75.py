from pathlib import Path
exec(Path(__file__).with_name('bright.py').read_text().split('local_mean=')[0])
from matplotlib.patches import Patch
from matplotlib.colors import to_rgb
bright,_=filter_area(ordinary&(smoothed>=1.10*mean))
colors=np.round(255*np.array([to_rgb(c) for c in ['#111720','#879292','#304c65','#dd9e51','#fff3bf']])).astype(int)
cr=(abs(lat)<=18);cc=(abs(lon)<=25);cs=np.ix_(cr,cc)
center=np.uint8(np.clip(np.stack([resample(rgb[:,:,k])[cs] for k in range(3)],axis=-1),0,255))
ce=[lon[cc][0]-.125,lon[cc][-1]+.125,lat[cr][0]-.125,lat[cr][-1]+.125]
fig,axs=plt.subplots(4,3,figsize=(15,10.2),gridspec_kw={'width_ratios':[1.22,1.1,.77]})
fig.subplots_adjust(top=.84,bottom=.07,left=.025,right=.99,wspace=.045,hspace=.29)
fig.text(.025,.967,'Two brightness layers within the Milky Way',size=21)
fig.legend([Patch(facecolor=c/255) for c in colors[[2,1,3,4]]],['Dark cutout','Ordinary band','Bright · ≥10% above mean','Brightest · threshold varies by row'],loc='upper left',bbox_to_anchor=(.018,.947),ncol=4,frameon=False)
saved=dict(longitude=lon,latitude=lat,envelope=inside,dark=dark,bright=bright)
for i,excess in enumerate([None,.5,.75,1.]):
 a,b,c=axs[i]
 if i==0: world,zoom,centre=rgb,local,center;row='Source · whole sky'
 else:
  top,n=filter_area(bright&(smoothed>=(1+excess)*mean))
  assert not np.any(top&~bright)
  saved['upper_'+str(int(excess*100))]=top
  print(excess,n,round(100*weights[top].sum()/outerarea,2))
  cl=np.zeros(inside.shape,np.uint8);cl[inside]=1;cl[dark]=2;cl[bright]=3;cl[top]=4
  world=np.broadcast_to(colors[0],rgb.shape).astype(float).copy()
  for k in range(1,5):world+=project(cl==k)[:,:,None]*(colors[k]-colors[0])
  world=world.clip(0,255).astype('uint8');zoom=colors[cl[sl]];centre=colors[cl[cs]]
  row=f'Brightest · ≥{excess:.0%} above mean'
 a.imshow(world);a.axis('off');a.set_title(row,loc='left',size=11)
 for ax,z,extent in [(b,zoom,ext),(c,centre,ce)]:
  ax.imshow(z,origin='lower',extent=extent);ax.set_yticks([]);ax.tick_params(labelsize=7)
 b.set_xticks([-60,-45,-30,-15,0],['300°','315°','330°','345°','0°'])
 c.set_xticks([-20,0,20],['340°','0°','20°'])
 if i==0:
  b.set_title('Emu · Coalsack towards Sagittarius',loc='left',size=11);c.set_title('Galactic-centre region',loc='left',size=11)
  b.annotate('Coalsack',xy=(-57,-1),xytext=(-49,8),color='white',fontsize=8,arrowprops=dict(arrowstyle='->',color='white',lw=.8))
fig.text(.025,.018,'Thresholds use the same area-weighted mean map tone of the band after dark cutouts. Minimum patch area: 10 deg². Source: NASA/Goddard SVS, ESA/Gaia/DPAC.',fontsize=9)
fig.savefig(out/'Brightness-50-75-100.png',dpi=210,bbox_inches='tight',pad_inches=.12)
np.savez_compressed(out/'brightness-75-comparison.npz',**saved)
