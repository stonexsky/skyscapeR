from pathlib import Path
import numpy as np
from PIL import Image
from scipy.ndimage import map_coordinates,gaussian_filter1d
p=Path('../patch-preview/retrace')
D=np.load(p/'wider/brightness-75-comparison.npz')
lon,lat=D['longitude'],D['latitude']
l,b=np.meshgrid(np.deg2rad(lon),np.deg2rad(lat))
xyz=np.stack((np.cos(b)*np.cos(l),np.cos(b)*np.sin(l),np.sin(b)),axis=-1) @ np.array([[-.0548755604,-.8734370902,-.4838350155],[.4941094279,-.4448296300,.7469822445],[-.8676661490,-.1980763734,.4559837762]])
pix=np.array(Image.open(p/'source-map.png').convert('RGB')) @ np.array([.2126,.7152,.0722])
h,w=pix.shape
a=(.5-np.arctan2(xyz[:,:,1],xyz[:,:,0])/(2*np.pi))*w-.5
y=(.5-np.arcsin(xyz[:,:,2])/np.pi)*h-.5
src=map_coordinates(np.pad(pix,((0,0),(1,1)),mode='wrap'),[y,(a%w)+1],order=1)
src=np.stack([gaussian_filter1d(row,1/(2.35482*.25*np.cos(ba)),mode='wrap') for ba,row in zip(np.deg2rad(lat),src)])
src=gaussian_filter1d(src,1/(2.35482*.25),axis=0)
live=D['envelope'] & ~D['dark']
def aperture(lo,ba):
 dot=np.sin(b)*np.sin(np.deg2rad(ba))+np.cos(b)*np.cos(np.deg2rad(ba))*np.cos(l-np.deg2rad(lo))
 return dot>=np.cos(np.deg2rad(2))
def avg(v,m):return np.average(v[m],weights=np.cos(b[m]))
v=np.where(live,src,0)
bands=[aperture(303,-2)]+[(lon[None,:]>=40)&(lon[None,:]<=70)&(abs(lat[:,None]-ba)<=.5) for ba in [-8,-14]]
print('Source-tone candidate (Carina normalisation)',[round(20.7-2.5*np.log10(avg(v,m)/avg(v,aperture(287,-2))),2) for m in bands])
for label,tone in [('sRGB decoded after smoothing', np.where(src<=10.31475,src/(255*12.92),((src/255+.055)/1.055)**2.4))]:
 v=np.where(live,tone,0)
 print(label,[round(20.7-2.5*np.log10(avg(v,m)/avg(v,aperture(287,-2))),2) for m in bands])
rgb=np.array(Image.open(p/'source-map.png').convert('RGB'))/255.
linear=np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4)@np.array([.2126,.7152,.0722])
z=map_coordinates(np.pad(linear,((0,0),(1,1)),mode='wrap'),[y,(a%w)+1],order=1)
z=np.stack([gaussian_filter1d(row,1/(2.35482*.25*np.cos(ba)),mode='wrap') for ba,row in zip(np.deg2rad(lat),z)])
v=np.where(live,gaussian_filter1d(z,1/(2.35482*.25),axis=0),0)
print('Decode before sampling/smoothing:',[round(20.7-2.5*np.log10(avg(v,m)/avg(v,aperture(287,-2))),2) for m in bands])
fields={f'strip {ba}':(lon[None,:]>=10)&(lon[None,:]<=70)&(abs(lat[:,None]-ba)<=.5) for ba in [-8,-14]}
fields['Scutum']=np.cos(b)*np.cos(np.deg2rad(-3))*np.cos(l-np.deg2rad(27))+np.sin(b)*np.sin(np.deg2rad(-3))>=np.cos(np.deg2rad(3))
fields['Coalsack']=aperture(303,-2)
current=live*1.+D['bright']*.35+D['upper_75']*.75
for name,m in fields.items():
 print(name, 'current and candidate:',*[round(20.7-2.5*np.log10(avg(val,m)/avg(val,aperture(287,-2))),2) for val in [current,v]])
