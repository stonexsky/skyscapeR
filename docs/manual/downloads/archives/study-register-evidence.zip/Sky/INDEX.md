# skyscapeR validation record | 7 November 2026

Start with rising-study/README.txt and Heliacal-rising-results.csv for the expanded heliacal-rising benchmark. Each of the seven stars with a comparable event has ten site–epoch combinations. Antares, Procyon, Regulus and Spica were always within three days, Sirius within four and Aldebaran within five. Alcyone reached eight days once. In total, 61/70 were within three days and 69/70 within a week. These are differences between models, not intervals estimated from dated human sightings.

## Where to find each experiment

* patch-preview/retrace/ holds the approved outline, dark-region filtering, threshold alternatives, nested brightness tiers, intermediate masks, source map and comparison images. patch-preview/ also has the earlier reconstruction and validation scripts. The original paper-input ZIPs predate these tests; the source map and data used for this session's derivation are retained here.
* mwpkg/work/validation/ includes initial Swiss-coordinate checks, Milky Way rendering, software audit logs, plotting and compatibility checks. mwpkg/asset-check/ retains the source and classification checks. mwpkg/delivery/ contains the dated 2.0 source and example images.
* thorn-check/ holds the Thornborough cardinal views, geometry and bank tests. extinction/ compares the band with and without extinction using the same sky and records the transmission values.
* audit-light/ contains the original Sirius, Pleiades and Carina aperture experiment and the paired pixel measurements.
* light-build/ contains the first common V-band budget, its tests and previews. Use the installable 2.0.9001 source in light-build/release/.
* colour-dev/ contains the 2.0.9002 archive, physical planet/point-source zoom checks, colour-transfer tests, publication and natural wide fields, constellation-line comparisons and twilight examples.
* acceptance/ contains independent Milky Way field checks, twilight tests and the initial point-glow experiment. The northern-field longitude range was subsequently corrected in twilight-dev/mw-check.py using Table 3 of van der Kruit (2024).
* twilight-dev/ contains the 2.0.9003 archive, twilight calibration and held-out Maryland results, original Wiltshire rising/setting test, continuous Milky Way tone experiment and tapered-glow tests. The experiments with new interior tones and point-glow were not adopted. The accepted contours, dark regions and brightness tiers are retained.
* rising-study/ contains the expanded comparison at Wiltshire and Mnajdra: scripts, event dates, minute-search daily margins, checks through the renderer, observer sensitivity and the separate southern-star follow-up.
* release-default/final/ contains release-level checks and the build promoted to the natural default. Its vignette was rebuilt from source.

## Replaying the work

Keep these relative directories when running scripts. The original scripts and labels refer to their contemporary builds. Some use the development-only light.model switch: run those with the corresponding archived version. Use the 2.0.9004 public interface in new work. Install the R source archive required for a test, with swephR and the Swiss Ephemeris files covering the epoch. R/package dependencies, fonts, NASA source material and ephemeris files have their own credits and terms. The installed R libraries and external ephemeris distributions are not part of this record. For the expanded date comparisons follow rising-study/README.txt. Preliminary runs and their diagnostics are retained alongside successful checks. SHA256SUMS lists paths and digests for the archived evidence.
