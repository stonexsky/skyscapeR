"""Run the seven public createHor profiles concurrently after the native crop completes."""
from concurrent.futures import ThreadPoolExecutor
import csv,subprocess,sys,tempfile
from pathlib import Path
root=Path(__file__).resolve().parent
with (root/'wales15000-manifest.csv').open() as f: rows=list(csv.DictReader(f))
for r in rows:
    r['raster']='../terrain/wales-50km.tif'
    r['radius_m']=50000
    r['coverage_evidence']='Native 1 m DTM. Both bracketing rays must contain finite terrain samples to 50 km; onshore no-data and off-product bearings withheld.'
with (root/'wales50000-manifest.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,rows[0]);w.writeheader();w.writerows(rows)
def run(i):
    with tempfile.TemporaryDirectory() as t:
        manifest=Path(t)/'profile.csv'
        with manifest.open('w',newline='') as f:
            w=csv.DictWriter(f,rows[0]);w.writeheader()
            for j,r in enumerate(rows): w.writerow(dict(r,run_status='ready' if j==i else 'skip'))
        subprocess.run([sys.argv[1],*sys.argv[2:],str(manifest),'results-wales50000'],cwd=root,check=True,stdout=subprocess.DEVNULL)
with ThreadPoolExecutor(3) as pool:
    for _ in pool.map(run,range(len(rows))):pass
