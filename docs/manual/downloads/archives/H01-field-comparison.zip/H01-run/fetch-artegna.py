"""Acquire FVG numerical DTMs. The 10 m quadrant mosaic is a regional comparison."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import csv,subprocess,zipfile
base=Path(__file__).resolve().parent.parent
out=base/'terrain/it';out.mkdir(exist_ok=True,parents=True)
baseurl='https://irdat.regione.fvg.it/cartogdownload/DTM_PCR'
codes=['049141','049102','049142','049144','049154']
jobs=[('1M','DTM01_PCR_'+code+'_RDN2008_TM33') for code in codes]
jobs.extend(('10M',f'DTM10_PCR_{sheet}_{quadrant}_RDN2008_TM33') for sheet in ['048','049','050','066','067'] for quadrant in ['SO','SE','NO','NE'])
def get(args):
    res,key=args;url=baseurl+f'/{res}/6708/{key}.zip';archive=out/(key+'.zip')
    p=subprocess.run(['curl','-fsSL','--connect-timeout','12','--retry','1','--max-time','80',url,'-o',str(archive)],stderr=subprocess.DEVNULL)
    if p.returncode or not zipfile.is_zipfile(archive):
        return key,url,'unavailable'
    with zipfile.ZipFile(archive) as z:
        for n in z.namelist():
            if n.lower().endswith(('.asc','.prj')):
                with z.open(n) as src: (out/Path(n).name).write_bytes(src.read())
    return key,url,'downloaded'
with ThreadPoolExecutor(5) as ex:rows=list(ex.map(get,jobs))
with (out/'tiles.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['key','url','status']);w.writerows(rows)
