"""Bring the complete observation register into agreement with the selected runs."""
import pandas as pd
from pathlib import Path
root=Path(__file__).resolve().parent
screen=pd.read_csv(root/'eligibility-after-location-review.csv',dtype=str,keep_default_na=False)
pairs=pd.read_csv(root/'coverage-accounting.csv').set_index('pair_id')
bearings=pd.read_csv(root/'interim-results/bearing-residuals.csv')
lookup={(r.source_id,r.station,round(r.true_azimuth_deg%360,8)):r for r in bearings.itertuples()}
for i,r in screen.iterrows():
    if r.pair_id not in pairs.index:continue
    reason=pairs.at[r.pair_id,'reason']
    screen.loc[i,['h01_working_run','h01_working_product','h01_bearing_residual_deg']]=[reason,'','']
    if reason=='complete':
        b=lookup[(r.source_id,r.station,round(float(r.true_azimuth_deg)%360,8))]
        screen.loc[i,['h01_working_product','h01_bearing_residual_deg']]=[b.product,b.error]
screen.to_csv(root/'eligibility-after-location-review.csv',index=False,encoding='utf-8-sig')
pairs['complete_run_names']=''
for d in sorted(root.iterdir()):
    if d.name in ['alternate-sample','working-sample','chaco25-1188','chaco50-1188']:continue
    files=sorted(d.glob('station-*.csv'))
    if not files:continue
    tab=pd.concat([pd.read_csv(f) for f in files])
    if 'complete_ray' not in tab or 'pair_id' not in tab:continue
    for k in set(tab.loc[tab.complete_ray,'pair_id']).intersection(pairs.index):
        pairs.at[k,'complete_run_names']=(pairs.at[k,'complete_run_names']+' | '+d.name).strip(' |')
pairs.to_csv(root/'all-run-coverage.csv')
