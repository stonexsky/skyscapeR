"""Download checksum-verified EU-DEM inputs, then run prep-irish.R."""
import hashlib,subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
folder=Path(__file__).resolve().parent.parent/'terrain/ie'
folder.mkdir(parents=True,exist_ok=True)
def acquire(entry):
    name,sha=entry
    f=folder/(name+'.tif')
    if not f.exists():
        tmp=f.with_suffix('.part')
        subprocess.run(['curl','-fSL','--retry','2','--max-time','600',
                        'https://copernicus.data.lit.fmi.fi/dem/EU-DEM/eu_dem_v11_'+name+'.tif','-o',str(tmp)],check=True)
        tmp.replace(f)
    with f.open('rb') as fp:actual=hashlib.file_digest(fp,'sha256').hexdigest()
    if actual!=sha:raise ValueError(name+' does not match the archived input hash')
with ThreadPoolExecutor(2) as pool:
    list(pool.map(acquire,[('E20N30','f82ec827ea275fcdfe955f09496541fa16dc8c07b32c3f1a95882dbb1fe136aa'),('E30N30','fa68a2a4b0cb989ba8cba4967f232c6c0b82d5d3116c513c62ddab39a4927e34')]))
