"""Fetch only extra 5 m sheets that support the measured rays to 50 km."""
from pathlib import Path
import csv,subprocess,os
from urllib.parse import urlencode
from concurrent.futures import ThreadPoolExecutor
base=Path(__file__).resolve().parent
src=base.parent/'terrain'/'escan'
out=base.parent/'terrain'/'escan50'
out.mkdir(exist_ok=True)
with (base/'source-records/tenerife-50km-tiles.csv').open() as f:
    coords=sorted({(int(float(r['easting'])),int(float(r['northing']))) for r in csv.DictReader(f)})
def fetch(c):
    x,y=c;name=f'{x}_{y}.tif';t=out/name
    url='https://servicios.idee.es/wcs-inspire/mdt?'+urlencode([('service','WCS'),('version','2.0.1'),('request','GetCoverage'),('coverageId','Elevacion4083_5'),('subset',f'x({x},{x+10000})'),('subset',f'y({y},{y+10000})'),('format','image/tiff')])
    if not t.exists() and (src/name).exists():os.link(src/name,t)
    if not t.exists():
        tmp=t.with_suffix('.part')
        subprocess.run(['curl','-fsSL','--connect-timeout','15','--retry','2','--max-time','90',url,'-o',str(tmp)],check=True)
        with tmp.open('rb') as fp:
            if fp.read(2) not in (b'II',b'MM'):raise ValueError('Not TIFF: '+url)
        tmp.replace(t)
    return (name,url,'downloaded')
with ThreadPoolExecutor(4) as pool:rr=list(pool.map(fetch,coords))
with (out/'tiles.csv').open('w',newline='') as fp:
    w=csv.writer(fp);w.writerow(['file','url','status']);w.writerows(rr)
