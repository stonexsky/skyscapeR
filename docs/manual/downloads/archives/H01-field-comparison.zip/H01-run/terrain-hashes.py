"""Fingerprint every raster and virtual mosaic used in the study."""
import csv,hashlib
from pathlib import Path
base=Path(__file__).resolve().parent
terrain=base.parent/'terrain'
with (base/'source-records/terrain-sha256.csv').open('w',newline='') as fp:
    w=csv.writer(fp);w.writerow(['path','bytes','sha256'])
    for f in sorted(terrain.rglob('*')):
        if f.suffix.lower() not in {'.tif','.vrt','.hgt','.asc','.zip'}: continue
        with f.open('rb') as fh:sha=hashlib.file_digest(fh,'sha256').hexdigest()
        w.writerow([f.relative_to(terrain),f.stat().st_size,sha])
