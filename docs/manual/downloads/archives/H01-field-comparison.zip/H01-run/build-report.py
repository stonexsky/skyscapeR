from pathlib import Path
import base64,html,io,json
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
base=Path(__file__).resolve().parent
stats=pd.read_csv(base/'interim-results/accuracy.csv')
bearing=pd.read_csv(base/'interim-results/bearing-residuals.csv')
pair=pd.read_csv(base/'coverage-accounting.csv')
overview=stats.query("scale=='overall'").iloc[0]
country_lookup=pair[['source_id','station','country']].drop_duplicates()
bearing=bearing.merge(country_lookup,on=['source_id','station'],validate='many_to_one')
q=pair[pair.country!='Italy'].drop_duplicates(['source_id','station','true_azimuth_deg'])
country=[]
for c,rows in q.groupby('country'):
    d=bearing[bearing.country==c];country.append([c,len(rows),len(d),len(d[['source_id','station']].drop_duplicates()),d.error.mean(),d.error.abs().mean(),np.sqrt(np.mean(d.error**2))])
def table(frame):
    a=frame.copy()
    return a.to_html(index=False,float_format=lambda x:f'{x:.3f}',na_rep='—',border=0,classes='data')
def controls(d):
    return len(d),np.mean(d.error),np.mean(abs(d.error)),np.sqrt(np.mean(d.error**2))
def hist(x):
    fig,ax=plt.subplots(figsize=(7.4,2.9))
    all_e=bearing.error
    edges=np.arange(np.floor(all_e.min()*4)/4-.125,np.ceil(all_e.max()*4)/4+.376,.25)
    ax.hist(x,bins=edges,color='#316969',edgecolor='white',linewidth=.45)
    ax.axvline(0,c='#a4492f',ls='--',lw=1)
    ax.set_xlabel('Predicted minus measured altitude (degrees)');ax.set_ylabel('Bearings')
    ax.spines[['right','top']].set_visible(False);fig.tight_layout()
    f=io.BytesIO();fig.savefig(f,format='png',dpi=120);plt.close(fig)
    return '<img alt="Histogram of signed residuals in degrees" src="data:image/png;base64,'+base64.b64encode(f.getvalue()).decode()+'">'
def heading(s):return html.escape(s)
def block(x):
    out=''
    for key,g in x:
        key=' · '.join(map(str,key)) if isinstance(key,tuple) else str(key)
        out+='<details><summary>'+heading(key)+f' ({len(g)} bearings)</summary>'+hist(g.error)+'</details>'
    return out
head='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>H01 | Horizon altitude validation</title><style>body{max-width:960px;margin:2em auto;padding:0 1em;font:17px/1.55 system-ui;color:#1e3030}h1,h2,h3{line-height:1.2}h1{font-size:2rem}h2{border-top:1px solid #cedad5;padding-top:.7em}table{border-collapse:collapse;font-variant-numeric:tabular-nums;width:100%;font-size:.9rem}td,th{text-align:left;border-bottom:1px solid #d8e0de;padding:.4em}img{width:100%;max-width:760px}summary{cursor:pointer;padding:.45em 0}details{border-top:1px solid #ddd}section{overflow:auto}.intro{color:#415857}a{color:#175a61}</style>'''
out=head+'<h1>H01 · Measured and predicted horizon altitudes</h1><p class="intro">Working validation results · 8 November 2026 · skyscapeR 2.0.9004</p>'
out+='<h2>How accurately does createHor() reproduce a surveyed terrain skyline?</h2><p>Across 334 distinct bearings at 31 observing setups, the median absolute difference from the field measurement was <strong>0.036°</strong>, the mean absolute difference was <strong>0.169°</strong>, and <strong>91.9%</strong> of predictions fell within <strong>±0.5°</strong>. Mean signed error was <strong>+0.048°</strong> (predicted minus measured). Thus the DEM-derived skyline usually agreed with the observed terrain horizon to within half a degree at these bearings. Individual errors reached <strong>7.26°</strong>. The 0.5° figure is an observed proportion for this sample and cannot serve as an uncertainty bound for an individual sightline.</p><p>Each residual combines the effects of the terrain model, observer position and height, numerical skyline calculation and field measurement. The surveys sample particular directions at each setup. Accuracy between those directions, including narrow peaks or notches, remains unmeasured. The station and terrain summaries below show how far the pooled result transfers across the tested conditions.</p>'
out+=f'<p>The longer-radius comparison includes <b>{int(overview.n_bearings)} bearings from {int(overview.n_setups)} survey setups</b>. Each bearing contributes once. Positive residuals indicate that the computed horizon is higher. All errors are in degrees.</p>'
out+='<section>'+table(pd.DataFrame(country,columns=['Country','Screened bearings','Scored','Setups scored','Bias','MAE','RMSE']))+'</section>'
out+='<p>La Nariz and Argentina are separate diagnostic comparisons. Italy forms an additional figure-digitised comparison outside the 775 screened field bearings. Incomplete terrain rays are withheld. Coverage differs by country, terrain product and bearing. These are descriptive sample statistics.</p>'
out+='<h2>Pooled accuracy</h2><section>'+table(pd.DataFrame([[overview.bias_deg,overview.mae_deg,overview.median_absolute_deg,overview.rmse_deg,overview.q95_absolute_deg,100*overview['within_0.5']]],columns=['Bias','MAE','Median absolute error','RMSE','95th percentile |error|','Within 0.5° (%)']))+'</section>'+hist(bearing.error)
alt = pd.read_csv(base/'alternate-results/accuracy.csv').query("scale=='overall'").iloc[0]
out+=f'<h3>Irish terrain coverage comparison</h3><p>Replacing EU-DEM with SRTM for every Irish station gives {int(alt.n_bearings)} bearings from {int(alt.n_setups)} setups, a mean absolute error of {alt.mae_deg:.3f}° and an RMSE of {alt.rmse_deg:.3f}°. On the same 117 Irish bearings, MAE is 0.167° for EU-DEM and 0.120° for SRTM. Both profiles use a single source throughout each line of sight.</p>'
out+='<h2>Terrain sources</h2>'
g=stats[stats.scale=='DEM'][['group','n_bearings','n_setups','bias_deg','mae_deg','rmse_deg']].copy();g.columns=['Product, version and resolution','Bearings','Setups','Bias','MAE','RMSE']
out+='<section>'+table(g)+'</section>'+block(bearing.groupby(['product','dem_version','resolution_m'],sort=True))
out+='<h2>Survey setups</h2>'
station_summary=[]
for (c,s),group in bearing.groupby(['country','station']):
    station_summary.append([c,s,*controls(group)])
out+='<section>'+table(pd.DataFrame(station_summary,columns=['Country','Setup','Bearings','Bias','MAE','RMSE']))+'</section>'+block(bearing.groupby(['country','station']))
out+='<h2>Coverage and interpretation</h2><p>Ireland uses the 25 m EU-DEM to 65 km. Wales uses the native 1 m Welsh DTM to 50 km. Chaco uses USGS 1/3 arc-second terrain to 50 km. Tenerife uses the IGN 5 m DTM to 50 km with its published GPS positions and refraction-corrected field altitudes. The English controls use the 1 m DTM to 5 km. Malta and Orkney use an explicitly coarser SRTM comparison after gaps in the local lidar coverage. The archive separates these products and retains the incomplete native-resolution runs.</p>'
out+='<p>West Kennet reproduces the 12 previous predictions to numerical precision. At Rectory Farm the earlier exact-ray profiles trace several large differences to nearby terrain, approximately 245–289 m from the instrument. At Tal-Lippija the published −7.5° coastal sight produces the largest residual in this working sample. Its original label and measurement are retained.</p>'
extra=[]
for label,d in [('Argentina · 30 km', 'ar-supplement-30000'),('Argentina · 70 km','ar-supplement-70000'),('Argentina · 120 km','ar-supplement-120000'),('La Nariz · paper coordinates','results-esmain20000'),('La Nariz · official site centre','diagnostic-la-nariz'),('Artegna · 1 m / 5 km','italy-1-5000'),('Artegna · 10 m / 15 km','italy-10-15000'),('Artegna · 10 m / 30 km','italy-10-30000'),('Ireland · SRTM / 65 km','comparison-srtm-ireland')]:
    fs=list((base/d).glob('station-*.csv'))
    if fs:
        r=pd.concat([pd.read_csv(f) for f in fs]);r=r[r.complete_ray];r=r.rename(columns={'residual_deg':'error'})
        if len(r):extra.append([label,*controls(r)])
out+='<h2>Separate comparisons</h2><section>'+table(pd.DataFrame(extra,columns=['Comparison','Complete bearings','Bias','MAE','RMSE']))+'</section>'
out+='<p>The paper and statutory site-centre coordinates for La Nariz differ by 21.64 km. Both were tested. The official point identifies the sanctuary; the offsets to the two tripods remain unpublished. Argentine results use Copernicus GLO-30, a surface model, after the national terrain download service returned errors. The Italian observations are marker coordinates digitised from Patat’s Figure 3.</p>'
out+='<p>The official La Nariz site-centre coordinates are reported in <a href="https://transparencia.carm.es/wres/transparencia/doc/Consejo_Gobierno/2023-11-09/punto_20_bic_santuario_iberico_moratalla.pdf">the Murcia designation</a>. SRTM independently corroborates the approximately 618 m ground-elevation discrepancy at the coordinate in the survey paper. The official site centre is used solely for the separately labelled location check.</p>'
out+='<h2>What changed since the first run?</h2><p>The earlier working comparison used 15 km in Wales and Tenerife and scored 334 bearings (MAE 0.169°). Its Irish SRTM variant scored 727 (MAE 0.229°). This edition extends Wales and Tenerife to 50 km. A bearing can disappear from the longer run if either bracketing ray crosses missing terrain. The archive’s previous-edition directory retains the earlier report, bearing residuals and histograms.</p>'
radius_rows=[]
station_ranges=[]
for region,dirs in [('Wales',['results-wales15000','welsh-long-rays/r30000','results-wales50000']),('Tenerife',['nodata-escan15000','nodata-escan30000','nodata-escan50000'])]:
    for directory in dirs:
        obs=pd.concat([pd.read_csv(f) for f in (base/directory).glob('station-*.csv')])
        radius_km=int(obs.radius_m.iloc[0]/1000)
        radius_rows.append([region,radius_km,len(obs),int(obs.complete_ray.sum()),obs.loc[obs.complete_ray,'station'].nunique()])
        for station,group in obs.groupby('station'):
            station_ranges.append([region,station,radius_km,int(group.complete_ray.sum())])
out+='<section>'+table(pd.DataFrame(radius_rows,columns=['Region','Radius (km)','Measured pairs','Complete','Setups scored']))+'</section>'
ranges=pd.DataFrame(station_ranges,columns=['Region','Setup','Radius','Complete']).pivot(index=['Region','Setup'],columns='Radius',values='Complete').reset_index()
ranges.columns=['Region','Setup','15 km','30 km','50 km']
out+='<details><summary>Complete bearings by setup and radius</summary><section>'+table(ranges)+'</section></details>'
welsh=pd.concat(pd.read_csv(f) for f in (base/'welsh-long-rays/r50000').glob('station-*.csv'))
gaps=welsh.loc[welsh.first_missing_m.between(15001,50000),'first_missing_m']/1000
out+=f'<p>Of the {len(gaps)} Welsh bearings complete at 15 km that lose coverage at 50 km, the first missing terrain sample lies between {gaps.min():.2f} and {gaps.max():.2f} km (median {gaps.median():.2f} km). Fourteen of the 28 retained bearings come from the Gors Fawr stone circle. This changes the relative weight of individual observing setups in the pooled result.</p>'
out+='<p>The Welsh 15 and 50 km results use the public package profiles. The intermediate Welsh check reproduces the bracketing rays at their original radial spacing. In Tenerife, all complete 50 km bearings are from Barranco de la Tapia. Correctly masking the −32768 empty cells in the Spanish terrain service left the original 15 km Tenerife and 20 km La Nariz results unchanged.</p>'
out+='<p>The <a href="https://pnoa.ign.es/web/portal/pnoa-lidar/tercera-cobertura">Spanish third-coverage programme</a> publishes finer terrain products. The archive identifies the official map sheets intersected by each measured direction. Numerical finer-resolution coverage along those rays still needs verification. The scored Tenerife results use 5 m cells.</p>'
out+='<h2>Search distance</h2>'
changes=pd.read_csv(base/'radius-comparison.csv')
delta_rows=[]
for (c,rs,rl),g in changes.groupby(['country','radius_short_m','radius_long_m']):
    d=g.change_deg.abs()
    delta_rows.append([c,rs/1000,rl/1000,len(d),d.median(),d.max(),int((d>.05).sum())])
out+='<section>'+table(pd.DataFrame(delta_rows,columns=['Country','From km','To km','Paired readings','Median angular change','Maximum change','Changes >0.05°']))+'</section>'
out+='<p>Changes are computed only for rays complete at both radii. Chaco has 14 measured altitude pairs on 13 distinct bearings. Peak-finding and coverage are separate from comparisons between software packages. The archive preserves the complete set of row-level decisions, input URLs and reproducible code.</p></html>'
(base/'H01-validation-results.html').write_text(out,encoding='utf-8')
