library(terra)
p <- subset(read.csv("distinct-pairs.csv"),source_id=="ES-TFE")
tiles <- list()
for (st in unique(p$station)) {
  s <- p[p$station==st,]
  loc <- sprintf("+proj=aeqd +lat_0=%.12f +lon_0=%.12f +datum=WGS84 +units=m",s$lat[1],s$lon[1])
  az <- unique(c(floor(s$true_azimuth_deg/.25)*.25,ceiling(s$true_azimuth_deg/.25)*.25))
  az <- az*pi/180
  d <- seq(0,50000,by=25)
  xy <- cbind(as.vector(outer(d,sin(az))),as.vector(outer(d,cos(az))))
  native <- project(xy,loc,"EPSG:4083")
  # Include the interpolation neighbours even where a ray grazes a tile edge.
  for (dx in c(-35,35)) for(dy in c(-35,35)) {
    tiles[[length(tiles)+1L]] <- unique(data.frame(easting=floor((native[,1]+dx)/10000)*10000,
      northing=floor((native[,2]+dy)/10000)*10000))
  }
}
write.csv(unique(do.call(rbind,tiles)),"source-records/tenerife-50km-tiles.csv",row.names=FALSE)
