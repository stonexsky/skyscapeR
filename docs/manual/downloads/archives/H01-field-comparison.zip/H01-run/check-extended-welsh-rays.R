# Reproduce the public run at 15 km before extending its two bracketing rays
# using the same skyscapeR height extraction and refraction routines.
library(terra)
stopifnot(as.character(packageVersion("skyscapeR"))=="2.0.9004")
args <- commandArgs(TRUE)
max_km <- as.integer(args[1])
dem <- rast(args[2])
out <- args[3]
dir.create(out,showWarnings=FALSE,recursive=TRUE)
manifest <- read.csv("wales15000-manifest.csv",stringsAsFactors=FALSE)
heights <- getFromNamespace(".dem_heights","skyscapeR")
angles <- getFromNamespace(".patat_angle","skyscapeR")
grid_step <- 0.25
radii <- c(15000L,30000L,50000L)
radii <- radii[radii<=1000*max_km]
# Each incorporated section uses the 1 m radial grid of the public controls.
distance <- seq_len(max(radii))
for (i in seq_len(nrow(manifest))) {
  s <- manifest[i,]
  obs <- read.csv(file.path("results-wales15000",sprintf("station-%03d.csv",i)),stringsAsFactors=FALSE)
  origin <- sprintf("+proj=aeqd +lat_0=%.12f +lon_0=%.12f +datum=WGS84 +units=m", s$y,s$x)
  eye <- heights(dem,matrix(c(0,0),1),origin,site=c(s$y,s$x))+s$eye_height_m
  phi <- s$y*pi/180
  earth <- 6378137*6356752.314245/sqrt((6378137*sin(phi))^2+(6356752.314245*cos(phi))^2)
  patat <- 0.252*1013.25*(34.2-10)/(15+273.15)^2
  fraction <- round((obs$true_azimuth_deg %% 360)/grid_step,8)
  lo <- floor(fraction)*grid_step %% 360
  hi <- ceiling(fraction)*grid_step %% 360
  ray_angles <- sort(unique(c(lo,hi)))
  rays <- vector("list",length(ray_angles))
  for (j in seq_along(ray_angles)) {
    az <- ray_angles[j]*pi/180
    xy <- cbind(distance*sin(az),distance*cos(az))
    z <- heights(dem,xy,origin)
    a <- angles(z,eye,distance,earth,patat)
    gaps <- which(!is.finite(z))
    first_gap <- if(length(gaps)) min(gaps) else Inf
    rays[[j]] <- do.call(rbind,lapply(radii,function(radius) {
      keep <- which(distance<=radius & is.finite(a))
      winner <- if(length(keep)) keep[which.max(a[keep])] else NA_integer_
      data.frame(ray_deg=ray_angles[j],radius_m=radius,first_gap_m=first_gap,
        highest_available_deg=a[winner],distance_to_max_m=distance[winner],
        complete=first_gap>radius)
    }))
  }
  rays <- do.call(rbind,rays)
  write.csv(rays,file.path(out,sprintf("rays-%03d.csv",i)),row.names=FALSE)
  for (radius in radii) {
    p <- rays[rays$radius_m==radius,]
    l <- p[match(lo,p$ray_deg),]; h <- p[match(hi,p$ray_deg),]
    w <- fraction-floor(fraction)
    complete <- l$complete & h$complete
    calculated <- (1-w)*l$highest_available_deg + w*h$highest_available_deg
    predicted <- ifelse(complete,calculated,NA_real_)
    if (radius==15000L) {
      stopifnot(identical(as.logical(obs$complete_ray),complete),
                all(abs(predicted[complete]-obs$predicted_deg[complete])<1e-8))
    }
    row <- obs;row$complete_ray <- complete;row$predicted_deg <- predicted
    row$residual_deg <- predicted-row$altitude_deg;row$radius_m <- radius
    row$lo_peak_range_m <- l$distance_to_max_m;row$hi_peak_range_m <- h$distance_to_max_m
    row$first_missing_m <- pmin(l$first_gap_m,h$first_gap_m)
    dir <- file.path(out,paste0("r",radius));dir.create(dir,showWarnings=FALSE)
    write.csv(row,file.path(dir,sprintf("station-%03d.csv",i)),row.names=FALSE)
  }
}
