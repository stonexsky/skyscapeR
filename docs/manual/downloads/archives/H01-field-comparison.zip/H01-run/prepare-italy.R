library(terra)
d <- "../terrain/it"
for (size in c(1,10)) {
  pattern <- if (size==1) "^[0-9].*\\.asc$" else "^DTM_.*10m.*\\.asc$"
  fs <- list.files(d,pattern,full.names=TRUE,ignore.case=TRUE)
  stopifnot(length(fs)>0)
  outs <- character()
  for (f in fs) {
    tif <- sub("\\.asc$",".tif",f,ignore.case=TRUE)
    if (!file.exists(tif)) {
      r <- rast(f)
      crs(r) <- "EPSG:6708"
      writeRaster(r,tif,overwrite=TRUE,gdal=c("TILED=YES","COMPRESS=DEFLATE"))
    }
    outs <- c(outs,normalizePath(tif))
  }
  print(vrt(outs,filename=file.path(d,paste0("it",size,".vrt")),overwrite=TRUE))
}
