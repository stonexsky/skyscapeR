# Rscript summarise.R path-to-run-directory output-directory
args <- commandArgs(TRUE)
stopifnot(length(args)==2L)
files <- list.files(args[1],pattern="^station-[0-9]+\\.csv$",full.names=TRUE)
stopifnot(length(files)>0)
all <- do.call(rbind,lapply(files,read.csv,stringsAsFactors=FALSE))
dir.create(args[2],showWarnings=FALSE,recursive=TRUE)
all$complete_ray <- as.logical(all$complete_ray)
use <- subset(all, complete_ray & is.finite(predicted_deg) & is.finite(altitude_deg))
stopifnot(nrow(use)>0)
# Each bearing contributes once per actual setup; distinct altitude readings at
# identical bearings have equal weight after exact duplicate removal.
keys <- c("h01_class","source_id","station","true_azimuth_deg","product","dem_version","resolution_m")
bearing <- aggregate(use[c("predicted_deg","altitude_deg")],use[keys],mean)
bearing$error <- bearing$predicted_deg - bearing$altitude_deg
write.csv(bearing,file.path(args[2],"bearing-residuals.csv"),row.names=FALSE)
stats <- function(x) {
  e <- x$error
  data.frame(n_bearings=length(e),n_setups=nrow(unique(x[c("source_id","station")])),
    bias_deg=mean(e),median_signed_deg=median(e),mae_deg=mean(abs(e)),
    median_absolute_deg=median(abs(e)),rmse_deg=sqrt(mean(e^2)),
    sd_deg=sd(e),q95_absolute_deg=unname(quantile(abs(e),0.95)),
    max_absolute_deg=max(abs(e)),within_0.1=mean(abs(e)<=0.1),
    within_0.25=mean(abs(e)<=0.25),within_0.5=mean(abs(e)<=0.5),
    within_1=mean(abs(e)<=1))
}
collect <- list()
for (kind in unique(bearing$h01_class)) {
  b <- subset(bearing,h01_class==kind)
  groups <- list(overall=list(all=b),
    DEM=split(b,interaction(b$product,b$dem_version,b$resolution_m,drop=TRUE)),
    station=split(b,interaction(b$source_id,b$station,drop=TRUE)))
  cuts <- pretty(range(c(b$error,0)) + c(-0.001,0.001), n=24)
  pdf(file.path(args[2],paste0(make.names(kind),"-histograms.pdf")),width=8,height=5)
  for (scale in names(groups)) {
    for (key in names(groups[[scale]])) {
      d <- groups[[scale]][[key]]
      collect[[length(collect)+1L]] <- cbind(evidence=kind,scale=scale,group=key,stats(d))
      hist(d$error,breaks=cuts,col="grey75",border="white",
           main=paste(strwrap(iconv(paste(scale,key,sep=" - "),to="ASCII//TRANSLIT"),width=78),collapse="\n"),cex.main=0.9,xlab="Predicted minus measured horizon altitude (degrees)")
      abline(v=0,lty=2)
    }
  }
  dev.off()
}
write.csv(do.call(rbind,collect),file.path(args[2],"accuracy.csv"),row.names=FALSE)
