library(terra)
tag <- commandArgs(TRUE)[1]
d <- file.path("../terrain",tag)
tiles <- read.csv(file.path(d,"tiles.csv"),stringsAsFactors=FALSE)
f <- normalizePath(file.path(d,tiles$file[tiles$status=="downloaded"]))
stopifnot(length(f)>0)
r <- vrt(f,filename=file.path(d,"mosaic.vrt"),overwrite=TRUE)
print(r)
