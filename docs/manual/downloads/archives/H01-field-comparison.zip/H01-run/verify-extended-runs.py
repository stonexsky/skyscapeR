"""Confirm missing-data handling, radius controls and use of the exported createHor."""
from pathlib import Path
import numpy as np
import pandas as pd
root=Path(__file__).resolve().parent
def rows(directory):
    return pd.concat([pd.read_csv(f) for f in sorted((root/directory).glob('station-*.csv'))]).set_index('pair_id').sort_index()
checks=[]
for left,right in [('results-escan15000','nodata-escan15000'),('results-esmain20000','nodata-esmain20000'),('diagnostic-la-nariz','nodata-lanariz-designation'),('results-wales15000','welsh-long-rays/r15000'),('results-wales50000','welsh-long-rays/r50000')]:
    a,b=rows(left),rows(right)
    assert a.index.equals(b.index) and a.index.is_unique
    assert a.complete_ray.equals(b.complete_ray)
    assert np.allclose(a.predicted_deg,b.predicted_deg,equal_nan=True,rtol=0,atol=1e-8)
    d=(a.predicted_deg-b.predicted_deg).abs().max()
    checks.append([left,right,len(a),int(a.complete_ray.sum()),d])
pd.DataFrame(checks,columns=['run','check','pairs','complete','max_difference_deg']).to_csv(root/'source-records/extended-run-checks.csv',index=False)
