"""Trace the published bearings through the official MTN25 map-index grid.

The index identifies geographic sheets to request, not the availability of a
particular elevation product on those sheets. Geometry is sampled every 25 m.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import csv,json,math,subprocess
from urllib.parse import urlencode
import pandas as pd
base=Path(__file__).resolve().parent
out=base/'source-records'/'spanish-sheets';out.mkdir(parents=True,exist_ok=True)
src=pd.read_csv(base.parent/'followup/spanish-ray-paths.csv')
ref={'Barranco de la Tapia':(-16.433333,28.34166702),'La Pedrera':(-16.433333,28.50833302),'Teo 1':(-2.1875,38.16666704),'Teo 2':(-2.1875,38.16666704)}
def cell(x):
 ox,oy=ref[x.station]
 return (round(ox+(math.floor((x.lon-ox)*6)+.5)/6,6),round(oy+(math.floor((x.lat-oy)*12)+.5)/12,6))
src['cell']=[cell(x) for x in src.itertuples()]
def query(c):
 x,y=c
 p=dict(SERVICE='WMS',VERSION='1.1.1',REQUEST='GetFeatureInfo',LAYERS='cuadricula-mtn25-actual',QUERY_LAYERS='cuadricula-mtn25-actual',STYLES='',BBOX=','.join(map(str,[x-.01,y-.01,x+.01,y+.01])),SRS='EPSG:4326',WIDTH=101,HEIGHT=101,X=50,Y=50,FORMAT='image/png',INFO_FORMAT='application/json',FEATURE_COUNT=5)
 u='https://www.ign.es/wms-inspire/cuadriculas?'+urlencode(p)
 z=out/f'grid-{x}-{y}.json'
 if not z.exists():subprocess.run(['curl','-fsSL','--retry','1','--max-time','35',u,'-o',str(z)],check=True)
 features=json.loads(z.read_text())['features']
 if not features:return ('','no sheet returned',u)
 if len(features)!=1:raise ValueError('Overlapping maps: '+str(c))
 f=features[0]['properties'];return (f['numero'],f['nombre'],u)
keys=list(src.cell.drop_duplicates())
with ThreadPoolExecutor(5) as pool:info=dict(zip(keys,pool.map(query,keys)))
rows=[]
for (pid,st,c),g in src.groupby(['pair_id','station','cell']):
 sheet,name,url=info[c]
 rows.append(dict(pair_id=pid,station=st,from_m=int(g.distance_m.min()),to_m=int(g.distance_m.max()),sheet=sheet,sheet_name=name,official_grid_query=url))
with (out/'sightline-sheets.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,rows[0]);w.writeheader();w.writerows(rows)
print(pd.DataFrame(rows).groupby('station').sheet.unique())
