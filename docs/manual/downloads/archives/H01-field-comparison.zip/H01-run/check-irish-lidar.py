"""Query nine official GSI survey collections at the adopted Irish DEM stations."""
import subprocess,csv,json,time
from pathlib import Path
from urllib.parse import urlencode
from concurrent.futures import ThreadPoolExecutor
base=Path(__file__).resolve().parent
urls='https://gsi.geodata.gov.ie/server/rest/services/'
def load(url):
    p=subprocess.run(['curl','-fsSL','--retry','1','--connect-timeout','10','--max-time','28',url],capture_output=True)
    if p.returncode: return {}
    try:return json.loads(p.stdout)
    except ValueError:return {}
srvs=load(urls+'Lidar?f=pjson').get('services',[])
stations=[s for s in csv.DictReader((base/'station-manifest.csv').open()) if s['country']=='Ireland']
def station_query(inp):
    station,name,layer=inp
    sr=station['crs'].split(':')[-1];sr='4326' if sr=='CRS84' else sr
    params=dict(f='json',geometry=station['x']+','+station['y'],geometryType='esriGeometryPoint',
                inSR=sr,spatialRel='esriSpatialRelIntersects',outFields='*',returnGeometry='false')
    u=urls+name+'/FeatureServer/'+str(layer)+'/query?'+urlencode(params)
    d=load(u)
    features=d.get('features',[])
    return dict(station=station['station'],service=name,layer=layer,status='hit' if features else 'no intersection' if 'features' in d else 'query unavailable', hits=len(features),metadata=json.dumps([f['attributes'] for f in features],ensure_ascii=False),query=u)
jobs=[]
def layers(name):
    d=load(urls+name+'/FeatureServer?f=json')
    return name,[l['id'] for l in d.get('layers',[])]
with ThreadPoolExecutor(8) as pool:
    for name,ids in pool.map(layers,[s['name'] for s in srvs if s['type']=='FeatureServer']):
        for layer in ids or [0]:jobs.extend((s,name,layer) for s in stations)
    rr=list(pool.map(station_query,jobs))
if not rr:raise SystemExit('No valid catalogue returned.')
with (base/'source-records/irish-station-lidar-queries.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,rr[0]);w.writeheader();w.writerows(rr)
print([(r['station'],r['service'],r['hits']) for r in rr if r['hits']])
