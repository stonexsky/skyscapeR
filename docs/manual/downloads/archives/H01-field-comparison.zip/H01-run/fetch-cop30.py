"""Fetch Copernicus GLO-30 tiles for a provisional Argentine regional comparison."""
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import csv
base=Path(__file__).resolve().parent.parent
folder=base/'terrain/ar';folder.mkdir(parents=True,exist_ok=True)
def get(pos):
    y,x=pos;key=f'Copernicus_DSM_COG_10_S{abs(y):02d}_00_W{abs(x):03d}_00_DEM'
    url=f'https://copernicus-dem-30m.s3.amazonaws.com/{key}/{key}.tif'
    f=folder/(key+'.tif');tmp=f.with_suffix('.part')
    if not f.exists():
        p=subprocess.run(['curl','-fsSL','--retry','1','--connect-timeout','15','--max-time','90',url,'-o',str(tmp)],stderr=subprocess.DEVNULL)
        if p.returncode==0:tmp.replace(f)
    return f.name,url,'downloaded' if f.exists() else 'unavailable'
with ThreadPoolExecutor(5) as ex:rr=list(ex.map(get,[(y,x) for y in (-27,-26,-25,-24,-23) for x in (-69,-68,-67,-66,-65)]))
with (folder/'tiles.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['file','url','status']);w.writerows(rr)
print(rr)
