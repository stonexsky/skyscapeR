"""Retrieve native Environment Agency tiles for the two replication stations."""
import csv
import hashlib
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.parse import urlencode
from xml.etree import ElementTree as ET

base=Path(__file__).resolve().parent
out=base.parent/'terrain'
out.mkdir(exist_ok=True)
known={r['terrain_file']:r for r in csv.DictReader((base/'historical-uk-terrain-manifest.csv').open())}
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def fetch(name):
    target=out/name
    if target.exists() and digest(target)==known[name]['sha256_downloaded_or_losslessly_repacked_file']:return True
    x,y=map(int,target.stem.split('_')[-2:])
    params=[('service','WCS'),('version','2.0.1'),('request','GetCoverage'),('coverageId','13787b9a-26a4-4775-8523-806d13af58fc__Lidar_Composite_Elevation_DTM_1m'),('subset',f'E({x},{x+2000})'),('subset',f'N({y},{y+2000})'),('format','image/tiff')]
    url='https://environment.data.gov.uk/spatialdata/lidar-composite-digital-terrain-model-dtm-1m/wcs?'+urlencode(params)
    tmp=target.with_suffix('.part')
    response=subprocess.run(['curl','-fsSL','--retry','2','--connect-timeout','12','--max-time','75',url,'-o',str(tmp)])
    if response.returncode or digest(tmp)!=known[name]['sha256_downloaded_or_losslessly_repacked_file']:
        tmp.unlink(missing_ok=True);return False
    tmp.replace(target);return True

names=set()
for vrt,center,prefix in [('native',(410498,167749),'west-kennet'),('S2native',(525485,270925),'rectory-farm')]:
    root=ET.parse(base/'layouts'/f'{vrt}.vrt')
    for band in root.findall('VRTRasterBand'):
        for elem in band.findall('ComplexSource'):
            name=elem.findtext('SourceFilename')
            x,y=map(int,Path(name).stem.split('_')[-2:])
            # Cover the entire 5 km circle and interpolation neighbours.
            dx=max(0,x-center[0],center[0]-x-2000);dy=max(0,y-center[1],center[1]-y-2000)
            if dx*dx+dy*dy<=5100**2:names.add(name)
            else:band.remove(elem)
    root.write(out/f'{prefix}.vrt')
with ThreadPoolExecutor(5) as pool:
    results=list(pool.map(fetch,sorted(names)))
print(f'Verified {sum(results)} / {len(names)} tiles',flush=True)
if not all(results):raise SystemExit(1)
