library(terra)
r <- read.csv("distinct-pairs.csv",stringsAsFactors=FALSE)
s <- subset(r,source_id %in% c("ES-TFE","ES-NAR"))
out <- list()
for (st in unique(s$station)) {
  a <- s[s$station==st,]
  ll <- c(a$lon[1],a$lat[1]);radius<-50000
  if(a$source_id[1]=="ES-NAR") {
    ll <- as.numeric(project(matrix(c(582219,4229434),1L),"EPSG:25830","OGC:CRS84"))
    radius<-20000
  }
  local <- sprintf("+proj=aeqd +lat_0=%.12f +lon_0=%.12f +datum=WGS84 +units=m",ll[2],ll[1])
  d <- seq(0,radius,by=25)
  for(i in seq_len(nrow(a))) {
    az<-a$true_azimuth_deg[i]*pi/180
    xy<-project(cbind(d*sin(az),d*cos(az)), local,"OGC:CRS84")
    out[[length(out)+1L]]<-data.frame(pair_id=a$pair_id[i],station=st,distance_m=d,lon=xy[,1],lat=xy[,2])
  }
}
dir.create("../followup",showWarnings=FALSE)
write.csv(do.call(rbind,out),"../followup/spanish-ray-paths.csv",row.names=FALSE)
