"""Run beside screen-input.csv and observations.csv. Keep every source row."""
import csv
import re
from collections import defaultdict
from pathlib import Path

base = Path(__file__).parent
def read(name):
    with (base / name).open(encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))
def write(name, rows):
    with (base / name).open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, rows[0]); writer.writeheader(); writer.writerows(rows)

original = {r["observation_id"]: r for r in read("observations.csv")}
pilot = {(r["station"], float(r["azimuth_deg"]), float(r["observed_alt_deg"])): r["group"]
         for r in read("uk-pilot-targets.csv")}
obstacle = re.compile(r"tree|forest|bush|spruce|oak|ivy|gorse|hedge|hawthorn|evergreen|vegetation|\bveg\b|wood|pole|post|mast|house|chimney|gable|shed|barn|roof|trig|windmill|cottage|lighthouse|gate|obelisk|sheepfold|cross|farm|bale|spoil")
uncertain = re.compile(r"\?|\*|bank|cairn|road|cloud|slab|stone|silbury|circle|spike|wall|sea|through|below far|calculated|approx|/h\b")
land = re.compile(r"hill|slope|rock|cliff|crag|basal|ridge|notch|step|dip|hump|intersect|saddle|outcrop|break|\btop\b|mountain|\bmt\b|\brise\b")
def classify(r):
    state = r["decision"]
    if state == "advance to DEM selection":
        return "primary", r["foresight_evidence"] or r["foresight_screen"]
    if not state.startswith("hold"):
        return "outside cohort", state
    s, target = r["source_id"], r["target"].lower()
    if s == "IT-PAT":
        return "digitised comparison", "Patat Figure 3 open-circle measurements, eastern/western natural horizon; digitised."
    if s == "ES-NAR":
        return "primary", "Table 1 and Fig. 7, labels on the surveyed mountain skyline."
    if s == "ES-TFE":
        return "primary", "Tables 1–2 and profile figures. Published refraction-corrected H; match altitude convention before scoring."
    if "-W-" in s:
        key = (r["station"], float(r["true_azimuth_deg"]), float(r["altitude_deg"]))
        if key in pilot:
            group = pilot[key]
            if group == "terrain primary": return "primary", "UK field archive: "+group
            if group in ("vegetation or constructed reference", "source flagged vertical error"):
                return "exclude target", "UK field archive: "+group
            return "withhold", "UK field archive: "+group
        if "calculated" in target: return "exclude target", "Source explicitly labels target calculated."
        if obstacle.search(target):
            return "withhold" if land.search(target) else "exclude target", "Foreground or constructed reference in sight description."
        if uncertain.search(target) or state == "hold: flagged foresight":
            return "withhold", "Ambiguous, coastal, constructed or previously flagged sight."
        if land.search(target):
            return "primary", "Landform in Wilson’s field-table description: "+r["target"]
    return "withhold", "Individual terrain identity or observing setup still unresolved."

rows = read("screen-input.csv")
groups = defaultdict(list)
for r in rows:
    o = original[r["observation_id"]]
    status,reason = classify(r)
    r.update(h01_class=status, h01_reason=reason, pair_id="", source_height_m=o["reported_instrument_height_m"],
             source_angle_note=o["angle_note"])
    if status in ("primary","digitised comparison"):
        groups[(r["source_id"],r["station"],float(r["true_azimuth_deg"]) % 360,float(r["altitude_deg"]))].append(r)
pairs=[]
for entries in groups.values():
    first=entries[0]
    for r in entries:r["pair_id"]=first["observation_id"]
    pairs.append(dict(first,source_rows=len(entries),member_ids=" | ".join(r["observation_id"] for r in entries)))
write("screened.csv",rows)
write("distinct-pairs.csv",pairs)
