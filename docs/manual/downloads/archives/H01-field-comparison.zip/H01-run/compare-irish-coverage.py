"""Replace the full Irish stratum with one SRTM run per setup to show coverage effects."""
from pathlib import Path
import pandas as pd
base=Path(__file__).resolve().parent
out=base/'alternate-sample';out.mkdir(exist_ok=True)
sources=[]
for f in sorted((base/'working-sample').glob('station-*.csv')):
    a=pd.read_csv(f)
    if a.country.iloc[0]!='Ireland':sources.append(a)
sources.extend(pd.read_csv(f) for f in sorted((base/'comparison-srtm-ireland').glob('station-*.csv')))
for i,a in enumerate(sources,1):a.to_csv(out/f'station-{i:03}.csv',index=False)
fine=pd.concat([pd.read_csv(f) for f in (base/'results-ireland65000').glob('station-*.csv')])
coarse=pd.concat([pd.read_csv(f) for f in (base/'comparison-srtm-ireland').glob('station-*.csv')])
paired=fine[fine.complete_ray][['pair_id','station','residual_deg']].merge(coarse[coarse.complete_ray][['pair_id','residual_deg']],on='pair_id',suffixes=('_EUDEM','_SRTM'),validate='one_to_one')
paired.to_csv(base/'irish-matched-residuals.csv',index=False)
