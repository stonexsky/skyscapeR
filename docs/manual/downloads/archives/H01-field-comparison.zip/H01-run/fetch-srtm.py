from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import csv,subprocess,hashlib,zipfile,math
base=Path(__file__).resolve().parent
out=base.parent/'terrain'/'srtm'
out.mkdir(exist_ok=True)
stations=list(csv.DictReader((base/'station-manifest.csv').open()))
points=list(csv.DictReader((base/'distinct-pairs.csv').open()))
names=set()
for s in stations:
 if not (s['country']=='Ireland' or s['source_id'] in ['UK-REI','MT-LOM']):continue
 r=next(r for r in points if r['source_id']==s['source_id'] and r['station']==s['station'])
 lat,lon=float(r['lat']),float(r['lon'])
 dx=0.62/math.cos(math.radians(lat))
 for y in range(math.floor(lat-0.62),math.floor(lat+0.62)+1):
  for x in range(math.floor(lon-dx),math.floor(lon+dx)+1):
   names.add(f'N{y:02d}'+(f'W{-x:03d}' if x<0 else f'E{x:03d}'))
known={n.split('.')[0]:h for h,n in (l.split() for l in (base/'irish-pilot-srtm-sha256.txt').read_text().splitlines())}
def fetch(n):
    u='https://step.esa.int/auxdata/dem/SRTMGL1/'+n+'.SRTMGL1.hgt.zip'
    f=out/(n+'.zip')
    cmd=['curl','-fsSL','--connect-timeout','12','--max-time','80','--retry','1',u,'-o',str(f)]
    p=subprocess.run(cmd,stderr=subprocess.DEVNULL)
    if p.returncode:return (n,u,'unavailable','')
    with f.open('rb') as fp:h=hashlib.file_digest(fp,'sha256').hexdigest()
    if n in known and h!=known[n]:raise ValueError(n+' checksum mismatch')
    with zipfile.ZipFile(f) as z:
        data=z.read(n+'.hgt')
        if len(data)!=3601**2*2:raise ValueError(n+' wrong tile size')
        (out/(n+'.hgt')).write_bytes(data)
    return (n,u,'downloaded',h)
with ThreadPoolExecutor(6) as pool:rr=list(pool.map(fetch,sorted(names)))
with (out/'downloads.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['tile','url','status','sha256_zip']);w.writerows(rr)
