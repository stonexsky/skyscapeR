library(terra)
u <- '/vsicurl/https://dmwproductionblob.blob.core.windows.net/cogs/lidar/wales_dtm_32bit_cog.tif'
r <- rast(u)
print(r)
# Native window shared by seven Pembrokeshire sites. A 5km initial screen.
z <- crop(r,ext(204000,222000,222000,237000),filename='terrain/wales-first.tif',overwrite=TRUE,wopt=list(gdal=c('TILED=YES','COMPRESS=DEFLATE')))
print(z)
