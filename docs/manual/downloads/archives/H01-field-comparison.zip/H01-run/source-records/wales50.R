library(terra)
url <- "/vsicurl/https://dmwproductionblob.blob.core.windows.net/cogs/lidar/wales_dtm_32bit_cog.tif"
source <- rast(url)
# Clip to native raster bounds; outside coverage must remain missing.
wanted <- intersect(ext(source), ext(160000,268000,176000,283000))
out <- crop(source,wanted,filename="terrain/wales-50km.tif",overwrite=TRUE,wopt=list(gdal=c("TILED=YES","COMPRESS=DEFLATE","BIGTIFF=YES")))
print(out)
