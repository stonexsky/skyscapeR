import csv,json,subprocess
from pathlib import Path
from urllib.parse import urlencode
base=Path(__file__).resolve().parent
station=list(csv.DictReader((base/'source-records/irish-station-lidar-queries.csv').open()))
hits=[r for r in station if r['status']=='hit']
for i in [hits[0],hits[1]]:
    group='waterford' if 'OPW_' in i['service'] else 'westmeath'
    box='-8.60,51.20,-6.60,52.80' if group=='waterford' else '-8.60,52.85,-6.55,54.15'
    api=i['query'].split('?')[0]
    params=dict(f='geojson',geometry=box,geometryType='esriGeometryEnvelope',inSR=4326,spatialRel='esriSpatialRelIntersects',outFields='DATA_URL,DATA_NAME,RESOLUTION,LOCATION',outSR=4326,returnGeometry='true')
    dest=base/'source-records'/('gsi-'+group+'.geojson')
    subprocess.run(['curl','-fsSL','--retry','1','--max-time','40',api+'?'+urlencode(params),'-o',str(dest)],check=True)
    d=json.load(dest.open());print(group,len(d.get('features',[])),flush=True)
