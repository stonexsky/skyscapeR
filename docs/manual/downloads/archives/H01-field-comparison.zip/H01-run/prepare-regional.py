"""Set provisional comparison runs, one source product per raster."""
import csv
from pathlib import Path
base=Path(__file__).resolve().parent
items=list(csv.DictReader((base/'station-manifest.csv').open()))
def make(tag,selected,raster,product,version,res,radius,step,eye):
    rows=[]
    for r in selected:
        rows.append(dict(r,run_status='ready',raster='../terrain/'+raster,product=product,dem_version=version,resolution_m=res,radius_m=radius,distance_step_m=step,eye_height_m=eye,coverage_evidence='Test both neighbouring DEM rays for complete native samples out to declared radius. Product selection provisional.'))
    with (base/(tag+'-manifest.csv')).open('w',newline='') as f:
        w=csv.DictWriter(f,items[0]);w.writeheader();w.writerows(rows)
for radius in [25000,50000]:
    make('chaco'+str(radius),[r for r in items if r['source_id']=='US-MUN'],'us/chaco.vrt','USGS 3DEP 1/3 arc-second','2022–2024 tile editions',10,radius,5,1.6)
for radius in [25000,65000]:
    make('ireland'+str(radius),[r for r in items if r['country']=='Ireland'],'ie/ireland.vrt','EU-DEM','v1.1',25,radius,12.5,1.25)
make('wales5000',[r for r in items if r['source_id'].startswith('UK-W-') and r['station']!='West Kennet'],'wales-first.tif','Welsh Government DTM','2020–2023',1,5000,1,1.25)
for tag,sid,product,version,res,rad,step,eye in [
    ('mt','MT-LOM','Malta 2012 terrain WCS','2012',1,5000,1,1.6),
    ('escan','ES-TFE','IGN MDT05 WCS, Canarias','retrieved 2026-11-08',5,15000,2.5,1.6),
    ('esmain','ES-NAR','IGN MDT05 WCS, mainland','retrieved 2026-11-08',5,20000,2.5,1.6)]:
    make(tag+str(rad),[r for r in items if r['source_id']==sid],tag+'/mosaic.vrt',product,version,res,rad,step,eye)
