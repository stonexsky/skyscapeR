# Rscript run-station.R station-manifest.csv output-directory
args <- commandArgs(TRUE)
stopifnot(length(args) == 2L, as.character(packageVersion("skyscapeR")) == "2.0.9004")
sites <- read.csv(args[1], stringsAsFactors=FALSE)
points <- read.csv("distinct-pairs.csv", stringsAsFactors=FALSE)
dir.create(args[2], recursive=TRUE, showWarnings=FALSE)
for (i in seq_len(nrow(sites))) {
  s <- sites[i, ]
  if (s$run_status != "ready") next
  stopifnot(file.exists(s$raster), nzchar(s$product), nzchar(s$dem_version),
            is.finite(s$resolution_m), is.finite(s$eye_height_m),
            is.finite(s$radius_m), s$radius_m > 0, is.finite(s$distance_step_m),
            s$distance_step_m > 0, is.finite(s$x), is.finite(s$y),
            nzchar(s$crs), nzchar(s$coverage_evidence))
  rows <- subset(points, source_id == s$source_id & station == s$station)
  stopifnot(nrow(rows) > 0, length(unique(rows$h01_class)) == 1)
  loc <- c(s$x, s$y)
  if (is.finite(s$ground_override_m)) loc <- c(loc,s$ground_override_m)
  h <- skyscapeR::createHor(dem=s$raster, loc=loc, loc.crs=s$crs,
        eye.height=s$eye_height_m, max.distance=s$radius_m, az.step=s$az_step_deg,
        distance.step=s$distance_step_m, curvature=TRUE, refraction.k=if (is.na(s$refraction_k)) NULL else s$refraction_k,
        panorama=FALSE, ncores=1, verbose=FALSE)
  meta <- h$metadata$source
  step <- meta$az.step
  stopifnot(length(step)==1L, is.finite(step), "incomplete.bearings" %in% names(meta))
  az <- rows$true_azimuth_deg %% 360
  bins <- round(az / step, 8)
  incomplete <- round(meta$incomplete.bearings %% 360, 7)
  ok <- !(round((floor(bins)*step) %% 360, 7) %in% incomplete |
          round((ceiling(bins)*step) %% 360, 7) %in% incomplete)
  profile <- h$data
  pred <- approx(c(profile$az-360,profile$az,profile$az+360),
                 rep(profile$alt,3),xout=az)$y
  rows$predicted_deg <- ifelse(ok,pred,NA_real_)
  rows$complete_ray <- ok
  rows$product <- s$product
  rows$dem_version <- s$dem_version
  rows$resolution_m <- s$resolution_m
  rows$residual_deg <- rows$predicted_deg - rows$altitude_deg
  rows$radius_m <- s$radius_m
  rows$eye_height_m <- s$eye_height_m
  outfile <- file.path(args[2],sprintf("station-%03d.csv",i))
  write.csv(rows, paste0(outfile,".tmp"), row.names=FALSE)
  stopifnot(file.rename(paste0(outfile,".tmp"),outfile))
}
