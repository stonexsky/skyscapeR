"""Create one descriptive prediction per eligible bearing and show exclusions explicitly."""
from pathlib import Path
import csv
from collections import Counter
import shutil
base=Path(__file__).resolve().parent
def read(f):
 with Path(f).open(encoding='utf-8-sig') as h:return list(csv.DictReader(h))
def write(f,rows):
 with Path(f).open('w',newline='') as h:
  w=csv.DictWriter(h,rows[0].keys());w.writeheader();w.writerows(rows)
roster=read(base/'distinct-pairs.csv')
out=base/'working-sample';out.mkdir(exist_ok=True)
for p in out.glob('station-*.csv'):p.unlink()
def load(folder):
 return [r for f in sorted((base/folder).glob('station-*.csv')) for r in read(f)]
choices={'IE':'results-ireland65000','US':'results-chaco50000','ES-TFE':'nodata-escan50000',
         'MT':'comparison-srtm-malta','UK-W':'results-wales50000','UK-REI':'comparison-srtm-orkney',
         'UK-HUMBLE':'english-rectory','UK-W-West-Kennet':'english-west'}
rows_by_id={}
for choice in set(choices.values()):
 for r in load(choice):
  rows_by_id[r['pair_id']]=(choice,r)
census=[]; station_groups={}
for p in roster:
 sid=p['source_id'];pair=p['pair_id']
 if sid=='AR-CACHI':reason='National source unavailable; 30 m DSM comparison archived separately.'
 elif sid=='ES-NAR':reason='Conflicting survey and statutory positions; separate diagnostics.'
 elif sid=='IT-PAT':reason='Digitised figure; separate evidence class.'
 elif pair not in rows_by_id:reason='No selected prediction available.'
 else:
  choice,r=rows_by_id[pair]
  reason='complete' if r['complete_ray']=='TRUE' else 'Incomplete DEM coverage on bracketing rays.'
  station_groups.setdefault((sid,p['station']),[]).append(r)
 census.append(dict(pair_id=pair,country=p['country'],source_id=sid,station=p['station'],true_azimuth_deg=p['true_azimuth_deg'],
                    measured_altitude_deg=p['altitude_deg'],reason=reason))
for n,rr in enumerate(station_groups.values(),1):write(out/f'station-{n:03}.csv',rr)
write(base/'coverage-accounting.csv',census)
def radius_table(a,b):
 old={r['pair_id']:r for r in load(a)}
 result=[]
 for r in load(b):
  t=old.get(r['pair_id'])
  if t and r['complete_ray']==t['complete_ray']=='TRUE':
   result.append(dict(pair_id=r['pair_id'],station=r['station'],country=r['country'],radius_short_m=t['radius_m'],
               radius_long_m=r['radius_m'],change_deg=float(r['predicted_deg'])-float(t['predicted_deg'])))
 return result
changes=[]
for a,b in [('results-ireland25000','results-ireland65000'),('results-chaco25000','results-chaco50000'),
            ('results-wales5000','results-wales15000'),('results-wales15000','welsh-long-rays/r30000'),('welsh-long-rays/r30000','results-wales50000'),('results-wales15000','results-wales50000'),('nodata-escan15000','nodata-escan30000'),('nodata-escan30000','nodata-escan50000'),('nodata-escan15000','nodata-escan50000'),('ar-supplement-30000','ar-supplement-70000'),('ar-supplement-70000','ar-supplement-120000'),('italy-10-15000','italy-10-30000')]:
 changes.extend(radius_table(a,b))
if changes:write(base/'radius-comparison.csv',changes)
