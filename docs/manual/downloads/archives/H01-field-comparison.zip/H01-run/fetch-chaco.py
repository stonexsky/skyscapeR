import json,subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
root=Path(__file__).resolve().parent.parent
meta=json.load(open(Path(__file__).resolve().parent/'source-records/chaco10.json'))
def fetch(i):
    url=i['downloadURL'];dst=root/'terrain/us'/url.rsplit('/',1)[1]
    dst.parent.mkdir(parents=True, exist_ok=True)
    if not dst.exists():
        tmp=dst.with_suffix('.part')
        subprocess.run(['curl','-fsSL','--max-time','120','--retry','2',url,'-o',str(tmp)],check=True)
        if tmp.stat().st_size!=int(i['sizeInBytes']):raise ValueError('Unexpected size: '+str(tmp))
        tmp.replace(dst)
with ThreadPoolExecutor(4) as ex:list(ex.map(fetch,meta['items']))
