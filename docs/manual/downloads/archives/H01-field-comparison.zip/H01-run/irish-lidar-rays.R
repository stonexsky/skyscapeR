library(terra)
pts <- read.csv("distinct-pairs.csv")
hits <- subset(read.csv("source-records/irish-station-lidar-queries.csv"),status=="hit")
rows <- list()
for(st in hits$station) {
  x <- pts[pts$station==st,]
  region <- if(grepl("Ballynamona",st)) "waterford" else "westmeath"
  v <- vect(sprintf("source-records/gsi-%s.geojson",region))
  local <- sprintf("+proj=aeqd +lat_0=%.10f +lon_0=%.10f +datum=WGS84 +units=m",x$lat[1],x$lon[1])
  v <- project(v,local)
  for (i in seq_len(nrow(x))) {
    az <- x$true_azimuth_deg[i]*pi/180
    distance <- seq(0,65000,by=100)
    q <- vect(cbind(distance*sin(az),distance*cos(az)),crs=local)
    intersects <- relate(q,v,"intersects")
    miss <- !apply(intersects,1,any)
    rows[[length(rows)+1]] <- data.frame(pair_id=x$pair_id[i],station=st,azimuth_deg=x$true_azimuth_deg[i],
        first_missing_m=if(any(miss))min(distance[miss]) else NA)
  }
}
write.csv(do.call(rbind,rows),"irish-lidar-rays.csv",row.names=FALSE)
