library(terra)
s <- read.csv("distinct-pairs.csv")
s <- subset(s,source_id=="UK-REI")
origin <- sprintf("+proj=aeqd +lat_0=%.10f +lon_0=%.10f +datum=WGS84 +units=m",s$lat[1],s$lon[1])
names <- readLines("../acquisition/orkney-tile-names.txt")
out <- list()
for (i in seq_len(nrow(s))) {
  az <- s$true_azimuth_deg[i]*pi/180
  distance <- seq(0,30000,by=100)
  xy <- project(cbind(sin(az)*distance,cos(az)*distance), origin,"EPSG:27700")
  letters25 <- strsplit("abcdefghjklmnopqrstuvwxyz","")[[1]]
  e <- floor(xy[,1]/100000); n <- floor(xy[,2]/100000)
  first <- (19-n) - (19-n) %% 5 + floor((e+10)/5)
  second <- ((19-n) * 5) %% 25 + e %% 5
  ids <- sprintf("%s%s%02d%02d_50cm_dtm_orkney2023", letters25[first+1],letters25[second+1],floor(xy[,1]/1000) %% 100,floor(xy[,2]/1000) %% 100)
  bad <- !ids %in% names
  out[[i]] <- data.frame(pair_id=s$pair_id[i],azimuth_deg=s$true_azimuth_deg[i],
    missing_catalogue_tiles=paste(unique(ids[bad]),collapse=" "),first_missing_m=if(any(bad)) min(distance[bad]) else NA_real_)
}
write.csv(do.call(rbind,out),"orkney-coverage.csv",row.names=FALSE)
