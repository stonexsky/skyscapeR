"""Mark unlabelled INT16 empty cells in IGN's numerical WCS response.

Preserve the originally downloaded TIFFs. Edit only the VRT layer, so the
earlier interpretation can be reproduced exactly for paired diagnostics.
"""
from pathlib import Path
from xml.etree import ElementTree as ET
import csv
root=Path(__file__).resolve().parent
for region in ("escan","esmain","escan50"):
    terrain=root.parent/'terrain'/region
    if region=='escan50' and not (terrain/'mosaic.vrt').exists():continue
    tree=ET.parse(terrain/'mosaic.vrt')
    for band in tree.findall('VRTRasterBand'):
        def setval(parent,tag,val):
            node=parent.find(tag)
            if node is None:node=ET.SubElement(parent,tag)
            node.text=str(val)
        setval(band,'NoDataValue',-32768)
        for src in list(band):
            if src.tag in ('SimpleSource','ComplexSource'):
                src.tag='ComplexSource'
                setval(src,'NODATA',-32768)
    tree.write(terrain/'nodata.vrt')
for name in ['escan15000','esmain20000','lanariz-designation']:
    path=root/(name+'-manifest.csv')
    with path.open() as f:rows=list(csv.DictReader(f))
    for row in rows:
        row['raster']=row['raster'].replace('/mosaic.vrt','/nodata.vrt')
        row['coverage_evidence']='Native IGN Int16 sentinel -32768 is explicitly NoData in this VRT. Each bracketing ray checked for missing samples.'
    with (root/(name+'-nodata-manifest.csv')).open('w',newline='') as f:
        w=csv.DictWriter(f,rows[0]);w.writeheader();w.writerows(rows)

for radius in (30000,50000):
    with (root/'escan15000-nodata-manifest.csv').open() as f:rows=list(csv.DictReader(f))
    for row in rows:row.update(radius_m=radius,raster='../terrain/escan50/nodata.vrt')
    with (root/f'escan{radius}-nodata-manifest.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,rows[0]);w.writeheader();w.writerows(rows)
