"""Download bounded numerical WCS windows. A failed or XML response is not a tile."""
import concurrent.futures,csv,subprocess,sys
from pathlib import Path
from urllib.parse import urlencode
base=Path(__file__).resolve().parent.parent
mode=sys.argv[1]
if mode=='mt':
    service='https://malta.coverage.wetransform.eu/dtm_1m_2012/ows'
    coverage='dtm_1m_2012'; axes='EN'; step=2000; ranges=[(434000,448000,3968000,3982000)]
elif mode in ('escan','esmain'):
    service='https://servicios.idee.es/wcs-inspire/mdt'
    coverage='Elevacion4083_5' if mode=='escan' else 'Elevacion25830_5'
    axes='xy'; step=10000
    ranges=[(340000,390000,3110000,3160000),(350000,400000,3140000,3190000)] if mode=='escan' else [(540000,610000,4200000,4270000)]
else:raise ValueError(mode)
out=base/'terrain'/mode;out.mkdir(exist_ok=True,parents=True)
coords=sorted({(x,y) for w,e,s,n in ranges for x in range(w,e,step) for y in range(s,n,step)})
def get(c):
    x,y=c;f=out/f'{x}_{y}.tif'
    url=service+'?'+urlencode([('service','WCS'),('version','2.0.1'),('request','GetCoverage'),('coverageId',coverage),('subset',f'{axes[0]}({x},{x+step})'),('subset',f'{axes[1]}({y},{y+step})'),('format','image/tiff')])
    if not f.exists():
        tmp=f.with_suffix('.download')
        p=subprocess.run(['curl','-fsSL','--retry','1','--connect-timeout','12','--max-time','80',url,'-o',str(tmp)],stderr=subprocess.DEVNULL)
        if p.returncode==0 and tmp.exists():
            with tmp.open('rb') as fp:sig=fp.read(4)
            if sig[:2] in (b'II',b'MM'):tmp.replace(f)
        tmp.unlink(missing_ok=True)
    return (f.name,url,'downloaded' if f.exists() else 'unavailable')
with concurrent.futures.ThreadPoolExecutor(5) as pool:
    records=list(pool.map(get,coords))
with (out/'tiles.csv').open('w',newline='') as fp:
    w=csv.writer(fp);w.writerow(['file','url','status']);w.writerows(records)
print(mode, len(coords), sum(r[2]=='downloaded' for r in records),flush=True)
