# Recreating the run

Unpack the archive into a directory containing H01-run/. Use R with terra and the versioned skyscapeR source from source-records/. All station commands are launched with H01-run as the current directory. Fetchers place files in a sibling terrain/ directory. Rscript run-station.R MANIFEST OUTPUT writes new predictions. Rscript summarise.R OUTPUT REPORT_FOLDER generates CSV summaries and histogram PDFs. The field screen is reproduced by python screen.py. Python 3.11 or later is required for hashlib.file_digest.

The following inputs and rebuild steps accompany the results:

| Area | Raster preparation | Run settings |
|---|---|---|
| England | python fetch-english-controls.py; both VRTs are reconstructed from source layouts and hash-checked tiles | west-kennet-manifest.csv; rectory-farm-manifest.csv |
| Ireland | python download-irish-regional.py; Rscript prep-irish.R | ireland25000-manifest.csv; ireland65000-manifest.csv |
| SRTM | python fetch-srtm.py; use terra::vrt on the resulting HGT files to make ../terrain/srtm/mosaic.vrt | srtm-ireland-manifest.csv; srtm-malta-manifest.csv; srtm-orkney-manifest.csv |
| Wales | Run source-records/wales-test.R and source-records/wales15.R from the parent directory with the two commands' relative paths, or change the destinations to ../terrain from H01-run | wales5000-manifest.csv; wales15000-manifest.csv |
| US | python fetch-chaco.py; use terra::vrt on the four US TIFFs in ../terrain/us to write ../terrain/us/chaco.vrt, retaining NAD83 | chaco25000-manifest.csv; chaco50000-manifest.csv |
| Tenerife, La Nariz and Malta | python fetch-wcs.py REGION; Rscript prepare-wcs.R REGION. REGION is escan, esmain or mt. Malta uses the native numerical 2012 data | escan15000-manifest.csv; esmain20000-manifest.csv; lanariz-designation-manifest.csv; mt5000-manifest.csv |
| Argentina | python fetch-cop30.py; Rscript prepare-wcs.R ar | ar30000-, ar70000- and ar120000-manifest.csv |
| Italy | python fetch-artegna.py; Rscript prepare-italy.R | it1-5000-, it10-15000- and it10-30000-manifest.csv |

The corresponding output directories are named in assemble-checkpoint.py and build-report.py. assemble-checkpoint.py gathers the longest tested primary run chosen for each station. compare-irish-coverage.py replaces the Irish stratum with SRTM to give an alternate pooled result. Separate regional, source and location diagnostics are retained at their named run directories. Use summarise.R on working-sample/ and alternate-sample/ before running build-report.py. The report builder requires pandas, NumPy and Matplotlib. The SHA-256 inventory records the actual external raster files used in this checkpoint. Provider updates can change source file hashes; preserve the product vintage and report any mismatch.

Eye height and radius are design inputs; they must not be fitted to residuals. Terrain selection across the entire international cohort remains provisional. This release supports a descriptive validation report, not a claim of universal accuracy or an inter-software ranking.

### Extended Welsh and Tenerife runs

For Wales, run `Rscript H01-run/source-records/wales50.R` from the directory containing H01-run and terrain. This crops the native Welsh DTM in British National Grid without resampling. From H01-run use `python run-wales50.py Rscript run-station.R`, then `Rscript check-extended-welsh-rays.R 50 ../terrain/wales-50km.tif welsh-long-rays`. The second command records the first missing sample and distance to each ray maximum and provides the intermediate 30 km comparison.

For Spain, prepare the original WCS mosaics first. Run `Rscript tenerife-tile-list.R`, `python fetch-tenerife-extended.py`, then `Rscript prepare-wcs.R escan50` and `python fix-ign-nodata.py` and use run-station.R on each *-nodata-manifest.csv file. See the file names in verify-extended-runs.py and assemble-checkpoint.py for the output folders. Run `Rscript spanish-ray-footprints.R` and `python spanish-sheet-register.py` for the finer-product sheet inventory. Those sheet identifiers establish the geographical lookup, not the availability of downloadable elevation data.

Run `python verify-extended-runs.py` for the Welsh paired check and the three Spanish missing-value controls. Run assemble-checkpoint.py and compare-irish-coverage.py before summarise.R, followed by refresh-screen.py and build-report.py. The previous pooled statistics remain in historical-input/previous-{working,alternate}-accuracy.csv. Source rasters are retrieved separately and can require substantial disk space.
