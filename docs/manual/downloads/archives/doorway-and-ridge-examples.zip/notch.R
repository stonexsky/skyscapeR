library(skyscapeR)
skyscapeR.vars(refraction=FALSE, timezone="UTC", calendar="G", atm=1013.25, temp=15)
site <- c(51, 0, 100)
bearing <- c(0, 87, 89, 89.2, 90.8, 91, 93, 360)
height <- c(6, 6, 6, 1, 1, 6, 6, 6)
notch <- createHor(bearing, height, loc=site, alt.unc=0.2)
level <- createHor(c(0,360), c(1,1), loc=site, alt.unc=0.2)
door <- az.pdf(90, unc=2, pdf="uniform", name="Doorway", verbose=FALSE)
transform_one <- function(h, az_step=0.02, dec_step=0.02) {
  coordtrans(door, h, xrange=c(-4,9), .prec=az_step, .res=dec_step,
             .output.res=0.01, verbose=FALSE)
}
d <- transform_one(notch)
flat <- transform_one(level)
sm <- spd(d, xrange=c(-4,9), normalise=TRUE)
print(hpdi(sm, mass=0.68))
print(hpdi(flat, mass=0.68))
fine <- transform_one(notch, 0.01, 0.01)
print(hpdi(fine, mass=0.68))
write.csv(data.frame(dec=sm$data$x, notch=sm$data$y,
                     flat=flat$data[[1]]$y), "doorway.csv",row.names=FALSE)
write.csv(data.frame(bearing,height),"notch.csv",row.names=FALSE)
