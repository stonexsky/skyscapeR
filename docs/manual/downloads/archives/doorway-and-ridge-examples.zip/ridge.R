library(skyscapeR)
skyscapeR.vars(refraction=FALSE, timezone="UTC", calendar="G", dec="topo",
              atm=1013.25, temp=15)
site <- c(51,0,100)
ridge <- createHor(c(0,91.5,93,94,97,360), c(0,0,8,8,0,0), loc=site)
day <- "2026/03/20"
events <- riseset(ridge, date=day, obj="sun", timezone="UTC", calendar="G",
                  refraction=FALSE, verbose=FALSE)
print(events$rise)
print(events$set)
start <- time2jd(paste(day,"05:45:00"), timezone="UTC",calendar="G")
minutes <- 0:90
positions <- body.position(start+minutes/1440, obj="sun", loc=site,
                           refraction=FALSE, verbose=FALSE)$horizontal
print(names(positions))
terrain <- hor2alt(ridge, positions$az)
write.csv(data.frame(minutes,az=positions$az,h=positions$alt,terrain=terrain),
          "ridge.csv",row.names=FALSE)
print(spatial.equinox(ridge, year=2026, refraction=FALSE))
print(solar.date(0, 2026, calendar="G", verbose=FALSE))
