from pathlib import Path
import csv,numpy as np
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
base=Path(__file__).resolve().parent;out=base
def arr(f):return np.genfromtxt(base/f,delimiter=',',names=True)
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans','axes.labelcolor':'#243446','text.color':'#243446','xtick.color':'#435461','ytick.color':'#435461','figure.facecolor':'white'})
a=arr('notch.csv'); b=arr('doorway.csv')
fig,ax=plt.subplots(2,1,figsize=(7,5.7),layout='constrained')
x=np.arange(87.5,92.51,.01); y=np.interp(x,a['bearing'],a['height'])
ax[0].axvspan(88,92,color='#eee5d9',label='Doorway bearing range (88–92°)')
ax[0].plot(x,y,color='#a55127',lw=2.2,label='Notched skyline');ax[0].axhline(1,ls='--',color='#1b6771',label='Level control')
ax[0].set(xlabel='True bearing (degrees)',ylabel='Terrain altitude (degrees)',ylim=(0,8));ax[0].legend(frameon=False,ncol=2,fontsize=8,loc='upper left')
ax[1].plot(b['dec'],b['notch'],color='#a55127',lw=2.1,label='Notched skyline')
ax[1].plot(b['dec'],b['flat'],color='#1b6771',ls='--',lw=2,label='Level control')
for i,(l,h) in enumerate([(.35,1.21),(3.46,3.97),(5.37,5.83)]):
 sel=(b['dec']>=l)&(b['dec']<=h);ax[1].fill_between(b['dec'],0,b['notch'],where=sel,color='#e2a378',label='68% regions (notch)' if not i else None)
ax[1].set(xlabel='Declination (degrees)',ylabel='Density (per degree)',xlim=(-2,8),ylim=(0,None));ax[1].legend(frameon=False,fontsize=8,loc='lower center',bbox_to_anchor=(0.5,1.0),ncol=3)
fig.savefig(out/'doorway-densities.png',dpi=170);plt.close(fig)
r=arr('ridge.csv');fig,ax=plt.subplots(figsize=(7,3.5),layout='constrained')
ax.fill_between(r['minutes'],r['terrain'],-5,color='#ded7ca',label='Terrain')
ax.plot(r['minutes'],r['h'],lw=2.2,color='#a55127',label="Solar centre")
ax.plot(r['minutes'],r['terrain'],lw=1.3,color='#665b4d')
ax.set(xlabel='Time (UTC), 20 March 2026',ylabel='Altitude (degrees)',xlim=(0,80),ylim=(-4,11))
ax.set_xticks([0,15,30,45,60,75],['05:45','06:00','06:15','06:30','06:45','07:00'])
ax.legend(frameon=False);fig.savefig(out/'ridge-crossings.png',dpi=170)
